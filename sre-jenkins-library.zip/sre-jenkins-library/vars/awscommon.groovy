import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType

def getServerCount(aws_application_type,aws_environment,ec2_component,consulCred){
  if (aws_environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(aws_environment == 'qa') {
    env.promenv='staging'
    environment_name = "qa"
  } else if(aws_environment == 'stg') {
    env.promenv='prod'
    environment_name = "stg"
  }else if(aws_environment == 'prod') {
    env.promenv='prod'
    environment_name = "prod"
  }
  withCredentials([string(credentialsId: consulCred, variable: 'authorization')]) {
   sh """
   cat > consul_report.py <<-'EOF'
import requests
import json
import base64

url="http://172.16.11.56:8500/v1/kv/terraform/state/"
aws_application_type='${aws_application_type}'
aws_environment='${aws_environment}'
ec2_component='${ec2_component}'
authorization='${authorization}'
auth = 'Bearer '+'${authorization}'
headers = {"content-type": "application/json","authorization": auth}
response=requests.get(url + aws_application_type +"/" + aws_environment +"/" + ec2_component,headers=headers)
base64_message = response.json()[0]['Value']
message_bytes = base64.b64decode(base64_message)
x = json.loads(message_bytes)
ip_list = []
f = open("iplist.txt", "w")
for resource in x['resources']:
  for instance in resource['instances']:
    private_ip=instance.get('attributes').get('private_ip')
    if (private_ip):
      print (private_ip)
      f.write(private_ip)
      f.write("\\n")
      ip_list.append(private_ip)

f.close()
print (len(ip_list))
"""
sh """
pip install requests
python consul_report.py
"""
  sh """
   	 cat iplist.txt | wc -l > job.serverCount
   	 cat job.serverCount
   """
   return sh(script:"cat job.serverCount", returnStdout:true).trim()
  }
}

def versionupdate_databag(repo_name,build_number,app_farm,environment,cred_id)
{
  println repo_name
  println WORKSPACE
  println env.WORKSPACE
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
  sh """
  echo $workspace
  echo $repo_name
  app_farm=${app_farm}
  repo_name=${repo_name}
  environment=${environment}
  build_number=${build_number}
  git config --global user.email 'svc-devops'
  git config --global user.name 'svc-devops@drfirst.com'
  #mkdir -p /home/jenkins/.chef
  #cp -f /home/jenkins/.chef_basic/knife.rb /home/jenkins/.chef
  #cp -f /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
  #cp -f /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef

  cd $WORKSPACE
  rm -rf ${repo_name}
  git clone https://\${GITPASS}@git.drfirst.com/devops-se/${repo_name}.git
  cd ${repo_name}

  git config remote.origin.url https://\${GITPASS}@git.drfirst.com/devops-se/${repo_name}.git
  git checkout master
  if echo "${build_number}" | grep -q "-"; then
    echo "build number  via CI"
    version=`echo "${build_number}" | rev | cut -d"-" -f 3- | rev`
    build=`echo "${build_number}" | rev | cut -d"-" -f -2 | rev`
  else
    echo "build number not via CI"
    version=`echo "${build_number}" | rev | cut -d"." -f 2- | rev`
    build=`echo "${build_number}" | rev | cut -d"." -f -1 | rev`
  fi;
#  version="\\\"version\\\":\\\"`echo \$version`\\\","
#  build="\\\"build\\\":\\\"`echo \$build`\\\""
  echo "testing jq"

  jq ".version = \\\"\$version\\\"| .build=\\\"\$build\\\"" data_bags/app_${app_farm}/${environment}.json >> test.json
  cat test.json
  mv test.json data_bags/app_${app_farm}/${environment}.json
  if [ -n \"\$(git status --porcelain)\" ]; then
    git commit -am "version update"
    git push origin master
    knife data bag  from file app_${app_farm}  data_bags/app_${app_farm}/${environment}.json
    echo "change"
  else
    echo 'no changes';
  fi
  rm -rf $WORKSPACE/${repo_name}

"""
  }
}

def deploy1stmachine(aws_application_type,aws_environment,ec2_component,primaryServerCount){
  if (environment == 'dev') {
    env.promenv='qa'
    env.environment_name = "Development"
    println "environment_name dev - ${env.environment_name}"
  } else if(environment == 'qa') {
    env.promenv='staging'
    env.environment_name = "qa"
    println "environment_name qa - ${env.environment_name}"
  } else if(environment == 'staging') {
    env.promenv='prod'
    env.environment_name = "stg"
    println "environment_name staging - ${env.environment_name}"
  }
  else if(env.environment == 'prod') {
    env.promenv='prod'
    env.environment_name = "prod"
    println "environment_name prod - ${env.environment_name}"
  }
   sh """
      #mkdir -p /home/jenkins/.chef
      #cp -f /home/jenkins/.chef_basic/knife.rb /home/jenkins/.chef
      #cp -f /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
      #cp -f /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef
      machine_name=\$(sed -n '1p' iplist.txt)
      echo \$machine_name
      echo "host_name=\$machine_name" > build.properties
      # eval "knife node show \$machine_name"
      if [[ '${primaryServerCount}' == '1' ]]; then
          #eval "knife ssh 'addresses:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date && whoami \\\""
          eval "knife ssh 'addresses:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem' -a ipaddress \\\"sudo chef-client\\\""
      else
          #eval "knife ssh 'addresses:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date && whoami \\\""
          eval "knife ssh 'addresses:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem' -a ipaddress \\\"sudo chef-client\\\""
      fi
      #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":false }}' | sudo chef-client -j /dev/stdin\\\""
      """
  }

def getPrimaryList(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "qa"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "stg"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "prod"
  }
   sh """
     cat iplist.txt |sed -e '1d' > machine_list
     cat machine_list
   """
}

def consumeDeployItem(queueName,enableDisable,workerID){
sh """
cat > consumeDeployItem${workerID}.py <<-'EOF'
#!/usr/bin/env python
import pika
import subprocess
import sys

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials, socket_timeout=600))
channel = connection.channel()

status = channel.queue_declare(queue='${queueName}',durable=True, auto_delete=True, arguments={
    'x-max-priority': 10
})
print('${queueName}')
print('${enableDisable}')

def writeJobToFile(job_body):
  f = open("machine_list${workerID}", "wb")
  f.write(job_body)
  f.close()

def executeChef(machine_name):
  chefCmd = ["knife ssh 'addresses:"+machine_name.decode("utf-8")+"' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem' -a ipaddress sudo chef-client  " ]
  print(chefCmd)
  retry=0
  while retry < 2 :
    retry += 1
    try:
      result = subprocess.run(chefCmd, stderr=sys.stderr, stdout=sys.stdout, shell=True, check=True)
      print(result.returncode, result.stdout, result.stderr)
    except:
      if retry == 2:
        sys.exit(1)
      continue
    break

if '${enableDisable}' == 'enable':
  i = 1
else:
  i = 0

print(i)

while i != 0:
  method_frame, header_frame, body = channel.basic_get('${queueName}', auto_ack=True)
  if method_frame:
      print(method_frame, header_frame, body)
      print(method_frame.message_count)
      #channel.basic_ack(method_frame.delivery_tag)
      writeJobToFile(body)
      executeChef(body)
      i = method_frame.message_count
  else:
      print('No message returned')
      break
"""

sh """
python -u consumeDeployItem${workerID}.py
"""
}
