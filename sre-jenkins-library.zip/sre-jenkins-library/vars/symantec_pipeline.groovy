def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "vsphere"
      }
      parameters {
        //choice(choices: ['Staging'], description: 'chose environment', name: 'exec_environment')
        //choice(choices: ['51001', '51002'], description: 'application poet', name: 'app_port')
        string(name: 'deviceID', description: 'Symantec Device ID' )
      }
      stages{
        stage('call from Datapoint'){
          steps {
            container('chef-vsphere'){
            script{
              timeout(time: 180, unit: 'SECONDS') {
                 env.token1 = input (id: 'token1',
                 message: 'Proceed or Abort?',
                 parameters: [string(defaultValue: '', description: 'enter token', name: 'inputtoken1', trim: true)],
                 )
              }
              println env.token1
              datapointResp = noc_utils.symantecResponseCheck('elkproxybz01u',env.deviceID,env.token1)
              println datapointResp
            }
          }
        }
      }
      stage('call from Verizon'){
        steps {
          container('chef-vsphere'){
          script{
            timeout(time: 180, unit: 'SECONDS') {
               env.token2 = input (id: 'token1',
               message: 'Proceed or Abort?',
               parameters: [string(defaultValue: '', description: 'please enter a new token', name: 'inputtoken2', trim: true)],
               )
            }
            println env.token2
            verizonResp = noc_utils.symantecResponseCheck('elkproxyaz02u',env.deviceID,env.token2)
            println verizonResp

          }
        }
      }
    }
    stage('call from Rockville'){
      steps {
        container('chef-vsphere'){
        script{
          timeout(time: 180, unit: 'SECONDS') {
             env.token3 = input (id: 'token1',
             message: 'Proceed or Abort?',
             parameters: [string(defaultValue: '', description: 'please enter a new token', name: 'inputtoken3', trim: true)],
             )
          }
          println env.token3
          rockvilleResp = noc_utils.symantecResponseCheck('elasticproxyqz02u',env.deviceID,env.token3)
          println rockvilleResp

        }
      }
    }
  }
    stage('report'){
      steps {
        container('chef-vsphere'){
        script{
          println "datapoint response time: " +datapointResp
          println "verizon response time: "+verizonResp
          println "rockville response time: "+rockvilleResp
        }
      }
    }
  }
     }
  }
}
