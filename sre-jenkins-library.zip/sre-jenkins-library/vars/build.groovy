import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType
//import groovy.json.JsonSlurper

def docker_build_withoutScan(){
  container('dind'){
  withCredentials([usernameColonPassword(credentialsId: dockerCredentialID, variable: 'DOCKERPASS')]) {
  sh """
    cd $WORKSPACE/${env.application_name}
  """
  }
}
}

def gradle_build_withoutScan()
{
  def gradleHome= tool 'gradle5.2.1'
    withSonarQubeEnv('mysonar') {
      sh """ cd $WORKSPACE/${env.application_name} && $gradleHome/bin/gradle assemble -x test
  """
    }
}
def gradle_build_withScan()
{
  def gradleHome= tool 'gradle5.2.1'
  def scannerHome = tool 'sonar';
//sleep 400
    withSonarQubeEnv('mysonar') {
      sh """
      echo $gradleHome
      cd $WORKSPACE/${env.application_name} && $gradleHome/bin/gradle assemble -x test sonarqube -Dsonar.host.url=${env.SONAR_HOST_URL} -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.scm.provider=git
    """
  }
}

def nodejs_build()
{
if (env.application_name == 'medhx'){
sh """
  cd $WORKSPACE/${env.application_name}
  whoami
  #su -l root
  #apk update
  #apk add nodejs nodejs-npm git
  #apk add
  #apk update
  #npm install bower
  /node_modules/bower/bin/bower install --allow-root
  #npm install -g grunt-cli@1.2.0
  which grunt
  npm install grunt --save-dev
  grunt clean --force
  npm install -g
  #npm i grunt-sonar-runner
  #grunt sonarRunner:analysis
  #grunt test:build
  #if [ \$? != 0 ]; then
  #  echo "Unit tests failed"
  #  exit 1
  #else
  #  echo "UNIT-Tests passed!"
  #fi
  echo "############ grunt build ###################"
  grunt build
  #if [[ "${env.app_farm}" == "medhx" ]]; then
  echo "create deploy.js"
  #version=\$(cat package.json | grep version)
  version=${env.version_display}
  echo "version - \$version" 
  /usr/bin/env echo -en "app:medhx\n version:\$version" > app/deploy.js
 # fi

  /bin/tar -cvf medhx.tar app
  /bin/gzip -f medhx.tar
  """
}
else if (env.application_name == 'external'){ 
  sh """
  
  cd $WORKSPACE/${env.application_name}
  whoami
  which grunt
  npm install grunt --save-dev
  grunt clean --force
  npm install -g
  echo "############ grunt build ###################"
  grunt build
  cd release/release
  tar -cvzf pi2_toolbar.tar.gz pi2_toolbar
  ls -rlt
  cd $WORKSPACE/${env.application_name} 
  
  """
 } 

else
{
sh """
    cd $WORKSPACE/${env.application_name}
    whoami
    branch=${env.branch}
    node -v
    npm -version
    npm install
    echo 'Installing grunt..'
    npm install  grunt -g
    which grunt
    echo \$(git describe)
    version=\$(git describe --tags --always)
    echo "version - \$version"
    describe_version=\$(git describe)
    echo \$describe_version
    #npm i grunt-sonar-runner
    #grunt sonarRunner:analysis
    #if [[ "${env.app_farm}" != "webdev" ]]; then
      echo 'Running Unit Tests..'
      grunt test-continuous
      if [ \$? != 0 ]; then
      echo 'UNIT TESTS ARE FAILED..'
      exit 1
      else
      echo 'UNIT TESTS ARE SUCCESS..'
      fi
    #fi  
    echo 'Producing Artifacts..'
    ./node_modules/grunt-cli/bin/grunt compile
    echo 'Versioning strategy'
    echo 'git describe..'
    base_version=\$(echo \$describe_version  | cut -d- -f1 | sed -r 's/^.{1}//')
    commits=\$(echo \$describe_version | cut -d- -f2)
    hash_version=\$(echo \$describe_version | cut -d- -f3)
    build_version=\${commits}-\${hash_version}
    version=\${base_version}-\${build_version}
    echo \$PATH
    /usr/bin/env echo -en "app:Rcopia Web\nArtifact built at:\$(date)\nbranch:\$branch\nversion:\$base_version\nby build:\$build_version" > app/deploy.js
    sed -i 's/'{#version}'/'\${base_version}'/g' app/index.html
    tar -cvzf ../rcopia4x_web.tar.gz .
    echo "buildversion=webui_ref_\${version}_\${BUILD_ID}" > ../envVars.properties
    echo version=\$(echo \$version) >> ../envVars.properties
  """
}
}

def widgets_build()
{
sh """
    cd $WORKSPACE/${env.application_name}
    whoami
    branch=${env.branch}
    node -v
    npm -version
    npm install
    echo 'Installing grunt..'
    npm install  grunt -g
    which grunt
    echo \$(git describe)
    version=\$(git describe --tags --always)
    echo "version - \$version"
    describe_version=\$(git describe)
    echo \$describe_version
    #npm i grunt-sonar-runner
    #grunt sonarRunner:analysis
    echo 'Running Unit Tests..'

    echo 'Producing Artifacts..'
    ./node_modules/grunt-cli/bin/grunt compile
    echo 'Versioning strategy'
    echo 'git describe..'
    base_version=\$(echo \$describe_version  | cut -d- -f1 | sed -r 's/^.{1}//')
    commits=\$(echo \$describe_version | cut -d- -f2)
    hash_version=\$(echo \$describe_version | cut -d- -f3)
    build_version=\${commits}-\${hash_version}
    version=\${base_version}-\${build_version}
    echo \$PATH
    /usr/bin/env echo -en "app:Rcopia Web\nArtifact built at:\$(date)\nbranch:\$branch\nversion:\$base_version\nby build:\$build_version" > app/deploy.js
    tar -cvzf ../rcopia4x_widgets.tar.gz app/cdn/*
    echo "buildversion=webui_ref_\${version}_\${BUILD_ID}" > ../envVars.properties
    echo version=\$(echo \$version) >> ../envVars.properties
  """
}



def gradle_only_scan()
{
  def scannerHome = tool 'sonar';
  def gradleHome= tool 'gradle5.2.1'
  withSonarQubeEnv('mysonar') {
     sh "cd $WORKSPACE/${env.application_name} && $gradleHome/bin/gradle sonarqube  -Dsonar.host.url=${env.SONAR_HOST_URL} -Dsonar.projectName=${env.app_platform}-${env.application_name} -Dsonar.projectKey=${env.app_platform}-${env.application_name} -Dsonar.scm.provider=git "

   }

}
//-DskipTests=true
def maven_build_withoutScan(MAVEN_SETTINGS_FILE){
  def mavenHome = tool 'maven';
  if ( "${env.app_platform}" == "pi")
  {
  configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
    sh """
      ls "$WORKSPACE/${env.application_name}"
      ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install
      if [[ "${env.mvn_extra_deploy}" == "true" ]]; then
        echo "Extra maven deploy step"
        echo "${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}"
        ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}
      fi
          """
          }
  }
  else
  {
  configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
    sh """
      ls "$WORKSPACE/${env.application_name}"
      ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean package  -DskipTests=true
          """
}
  }

}

def maven_build_withScan(MAVEN_SETTINGS_FILE){
  def mavenHome = tool 'maven'
  //def scannerHome = tool 'sonar';
 //withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """#!/bin/bash
          echo "$mavenHome"
          #ls "$WORKSPACE/${env.application_name}"
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean package sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=git
          whoami
          ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install sonar:sonar -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}   -Dsonar.scm.provider=git
          ls -lart
          if [[ "${env.mvn_extra_deploy}" == "true" ]]; then
            echo "Extra maven deploy step"
            echo "${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}"
            ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}
          fi
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install
          mv $WORKSPACE/${env.jar_location}/*.${env.type} $WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}
              """
    }
  //}
}

def maven_build_withScan_lib(MAVEN_SETTINGS_FILE){
  def mavenHome = tool 'maven'
  //def scannerHome = tool 'sonar';
 //withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """#!/bin/bash
          echo "$mavenHome"
          #ls "$WORKSPACE/${env.application_name}"
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean package sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=git
          whoami
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install sonar:sonar -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}   -Dsonar.scm.provider=git
          ls -lart
          #${mavenHome}/bin/mvn -B -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML versions:set -DgenerateBackupPoms=false -DnewVersion=${env.version}
          echo "run clean and install"

          ${mavenHome}/bin/mvn -B -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install ${env.skipTests}

          if [ \$? -ne 0 ]; then
            echo "clean and install step failed"
            exit 1
          fi
          echo "run deploy"
          ${mavenHome}/bin/mvn -B -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML deploy -DskipTests=true
          #mv $WORKSPACE/${env.jar_location}/*.${env.type} $WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}
              """
    }
  //}
}

def maven_only_scan(MAVEN_SETTINGS_FILE){
  scannerHome = tool 'sonar'
  def mavenHome = tool 'maven';
  withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """
          ls "$WORKSPACE/${env.application_name}"
          ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml clean -s $MAVEN_SETTINGS_XML  sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}"  -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=git -Dsonar.java.binaries=.
              """
    }
  }
}

def gear_build_withoutScan(MAVEN_SETTINGS_FILE,build_number){
  def mavenHome = tool 'maven';
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """
          ls "$WORKSPACE/${env.application_name}"
          cd "$WORKSPACE/${env.application_name}"
          #bash quickBuild.sh
          BUILD_OPTS="--activate-profiles traditional-deployment"
          BUILD_OPTS="\${BUILD_OPTS} -DbuildNumber=${build_number}"

          chmod a+x gradlew
          ./gradlew --no-daemon --stacktrace --info --build-file gradle/distribute-base.gradle cleanMavenLocalArtifacts

          chmod a+x mvnw
          ./mvnw help:active-profiles clean install -s $MAVEN_SETTINGS_XML \${BUILD_OPTS}

        """
    }
}

def gear_build_withScan(MAVEN_SETTINGS_FILE,build_number){
  def mavenHome = tool 'maven';
  withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """
          ls "$WORKSPACE/${env.application_name}"
          cd "$WORKSPACE/${env.application_name}"
          #bash quickBuild.sh
          BUILD_OPTS="--activate-profiles traditional-deployment"
          BUILD_OPTS="\${BUILD_OPTS} -DbuildNumber=${build_number}"

          chmod a+x gradlew
          ./gradlew --no-daemon --stacktrace --info --build-file gradle/distribute-base.gradle cleanMavenLocalArtifacts

          chmod a+x mvnw
          ./mvnw help:active-profiles clean install -s $MAVEN_SETTINGS_XML \${BUILD_OPTS} sonar:sonar -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=git

        """
       }
    }
}

def sonar_scan_only(app_platform,applicatio_nname)
{
    def scannerHome = tool 'stand-alone-330'
    withSonarQubeEnv('mysonar') {
      sh """
      sed -i 's/use_embedded_jre=true/use_embedded_jre=false/g' ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner
      ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner -Dsonar.projectName=${app_platform}-${application_name} -Dsonar.projectKey=${app_platform}-${application_name} -Dsonar.scm.provider=git -Dsonar.sources=. -Dsonar.java.binaries=**/src/** -Dsonar.inclusions=**/src/com/drfirst/**
      """
    }
}

def sonar_scan_all(app_platform,application_name)
{
    def scannerHome = tool 'stand-alone-330'
    withSonarQubeEnv('mysonar') {
      sh """
      sed -i 's/use_embedded_jre=true/use_embedded_jre=false/g' ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner
      ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner -Dsonar.projectName=${app_platform}-${application_name} -Dsonar.projectKey=${app_platform}-${application_name} -Dsonar.scm.provider=git -Dsonar.sources=. -Dsonar.java.binaries=**/src/**
      """
    }
}


def prepare_env()
{
      jsonFile1 = "$WORKSPACE/details.json"
      def json1 = readJSON file: jsonFile1
        //application level data

      env.environment = json1['application']['environment']
      //buile tool settings
      env.build_tool = json1['build_tool']['name']
      env.MAVEN_SETTINGS_FILE = json1['build_tool']['MAVEN_SETTINGS_FILE']
      //nexus related details
      env.nexus_repository = json1['nexus']['nexus_repository']
      env.artifactId = json1['nexus']['artifactId']
      env.classifier = json1['nexus']['classifier']
      env.jar_location = json1['nexus']['jar_location']
      env.type = json1['nexus']['type']
      //sonar related details
      env.SONAR_HOST_URL = "http://cicd.dfcorp.drfirst.com/sonar"
      env.gitCredentialID = "svc-automation"
      env.jar_name = json1['nexus']['jar_name']
      env.groupID = json1['nexus']['groupID']
      env.extraRepo = false
      env.dev_only_pipeline = "false"
      env.qa_only_pipeline = "false"
      env.repoJson = json1['scan_repo_list']
      env.skipTests=""
      if (json1['scan_repo_list'][0]['repo_url'] != "")
      {
        echo "extra repo is true"
        env.extraRepo = true
        totalRepo = json1['scan_repo_list'].projects.size()
        println "count" + totalRepo
      }
      env.approver=json1['approver']
      env.mvn_extra_deploy="false"
      if (json1['build_tool']['mvn_extra_deploy'] == "true")
      {
        echo "extra deploy is true"
        env.mvn_extra_deploy="true"
        env.mvn_extra_deploy_cmd = json1['build_tool']['mvn_extra_deploy_cmd']
        println env.mvn_extra_deploy_cmd
      }
      if (json1['build_tool']['skipTests'] == "true")
      {
        env.skipTests="-DskipTests=true"
        println env.skipTests
      }
}

def prepare_docker_env()
{
  jsonFile1 = "$WORKSPACE/details.json"
  def json1 = readJSON file: jsonFile1

  env.dev_registry = json1['docker']['dev_registry']
  env.prod_registry = json1['docker']['prod_registry']
  env.dockerFilePath =  json1['docker']['dockerFilePath']
  env.dockerContext = json1['docker']['dockerContext']
  env.version_file = json1['docker']['version_file']
  env.prep_id = ""
}

def getMedhxUiVersion()
{
	sh(script:""" cd $WORKSPACE/${env.application_name}  && cat package.json |jq -r .version """,returnStdout: true).trim()
}

def getWebUiVersion()
{
	sh(script:""" cd $WORKSPACE/${env.application_name}  && git describe --tags --always | cut -d- -f1 | tr -d '\n' | sed -r 's/^.{1}//' """,returnStdout: true)
}

def getVersionFromPom()
{
	//sh(script:""" cd $WORKSPACE/${env.application_name}  && grep '<version>' pom.xml | head -2 | tail -1 | sed -e 's/<version>//; s/<\\/version>//;' | tr -d '[[:space:]]'  """,returnStdout: true)
  sh(script:""" cd $WORKSPACE/${env.application_name}  && xmllint --xpath "/*[local-name() = 'project']/*[local-name() = 'version']/text()" pom.xml  """,returnStdout: true)
}

def getVersionFromCfg(app_type)
{
  if (app_type == 'ss2web' || app_type == 'smartpharmacy'){
    sh(script:""" cd $WORKSPACE/${env.application_name}  &&  awk -F = '/^APP_VERSION/{print \$2}' ${env.version_file} """,returnStdout: true)
  }
  else if (app_type == 'ss2model'){
    sh(script:""" cd $WORKSPACE/${env.application_name}  &&  awk -F = '/^MODEL_VERSION/{print \$2}' ${env.version_file} """,returnStdout: true)
  }
  else if (app_type == 'ss2switch'){
    sh(script:""" cd $WORKSPACE/${env.application_name}  &&  awk -F = '/^SWITCH_VERSION/{print \$2}' ${env.version_file} """,returnStdout: true)
  }
  else if (app_type == 'smartstring'){
    sh(script:""" cd $WORKSPACE/${env.application_name}  && cat ${env.version_file} |jq -r .APP_VERSION """,returnStdout: true).trim()
  }


}

def getPrepIdFromCfg()
{
  sh(script:""" cd $WORKSPACE/${env.application_name}  &&  awk -F = '/^PREP_VERSION/{print \$2}' ${env.version_file} """,returnStdout: true)
}


def getVersionFromGear()
{
    if (env.application_name == 'gaudit'){
	   sh(script:""" cd $WORKSPACE/${env.application_name}  && grep -A1 '<packaging>pom' pom.xml | tail -1 | sed -e 's/<version>//; s/<\\/version>//;' | tr -d '[[:space:]]'  """,returnStdout: true)
    }
    else
    {
       // sh(script:""" cd $WORKSPACE/${env.application_name}  && grep -A1 '<packaging>war' pom.xml | tail -1 | sed -e 's/<version>//; s/<\\/version>//;' | tr -d '[[:space:]]'  """,returnStdout: true)
       sh(script:""" cd $WORKSPACE/${env.application_name}  && xmllint --xpath "/*[local-name() = 'project']/*[local-name() = 'version']/text()" pom.xml  """,returnStdout: true)
    }
}


def getVersion()
{
	sh(script:""" cd $WORKSPACE/${env.application_name}  && git describe --always | tr -d '[[:space:]]' """,returnStdout: true)
}
def getVersionFromDatabag(dev_repo,app_farm)
{
    withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
  	git config --global user.email 'svc-devops'
    git config --global user.name 'svc-devops@drfirst.com'
    cd $WORKSPACE
    git clone https://\${GITPASS}@git.drfirst.com/devops-se/${dev_repo}.git
    cd ${dev_repo}
    """
    jsonFile1 = "$WORKSPACE/${dev_repo}/data_bags/app_${app_farm}/dev.json"
    def json1 = readJSON file: jsonFile1
    echo "${json1} - json1"
    env.databagVersion = json1['version']
    env.databagBuild = json1['build']
    sh """
    rm -rf cd $WORKSPACE/${env.dev_repo}
    """
  }
}

def nexusCleanup(app_type,version)
{
  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
  sh """
  curl -v --request DELETE  --user "\${NEXUSPASS}"  --silent  https://nexusrepo.drfirst.com/nexus/content/repositories/system-engg-artifacts/${app_type}/${app_type}/${version}/${app_type}-${version}-SNAPSHOT.jar
  """
  }
}


def publishToNexus(appliction_name,version,repository,cred,artifactId,classifier,file_path,type,groupId)
{

  println "hello ${file_path}"
  nexusArtifactUploader(
      nexusVersion: 'NEXUS3',
      protocol: 'HTTPS',
      nexusUrl: 'nexusrepo.drfirst.com/nexus',
      groupId: "${groupId}",
      version: "${version}",
      repository: "${repository}",
      credentialsId: "${cred}",
      artifacts: [[
         artifactId: "${artifactId}",
         classifier: "${classifier}",
         file: "${file_path}",
        //  file: "/home/jenkins/workspace/uhc-ccda-funnel/uhc-ccda-funnel/target/uhc-ccda-funnel.war",
          type: "${type}",
      ]]
   )

}
def sonarCheck(type)
{
  sh(script:"""curl "${env.SONAR_HOST_URL}/api/issues/search?componentKeys=${env.app_platform}-${env.application_name}&types=$type" | jq .total """,returnStdout: true)
}

def updateJsonVersionDevOnly(environment,pipeline_branch,version,build_name,application_name,cred_id)
{
  if (environment == 'dev') {
    environment_name = "qa"
  }

  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
      cd /tmp
      repo_url=${application_name}
      rm -rf \$repo_url
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git
      cd \$repo_url
      git branch -a |  cut -d '/' -f3 > ../branchlist

      cat ../branchlist
      cat ../branchlist | grep ${pipeline_branch} > ../branches.txt
      cat  ../branches.txt
      git config --global user.email 'svc-devops'
      git config --global user.name 'svc-devops@drfirst.com'
      #version="\\\"version\\\":\\\"`echo \$version`\\\","
      version="version=\\\"`echo \$version`\\\""
      version_display="build_name=\\\"`echo ${build_name}`\\\""

      while read line; do
        echo \$line
        git checkout \$line
        #sed -i "1,/\\\"version.*/s/\\\"version.*/`echo \$version`/g"   "details.json"
        #sed -i "s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/version.*/s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/build_name.*/s/build_name.*/`echo \$version_display`/g"  "Jenkinsfile"
        if [ -n \"\$(git status --porcelain)\" ]; then
          echo "change"
          git commit -am "version update"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git HEAD:\$line
        else
          echo 'no changes';
        fi
      done < ../branches.txt

      while read line; do
        eval "curl -X POST http://cicd.dfcorp.drfirst.com/job/${env.app_platform}-${application_name}/job/\${line}/build --user 'svc-devops:119d7e02c440dc25d5a553fcf89ae5736d'"
      done < ../branches.txt

    """
  }
}

def updateJsonVersionDedicateBranch(environment,pipeline_branch,version,build_name,application_name,cred_id)
{
  if (environment == 'dev') {
    environment_name = "qa"
  } else if(environment == 'qa') {
    environment_name = "staging"
  } else if(environment == 'staging') {
    environment_name = "prod"
  }
  else if(environment == 'prod') {
    environment_name = ""
  }
  //override for external widget deployment
  if (application_name == 'external'){
    env.app_platform = 'rcopia4x'
    application_name = 'webui'
  }

  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
      cd /tmp
      if [[ "${application_name}" == "external" ]]; then
        repo_url="webui"
      else
        repo_url=${application_name}
      fi
      rm -rf \$repo_url
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git
      cd \$repo_url
      git branch -a |  cut -d '/' -f3 > ../branchlist
      echo "$pipeline_branch" | tr ',' '\n' > ../branches.txt
      while read line; do
        cat ../branchlist | grep "\${line}"
        if [ \$? -ne 0 ]; then
          break
        fi
      done < ../branches.txt
      #cat ../branchlist
      #cat ../branchlist | grep ${pipeline_branch} > ../branches.txt
      cat  ../branches.txt
      git config --global user.email 'svc-devops'
      git config --global user.name 'svc-devops@drfirst.com'
      #version="\\\"version\\\":\\\"`echo \$version`\\\","
      version="version=\\\"`echo \$version`\\\""
      version_display="build_name=\\\"`echo ${build_name}`\\\""

      while read line; do
        echo \$line
        git checkout \$line
        #sed -i "1,/\\\"version.*/s/\\\"version.*/`echo \$version`/g"   "details.json"
        #sed -i "s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/version.*/s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/build_name.*/s/build_name.*/`echo \$version_display`/g"  "Jenkinsfile"
        if [ -n \"\$(git status --porcelain)\" ]; then
          echo "change"
          git commit -am "version update"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git HEAD:\$line
        else
          echo 'no changes';
        fi
        sleep 5
      done < ../branches.txt

      while read line; do
        eval "curl -X POST http://cicd.dfcorp.drfirst.com/job/${env.app_platform}-${application_name}/job/\${line}/build --user 'svc-devops:119d7e02c440dc25d5a553fcf89ae5736d'"
        sleep 10
      done < ../branches.txt

    """
  }
}

def updateJsonVersion(environment,version,build_name,application_name,cred_id)
{
  if (environment == 'dev') {
    environment_name = "qa"
  } else if(environment == 'qa') {
    environment_name = "staging"
  } else if(environment == 'staging') {
    environment_name = "prod"
  }
  else if(environment == 'prod') {
    environment_name = ""
  }

  pipeline_name = application_name.replaceAll("[\\.-]","_").replaceAll("\"","")
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
      cd /tmp
      repo_url=${application_name}
      rm -rf \$repo_url
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git
      cd \$repo_url
      git branch -a |  cut -d '/' -f3 > ../branchlist

      cat ../branchlist
      cat ../branchlist | grep ${environment_name} | grep -v dev | grep -v widgets > ../branches.txt
      cat  ../branches.txt
      git config --global user.email 'svc-devops'
      git config --global user.name 'svc-devops@drfirst.com'
      #version="\\\"version\\\":\\\"`echo \$version`\\\","
      version="version=\\\"`echo \$version`\\\""
      version_display="build_name=\\\"`echo ${build_name}`\\\""

      while read line; do
        echo \$line
        git checkout \$line
        #sed -i "1,/\\\"version.*/s/\\\"version.*/`echo \$version`/g"   "details.json"
        #sed -i "s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/version.*/s/version.*/`echo \$version`/g"  "Jenkinsfile"
        sed -i "1,/build_name.*/s/build_name.*/`echo \$version_display`/g"  "Jenkinsfile"
        if [ -n \"\$(git status --porcelain)\" ]; then
          echo "change"
          git commit -am "version update"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${repo_url}.git HEAD:\$line
        else
          echo 'no changes';
        fi
      done < ../branches.txt

      while read line; do
        eval "curl -X POST http://cicd.dfcorp.drfirst.com/job/${env.app_platform}-${pipeline_name}/job/\${line}/build --user 'svc-devops:119d7e02c440dc25d5a553fcf89ae5736d'"
      done < ../branches.txt

    """
  }
}
def gitCommitPush(gitCredentialID,application_name){

  //add all files and commit all changes and then push
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
      pwd
      git_remote_url=`git config --get remote.origin.url`
      #git add .
      if [ -n \"\$(git status --porcelain)\" ]; then
        echo "changess"
        git config --global user.email 'svc-devops'
        git config --global user.name 'svc-devops@drfirst.com'
        git commit -am "version update"
        git config --global push.default simple && \
        git push https://\$GITPASS@git.drfirst.com/sysops/pipelines/${application_name}.git HEAD:$GIT_BRANCH
      else
        echo 'no changes';
      fi
    """
  }
}
def updateVersionJson(version)
{
  sh """
    pwd
    version="\\\"version\\\":\\\"`echo ${version}`\\\","
    sed -i "1,/\\\"version.*/s/\\\"version.*/`echo \$version`/g"   "details.json"
    """
}
def updateStage(stage)
{
  sh """
    last_successfull_stage="\\\"last_successfull_stage\\\":\\\"`echo ${stage}`\\\","
    sed -i "1,/\\\"last_successfull_stage.*/s/\\\"last_successfull_stage.*/`echo \$last_successfull_stage`/g"   "details.json"
    """
}

def versionupdate_databag(repo_name,build_number,app_farm,environment,cred_id)
{
  if (app_farm == 'epcs2-ui') {
	app_farm='ui'
	}
  if (app_farm == 'external') {
	app_farm='pitoolbar'
	}
	println app_farm
  println repo_name
  println WORKSPACE
  println env.WORKSPACE
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
  sh """
  echo $workspace
  echo $repo_name
  app_farm=${app_farm}
  repo_name=${repo_name}
  environment=${environment}
  build_number=${build_number}
	git config --global user.email 'svc-devops'
  git config --global user.name 'svc-devops@drfirst.com'

  cd $WORKSPACE
  rm -rf ${repo_name}
  git clone https://\${GITPASS}@git.drfirst.com/devops-se/${repo_name}.git
  cd ${repo_name}

  git config remote.origin.url https://\${GITPASS}@git.drfirst.com/devops-se/${repo_name}.git
  git checkout master
  if echo "${build_number}" | grep -q "-"; then
    echo "build number  via CI"
    version=`echo "${build_number}" | rev | cut -d"-" -f 3- | rev`
    build=`echo "${build_number}" | rev | cut -d"-" -f -2 | rev`
  else
    echo "build number not via CI"
    version=`echo "${build_number}" | rev | cut -d"." -f 2- | rev`
    build=`echo "${build_number}" | rev | cut -d"." -f -1 | rev`
  fi;
#  version="\\\"version\\\":\\\"`echo \$version`\\\","
#  build="\\\"build\\\":\\\"`echo \$build`\\\""
  echo "testing jq"

  jq ".version = \\\"\$version\\\"| .build=\\\"\$build\\\"" data_bags/app_${app_farm}/${environment}.json >> test.json
  cat test.json
  mv test.json data_bags/app_${app_farm}/${environment}.json
  if [ -n \"\$(git status --porcelain)\" ]; then
    git commit -am "version update"
    git push origin master
    knife data bag  from file app_${app_farm}  data_bags/app_${app_farm}/${environment}.json
    echo "change"
  else
    echo 'no changes';
  fi
  rm -rf $WORKSPACE/${repo_name}

"""
  }
}



def cloneExtraRepo()
{
  jsonFile1 = "$WORKSPACE/details.json"
  def json1 = readJSON file: jsonFile1
  echo "${json1} - json1"
  totalRepo = json1['scan_repo_list'].size()
  println "count" + totalRepo
  for(int i = 0;i<totalRepo;i++) {

    dir("$WORKSPACE/${env.application_name}/${i}") {
        git(
          url: json1['scan_repo_list'][i]['repo_url'],
          credentialsId: env.gitCredentialID,
            branch: json1['scan_repo_list'][i]['branch']
        )
    }
  }
}

def versionInput() {
    timeout(time: 180, unit: 'SECONDS') {
       env.version = input (id: 'inputVersion1',
       message: 'Proceed or Abort?',
       parameters: [string(defaultValue: '', description: 'enter application version', name: 'inputVersion', trim: true)],
       submitter: "${env.approver}")
    }
    //echo ("version InputVersion1 - ${env.approver}--" + inputVersion1['inputVersion'])
    //  env.version="${inputVersion}"
    println env.version
    println env.version.getClass()
    //echo env.inputVersion1.inputVersion

}

def branchInput() {
    timeout(time: 180, unit: 'SECONDS') {
       env.branch = input (id: 'inputBranch1',
       message: 'Proceed or Abort?',
       parameters: [string(defaultValue: '', description: 'enter branch name', name: 'inputBranch', trim: true)],
       submitter: "${env.approver}")
    }
    println env.branch
    println env.branch.getClass()
}

def dropdownBranchInput() {
    timeout(time: 180, unit: 'SECONDS') {
       env.branch = input message: 'Please choose the branch to build ', ok: 'Validate!',
       parameters: [choice(name: 'BRANCH_NAME', choices: ['develop','qa'], description: 'Branch to build?')],
       submitter: "${env.approver}"
    }
    println env.branch
    println env.branch.getClass()
}

def baseVersionGen(fullVersion,beseVersionLength){
  versionSplits = fullVersion.tokenize(".")
  println versionSplits
  baseVersion = versionSplits[0]
  for (i = 1; i < beseVersionLength; i++){
    baseVersion += ".${versionSplits[i]}"
  }
  println baseVersion
  return baseVersion
}

def checkGitCommit(gitCommitHash){
  jsonFile1 = "$WORKSPACE/details.json"
  def json1 = readJSON file: jsonFile1

  println gitCommitHash
  println json1['last_commit']

  if (json1['last_commit'] == gitCommitHash){
    error("Git commit does not change, abort the build to prevent duplicate artifact.")
  } else {
    println "Git commit check passed"
  }
}

def getBuildNumber(baseVersion)
{
      jsonFile1 = "$WORKSPACE/details.json"
      def json1 = readJSON file: jsonFile1

      def last_build = 0
      json1['build_numbers'].each {k,v ->
        if (k == baseVersion){
          last_build = v
        }
      }
      println last_build
      return last_build
}

def getNewBuildJson(baseVersion,newBuildNumber,gitCommitHash)
{
      jsonFile1 = "$WORKSPACE/details.json"
      def json1 = readJSON file: jsonFile1

      def newJson = new JsonBuilder(json1)

      def versionCheck = 0
      //check to see if version exist
      json1['build_numbers'].each {k,v ->
        if (k == baseVersion){
          versionCheck += 1
        }
      }
      //update json based on the check
      if (versionCheck > 0) {
        //update current
        newJson.content['build_numbers'][baseVersion] = newBuildNumber
      } else {
        newJson.content['build_numbers'].put(baseVersion,newBuildNumber)
      }

      //update last commit hash
      if (gitCommitHash){
        newJson.content['last_commit'] = gitCommitHash
      }

      def outJson = groovy.json.JsonOutput.toJson(newJson.content)
      outJson = groovy.json.JsonOutput.prettyPrint(outJson)
      outJson = outJson.replaceAll(/\"/,/\\\"/)

      println outJson
      return outJson
}

def getBuildFromGit()
{
	sh(script:""" cd $WORKSPACE/${env.application_name}  && git describe --tags --always | cut -d- -f2-  | tr -d '\n' """,returnStdout: true)
}

def ilac_build(build_env)
{
println("ilac build")
  sh """
   #sleep 3600
   cd $WORKSPACE/${env.application_name}
   echo "${build_env} -- env"
   npm_build_env="${build_env}"
   #if [ \${npm_build_env}="dev" ]; then
    #npm_build_env="qa"
   #else
    #echo "$build_env -- else "
   #fi
   npm install
   #npm run build:\${npm_build_env}
   npm run build
   #/bin/tar -czvf ${env.application_name}-\${npm_build_env}.tar.gz build
   /bin/tar -czvf ${env.application_name}.tar.gz build
  """
}

def huddleweb_build()
{
sh """
  cd $WORKSPACE/${env.application_name}
  whoami
  node -v
  npm -version
  npm install
  echo 'Installing pm2...'
  npm install pm2 -g
  tar -cvzf ../huddleweb.tar.gz .
  """
}

def nodejs_pswbuild()
{
sh """
  cd $WORKSPACE/${env.application_name}/mock-emr
  whoami
  node -v
  npm -version
  npm install
  npm run build
  rm -rf ../sof-widgets/src/main/webapp/mockemr/*
  mkdir -p ../sof-widgets/src/main/webapp/mockemr/
  cp -r build/* ../sof-widgets/src/main/webapp/mockemr/
  cd $WORKSPACE/${env.application_name}/widget-ui
  npm install
  npm run build
  mkdir -p ../sof-widgets/src/main/webapp/widget-ui/
  rm -rf ../sof-widgets/src/main/webapp/widget-ui/*
  cp -r build/* ../sof-widgets/src/main/webapp/widget-ui/
  """
}

def psw_maven_build_withScan(MAVEN_SETTINGS_FILE){
  def mavenHome = tool 'maven'
  //def scannerHome = tool 'sonar';
 //withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """#!/bin/bash
          echo "$mavenHome"
          #ls "$WORKSPACE/${env.application_name}"
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean package sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=gi
          whoami
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install sonar:sonar -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}   -Dsonar.scm.provider=git
          ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install
          ls -lart
          if [[ "${env.mvn_extra_deploy}" == "true" ]]; then
            echo "Extra maven deploy step"
            echo "${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}"
            ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML ${env.mvn_extra_deploy_cmd}
          fi
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install
          mv $WORKSPACE/${env.jar_location}/*.${env.type} $WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}
              """
    }
  //}
}

def angular_build(app_version)
{
sh """
  cd $WORKSPACE/${env.application_name}
  whoami
  node -v
  pwd
  export NG_CLI_ANALYTICS=ci && npm link
  npm run build
  cd dist/angular
  echo "app: ${env.application_name}" > deploy.js
  echo "version: ${app_version}" >> deploy.js
  tar -cvzf $WORKSPACE/${env.application_name}/${env.application_name}.tar.gz .
  """
}


def svnToGit(application_name,svn_url,git_url,gitCredentialID,version)
{
  sh """
  ls -l $WORKSPACE/${application_name}
  echo $version
  """
  dir("$WORKSPACE/${application_name}/svn") {
    checkout([$class: 'SubversionSCM',
            additionalCredentials: [],
            excludedCommitMessages: '',
            excludedRegions: '',
            excludedRevprop: '',
            excludedUsers: '',
            filterChangelog: false,
            ignoreDirPropChanges: false,
            includedRegions: '',
            locations: [[credentialsId: 'svn-automation',
                         depthOption: 'infinity',
                         ignoreExternalsOption: true,
                         local: '.',
                         remote: "${svn_url}"]],
            quietOperation: true, workspaceUpdater: [$class: 'UpdateUpdater']])
  }

  dir("$WORKSPACE/${application_name}/config") {
      git(
        url: "${git_url}",
        credentialsId: "${gitCredentialID}",
        branch: "master"
      )
    }
    sh """
    ls -l $WORKSPACE/${application_name}/svn
    ls -l $WORKSPACE/${application_name}/config
    """

  // sh """
  // cd $WORKSPACE/${application_name}/config
  // rm -rf *
  // cp -fr ../svn/* .
  // git status
  // git add .
  // if [ -n "$(git status --porcelain)" ]; then
  // 	git commit -m "pushing the pdmp config file from svn to git and tagging with the version $version"
  // else
  // 	echo 'no changes';
  // fi
  // 	git tag v\$version --force
  // 	git push
  // 	git push origin v\$version --force
  // """
}

def maven_build_iish(MAVEN_SETTINGS_FILE){
  def mavenHome = tool 'maven'
  //def scannerHome = tool 'sonar';
 //withSonarQubeEnv('mysonar') {
      configFileProvider([configFile(fileId: "$MAVEN_SETTINGS_FILE", variable: 'MAVEN_SETTINGS_XML')]) {
        sh """#!/bin/bash
          echo "$mavenHome"
          #ls "$WORKSPACE/${env.application_name}"
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean package sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}  -Dsonar.scm.provider=git
          whoami
          chmod 777 -R $WORKSPACE/${env.application_name}
          echo "changing permission"
          ls -lart $WORKSPACE/${env.application_name}
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}   -Dsonar.scm.provider=git > maven.log
          ${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install sonar:sonar -DskipTests=true -Dsonar.projectName="${env.app_platform}-${env.application_name}" -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL}   -Dsonar.scm.provider=git 
          ls -lart
          #${mavenHome}/bin/mvn  -f $WORKSPACE/${env.application_name}/pom.xml -s $MAVEN_SETTINGS_XML clean install
          mv $WORKSPACE/${env.jar_location}/*.${env.type} $WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}
              """
    }
  //}
}

def getPackagingFromGear(){
    sh(script:""" cd $WORKSPACE/${env.application_name}  && xmllint --xpath "/*[local-name() = 'project']/*[local-name() = 'packaging']/text()" pom.xml  """,returnStdout: true)
}


def gradle_build_jacocoreport()
{
  def gradleHome= tool 'gradle4.4'
  def scannerHome = tool 'sonar';
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
  	git config --global user.email 'svc-devops'
    git config --global user.name 'svc-devops@drfirst.com'
    cd $WORKSPACE/${env.application_name}
    rmdir cnf
    git clone https://\${GITPASS}@git.drfirst.com/rcopia4x/cnf.git
    
    """
  }
  //sleep 400
  // gradle build with jacoco test report
    withSonarQubeEnv('mysonar') { 
      catchError(buildResult: 'SUCCESS', stageResult: 'FAILURE') {
      sh """
      echo $gradleHome
      cd $WORKSPACE/${env.application_name} && $WORKSPACE/${env.application_name}/lib/gradle-3.5/bin/gradle clean bndbuild test jacocoTestReport jacocoMerge sonarqube -Dsonar.projectKey="${env.app_platform}-${env.application_name}" -Dsonar.host.url=${env.SONAR_HOST_URL} -Dsonar.projectName="${env.app_platform}-${env.application_name}" --continue --stacktrace
  
	"""
  }
    }

}

def getTestrailurl(project_id,branch){

  sh(script:""" curl -X GET "https://drfirstqa.testrail.io/index.php?/api/v2/get_runs/$project_id" -H "authorization: Basic cWFhdXRvbWF0aW9uQGRyZmlyc3QuY29tOjkzb1pvV1pTT3FrYXBaMGguZnB6LUQ1eVgwS25pbkJEcS9jRXlLWXlZ" | jq -r ".[] | select(.name==\\"\$branch\\") | .url" """,returnStdout: true)
}

