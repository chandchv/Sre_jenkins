def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      agent any
      stages{
        stage(load){
          steps{
            script{
              new_pipeline.create_repo()            
            }
          }
        }
      }
    }
  }
