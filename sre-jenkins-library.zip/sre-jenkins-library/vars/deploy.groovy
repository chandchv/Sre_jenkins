import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType

def prepare_env()
{
      jsonFile1 = 'details.json'
      def json1 = readJSON file: jsonFile1
    //  env.version = json1['version']
      env.autodeploy_1stmachine = json1['autodeploy_1stmachine']
      env.autodeploy_allmachine = json1['autodeploy_allmachine']
      env.last_successfull_stage = json1['last_successfull_stage']
      env.primary_farm = json1['primary_farm']
      env.approver = json1['approver']
      println "primary_farm set"
      println json1['primary_farm']
      println "primary_farm done"
}

def deploy1stmachine(environment,app_platform,app_type,app_farm,primaryServerCount)
{
  if (environment == 'dev') {
    env.promenv='qa'
    env.environment_name = "Development"
    println "environment_name dev - ${env.environment_name}"
  } else if(environment == 'qa') {
    env.promenv='staging'
    env.environment_name = "QA"
    println "environment_name qa - ${env.environment_name}"
  } else if(environment == 'staging') {
    env.promenv='prod'
    env.environment_name = "Staging"
    println "environment_name staging - ${env.environment_name}"
  }
  else if(env.environment == 'prod') {
    env.promenv='prod'
    env.environment_name = "Production"
    println "environment_name prod - ${env.environment_name}"
  }
  else if(env.environment == 'demo') {
    env.promenv='prod'
    env.environment_name = "Demo"
    println "environment_name prod - ${env.environment_name}"
  }
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
      sh """
      curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${env.environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"primary\\", \\"app_farm\\":\\"${app_farm}\\" }" |  jq '.host_info[0]' | jq .'host_name' > machine_list
      cat machine_list| while read line || [[ -n "\$line" ]]; do
      line="\${line//\\"/}"
      machine_name=\$line
      echo \$machine_name
      echo "host_name=\$machine_name" > build.properties
      # eval "knife node show \$machine_name"
      if [[ '${primaryServerCount}' == '1' ]]; then
        if [[ '${app_type}' == 'external' ] && [ '${app_platform}' != 'pi' ]]; then
          eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":true }}' | sudo chef-client -o 'recipe[df_nginx::external_widgets]' -j /dev/stdin\\\""
        else
          eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":true }}' | sudo chef-client -j /dev/stdin\\\""
        fi
      else
        if [[ '${app_type}' == 'external' ] && [ '${app_platform}' != 'pi' ]]; then
          eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":true }}' | sudo chef-client -o 'recipe[df_nginx::external_widgets]' -j /dev/stdin\\\""
        else
          #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date && whoami \\\""
          eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":false }}' | sudo chef-client -j /dev/stdin\\\""
        fi
      fi
      #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":false }}' | sudo chef-client -j /dev/stdin\\\""
      done;
      rm -rf machine_list
      """
  }
}

def deployAllmachine(environment,app_platform,app_type,app_farm)
{
    if (environment == 'dev') {
      env.promenv='qa'
      environment_name = "Development"
    } else if(environment == 'qa') {
      env.promenv='staging'
      environment_name = "QA"
    } else if(environment == 'staging') {
      env.promenv='prod'
      environment_name = "Staging"
    }
    else if(environment == 'prod') {
      env.promenv='prod'
      environment_name = "Production"
    }
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
      sh """
        curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"primary\\", \\"app_farm\\":\\"${app_farm}\\"}" > machine_list
        cat machine_list
        cat machine_list | jq '.host_info[0] | .host_name' > 1st_machine
        cat machine_list | jq -r '.host_info[0] | .host_ip' > 1stmachine_ip
        ip=`cat 1stmachine_ip`
        cat machine_list | jq '.host_info[] | .host_name' > machines
        mch=\$(<machines)
        cat machines| while read line || [[ -n "\$line" ]]; do
        machine_name=\$line
        if [[ `cat 1st_machine` == \$machine_name ]]; then
          echo "inside 1st loop"
          curl -s -u "\${phpCred}" -XPOST   http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"primary\\", \\"app_farm\\":\\"${app_farm}\\"}"  |  jq -r ".host_info[] | select(.host_name=="\${machine_name}")| .instance_info[] | .app_port" > port_list
          #sed -i 's/\\"//g' port_list
          machine_name="\${machine_name//\\"/}"
          cat port_list| while read line || [[ -n "\$line" ]]; do
          curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"RQ\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"enable\\",\\\"host_name\\": \\"\${machine_name}\\",\\"host_ip\\": \\"\${ip}\\",\\"app_port\\": \\"\${line}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"\${machine_name}\\"}"
          echo "appport_\${line}"
         done;
        else
          echo \$machine_name
          #eval "knife node show \$machine_name"
          eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo  echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":true }}' | sudo chef-client -j /dev/stdin\\\""
         fi;
       done;
       rm -rf machine_list machines 1stmachine_ip 1st_machine port_list
       """
 }
}

def enableFirstServer(environment,app_platform,app_type,app_farm)
{
    if (environment == 'dev') {
      env.promenv='qa'
      environment_name = "Development"
    } else if(environment == 'qa') {
      env.promenv='staging'
      environment_name = "QA"
    } else if(environment == 'staging') {
      env.promenv='prod'
      environment_name = "Staging"
    }
    else if(environment == 'prod') {
      env.promenv='prod'
      environment_name = "Production"
    }
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
      sh """
        curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"primary\\", \\"app_farm\\":\\"${app_farm}\\"}" > machine_list
        cat machine_list
        cat machine_list | jq '.host_info[0] | .host_name' > 1st_machine
        cat machine_list | jq -r '.host_info[0] | .host_ip' > 1stmachine_ip
        ip=`cat 1stmachine_ip`
        cat machine_list | jq '.host_info[] | .host_name' > machines
        mch=\$(<machines)
        cat machines| while read line || [[ -n "\$line" ]]; do
        machine_name=\$line
        if [[ `cat 1st_machine` == \$machine_name ]]; then
          echo "inside 1st loop"
          curl -s -u "\${phpCred}" -XPOST   http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"primary\\", \\"app_farm\\":\\"${app_farm}\\"}"  |  jq -r ".host_info[] | select(.host_name=="\${machine_name}")| .instance_info[] | .app_port" > port_list
          #sed -i 's/\\"//g' port_list
          machine_name="\${machine_name//\\"/}"
          cat port_list| while read line || [[ -n "\$line" ]]; do
          curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${env.primaryDatacenter}\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"enable\\",\\\"host_name\\": \\"\${machine_name}\\",\\"host_ip\\": \\"\${ip}\\",\\"app_port\\": \\"\${line}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"\${machine_name}\\"}"
          echo "appport_\${line}"
         done;
        fi;
       done;
       rm -rf machine_list machines 1stmachine_ip 1st_machine port_list
       """
 }
}

def getPrimaryList(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[].host_name |sed -e '1d' > machine_list
     cat machine_list
   """
   }
}

def getDrList(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[].host_name  > machine_list
     cat machine_list
   """
   }
}

def getParallelDeployConfig(primaryServerCount,desiredParallelState){
  def parallelDeployConfig = 'disable'
  if (primaryServerCount >= 4 && desiredParallelState){
    parallelDeployConfig = 'enable'
  }
  return parallelDeployConfig
}

def artifactPromotion(environment,karaf_feature,karaf_app_repo,version,nexus_repository){
  container('jnlp'){
  println "karaf_feature - ${karaf_feature}"
  if (karaf_feature){
    def nexusLocation = ''
    if (environment.toLowerCase() == 'qa') {
      nexusLocation ='Stage'
    }
    else if(environment.toLowerCase() == 'staging'){
      nexusLocation ='release'
    }
    sh """
    wget -O ./feature-generator-1.0.0-jar-with-dependencies-jar.jar https://nexusrepo.drfirst.com/nexus/content/repositories/system-engg-artifacts/extra_jars/feature-generator-1.0.0-jar-with-dependencies-jar.jar
    yes y |java -cp ./feature-generator-1.0.0-jar-with-dependencies-jar.jar com.drfirst.feature.generator.ReleaseBundles "${nexusLocation}" https://nexusrepo.drfirst.com/nexus/content/repositories/drfirst-features/${karaf_app_repo}/${karaf_feature}/$version/${karaf_feature}-$version-features.xml
    """
  }
  }
}

def dockerArtifactPromotion(environment,dev_registry,image_name,version,prod_registry){
    container('dind'){
      println "docker promote to prod registry"
      script{
         docker.withRegistry("https://${dev_registry}",'svc-devops-full-access') {
          println "Pulling docker image ${image_name}:${version}"
          image = docker.image("${dev_registry}/${image_name}:${version}")
          image.pull()
        }
        sh "docker tag ${dev_registry}/${image_name}:${version} ${prod_registry}/${image_name}:${version} "
        docker.withRegistry("https://${prod_registry}",'svc-devops-full-access') {
          newimage = docker.image("${prod_registry}/${image_name}:${version}")
          newimage.push()
        }
      }
    }
}

def kubernetes_deploy(environment,app_type,deploy_repo,version,kube_config){

  if (environment == 'dev') {
    serverUrl=""
  } else if(environment == 'qa') {
    serverUrl="https://10.100.14.1:6443"
  } else if(environment == 'staging') {
    serverUrl="https://172.17.82.68:6443"
  }else if(environment == 'prod') {
    serverUrl="https://172.16.3.118:6443"
  }
    withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
    	git config --global user.email 'svc-devops'
      git config --global user.name 'svc-devops@drfirst.com'
      cd $WORKSPACE
      rm -rf ${app_type}
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
      cd ${app_type}
      git config remote.origin.url https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
      git checkout kubernetes

      old_version=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep "git.drfirst.com" | cut -d ":" -f 4)
      base_version=\$(echo ${version} | cut -d "-" -f 1)
      sed -i "s/\$old_version/\${base_version}/g" $WORKSPACE/${app_type}/${environment}/deployment.yaml
      if [ -n \"\$(git status --porcelain)\" ]; then
        git commit -am "version update"
        git push origin kubernetes
        echo "change"
      else
        echo 'no changes';
      fi
    """
    }
    container('sandbox-chef'){
      //dir("$WORKSPACE/kubernetes") {
      //  git(
      //    url: deploy_repo,
      //    credentialsId: env.gitCredentialID,
      //    branch: 'kubernetes'
      //  )
      //}
      dir("$WORKSPACE/ref_data_repo") {
        git(
          //url: 'https://git.drfirst.com/jshi/ref_data_repo.git',
          url: 'https://git.drfirst.com/data-analytics/u0058-reference-data-repo.git',
          credentialsId: env.gitCredentialID,
          branch: '1-create-smartsig-reference-data'
        )
      }
      if (fileExists("$WORKSPACE/${app_type}/${environment}/db.json")) {
        jsonFile = "$WORKSPACE/${app_type}/${environment}/db.json"
        def jsonObj = readJSON file: jsonFile
        jsonObj['databases'].each { key,value ->
          echo "Walked through key $key and value $value"
          if( key.keySet().contains( 'ACCOUNT_TYPE' ) ) {
            if (key['ACCOUNT_TYPE'] == 'READONLY') {
              account_type="APPLICATION READONLY"
              }
          } else {
              account_type="APPLICATION"
          }
          withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
            sh """
              curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/create_db_account_api.php -d  "{\\"environment\\" : \\"${environment}\\",\\"app_username\\":\\"${key['ORACLE_USERNAME']}\\",\\"app_account_type\\":\\"${account_type}\\",\\"db_list\\":\\"${key['ORACLE_SID']}\\", \\"requestor_username\\":\\"jenkins\\" ,\\"requestor_firstname\\":\\"jenkins\\",\\"deployment_mode\\":\\"\\",\\"requestor_lastname\\":\\"jenkins\\",\\"requestor_email\\":\\"jenkins\\",\\"encryptiontype\\":\\"BASE64\\"}" > db_account.json
            """
          }
          if (app_type == 'ss2switch') {
            database_file = "$WORKSPACE/ref_data_repo/smartsig_switch/database.json"
          } else if (app_type == 'ss2web'){
            database_file = "$WORKSPACE/ref_data_repo/smart_sig/app/credentials/database.json"
          } else if (app_type == 'smartpharmacy'){
            database_file = "$WORKSPACE/ref_data_repo/smart_pharmacy/data/credentials/database.json"
          } else if (app_type == 'smartstring'){
            database_file = "$WORKSPACE/ref_data_repo/smart_string/data/credentials/database.json"
          }
          print database_file
          def dbObj = readJSON file: database_file
          print dbObj
          dbObj.each {k,v ->
            dbObj[k]=key[k]

          }
          dbaccountFile="$WORKSPACE/db_account.json"
          def dbaccountObj = readJSON file: dbaccountFile
          print dbObj
          if (app_type == 'smartstring' || app_type == 'ss2web'){
          print "inside smartstring or ss2web DB env encoding"
            dbObj['ORACLE_USERNAME_CAS']=dbObj['ORACLE_USERNAME_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PASSWORD_CAS']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
            dbObj['ORACLE_HOSTNAME_CAS']=dbObj['ORACLE_HOSTNAME_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PORT_CAS']=dbObj['ORACLE_PORT_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_SID_CAS']=dbObj['ORACLE_SID_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_USERNAME_CENTR']=dbObj['ORACLE_USERNAME_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PASSWORD_CENTR']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
            dbObj['ORACLE_HOSTNAME_CENTR']=dbObj['ORACLE_HOSTNAME_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PORT_CENTR']=dbObj['ORACLE_PORT_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_SID_CENTR']=dbObj['ORACLE_SID_CENTR'].bytes.encodeBase64().toString()

          print dbObj
          writeJSON file: database_file, json: dbObj
          }
          else {
          dbObj['ORACLE_USERNAME']=dbaccountObj['create_db_account_api'][0]['encrypted_username']
          dbObj['ORACLE_PASSWORD']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
          dbObj['ORACLE_HOSTNAME']=dbObj['ORACLE_HOSTNAME'].bytes.encodeBase64().toString()
          dbObj['ORACLE_PORT']=dbObj['ORACLE_PORT'].bytes.encodeBase64().toString()
          dbObj['ORACLE_SID']=dbObj['ORACLE_SID'].bytes.encodeBase64().toString()
          writeJSON file: database_file, json: dbObj
          print dbObj
        }
        }
      }
    }

    print serverUrl
  container('kubectl'){
   withKubeConfig([credentialsId: "${kube_config}-${environment}", serverUrl: serverUrl]) {
   sh """
     pwd
     ls -lart
     #sleep 1200

     sh  $WORKSPACE/${app_type}/deploy.sh
    """
   }

  }
}

def getServerList(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
      def serverlist = [];
      (appEnvironmentType.tokenize(' ,[] ')).each { environmentType ->
       sh """
          curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${environmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[].host_name  > machine_list
          cat machine_list
       """
          def data = readFile(file: 'machine_list')
          data.split('\n').each { value ->
                serverlist.add(value)
          }
       }
       sh """ rm -rf machine_list """
       return serverlist

   }
}

def getEnvType(is_primarySite,is_drSite){

    def environmentType = [];
    if(is_primarySite)
     {
      environmentType.add("primary");
      }
    if(is_drSite){
      environmentType.add("dr");
    }
 return environmentType;
}



def kubernetes_1stdeploy(environment,app_type,deploy_repo,version,kube_config,datacenter){
  switch(environment){
    case "dev":
      serverUrl=""
      break
    case "qa":
      serverUrl="https://10.100.14.1:6443"
      break
    case "staging":
      if (datacenter == "DS")
        serverUrl="https://172.17.73.100:6443"
      else
        serverUrl="https://172.17.82.68:6443"
      break
    case "prod":
      if (datacenter == "VZ")
        serverUrl="https://172.16.3.118:6443"
      else
        serverUrl="https://172.20.3.49:6443"
      break
  }
  //if (environment == 'dev') {
  //  serverUrl=""
  //} else if(environment == 'qa') {
  //  serverUrl="https://10.100.14.1:6443"
  //} else if(environment == 'staging') {
  //  if (datacenter == "DS") {
  //    serverUrl="https://172.17.82.68:6443"
  //  }else {
  //    serverUrl="https://172.17.82.68:6443"
  //  }
  //}else if(environment == 'prod') {
  //  serverUrl="https://172.16.3.118:6443"
  //}
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
  sh """
    git config --global user.email 'svc-devops'
    git config --global user.name 'svc-devops@drfirst.com'
    cd $WORKSPACE
    rm -rf ${app_type}
    git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
    cd ${app_type}
    git config remote.origin.url https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
    git checkout kubernetes

    old_version=\$(more $WORKSPACE/${app_type}/${environment}/pdvdeployment.yaml | grep "git.drfirst.com" | cut -d ":" -f 4)
    base_version=\$(echo ${version} | cut -d "-" -f 1)
    sed -i "s/\$old_version/\${base_version}/g" $WORKSPACE/${app_type}/${environment}/pdvdeployment.yaml
    sed -i "s/\$old_version/\${base_version}/g" $WORKSPACE/${app_type}/first_deploy.sh
    if [ -n \"\$(git status --porcelain)\" ]; then
      git commit -am "version update"
      git push origin kubernetes
      echo "change"
    else
      echo 'no changes';
    fi
  """
  }
  container('sandbox-chef'){
    //dir("$WORKSPACE/kubernetes") {
    //  git(
    //    url: deploy_repo,
    //    credentialsId: env.gitCredentialID,
    //    branch: 'kubernetes'
    //  )
    //}
    dir("$WORKSPACE/ref_data_repo") {
      git(
        //url: 'https://git.drfirst.com/jshi/ref_data_repo.git',
        url: 'https://git.drfirst.com/data-analytics/u0058-reference-data-repo.git',
        credentialsId: env.gitCredentialID,
        branch: '1-create-smartsig-reference-data'
      )
    }
    if (fileExists("$WORKSPACE/${app_type}/${environment}/db_${datacenter}.json")) {
      jsonFile = "$WORKSPACE/${app_type}/${environment}/db_${datacenter}.json"
      def jsonObj = readJSON file: jsonFile
      jsonObj['databases'].each { key,value ->
        echo "Walked through key $key and value $value"
        if (environment == 'prod') {
          db_env="Production"
        }
        else{
          db_env=environment
        }
        withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
          sh """
          curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/create_db_account_api.php -d  "{\\"environment\\" : \\"${db_env}\\",\\"app_username\\":\\"${key['ORACLE_USERNAME']}\\",\\"app_account_type\\":\\"APPLICATION\\",\\"db_list\\":\\"${key['ORACLE_SID']}\\", \\"requestor_username\\":\\"jenkins\\" ,\\"requestor_firstname\\":\\"jenkins\\",\\"deployment_mode\\":\\"\\",\\"requestor_lastname\\":\\"jenkins\\",\\"requestor_email\\":\\"jenkins\\",\\"encryptiontype\\":\\"BASE64\\"}" > db_account.json
          cat db_account.json
          """
        }
        if (app_type == 'ss2switch') {
          database_file = "$WORKSPACE/ref_data_repo/smartsig_switch/database.json"
        } else if (app_type == 'ss2web'){
          database_file = "$WORKSPACE/ref_data_repo/smart_sig/app/credentials/database.json"
        } else if (app_type == 'smartpharmacy'){
          database_file = "$WORKSPACE/ref_data_repo/smart_pharmacy/data/credentials/database.json"
        } else if (app_type == 'smartstring'){
            database_file = "$WORKSPACE/ref_data_repo/smart_string/data/credentials/database.json"
        }

        def dbObj = readJSON file: database_file
        dbObj.each {k,v ->
          dbObj[k]=key[k]
        }
        dbaccountFile="$WORKSPACE/db_account.json"
        def dbaccountObj = readJSON file: dbaccountFile
        if (app_type == 'smartstring' || app_type == 'ss2web'){
            print "deploy k8s 1st inside smartstring or ss2web DB env encoding"
            dbObj['ORACLE_USERNAME_CAS']=dbObj['ORACLE_USERNAME_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PASSWORD_CAS']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
            dbObj['ORACLE_HOSTNAME_CAS']=dbObj['ORACLE_HOSTNAME_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PORT_CAS']=dbObj['ORACLE_PORT_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_SID_CAS']=dbObj['ORACLE_SID_CAS'].bytes.encodeBase64().toString()
            dbObj['ORACLE_USERNAME_CENTR']=dbObj['ORACLE_USERNAME_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PASSWORD_CENTR']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
            dbObj['ORACLE_HOSTNAME_CENTR']=dbObj['ORACLE_HOSTNAME_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_PORT_CENTR']=dbObj['ORACLE_PORT_CENTR'].bytes.encodeBase64().toString()
            dbObj['ORACLE_SID_CENTR']=dbObj['ORACLE_SID_CENTR'].bytes.encodeBase64().toString()

          print dbObj
          writeJSON file: database_file, json: dbObj
        } else {
        dbObj['ORACLE_USERNAME']=dbaccountObj['create_db_account_api'][0]['encrypted_username']
        dbObj['ORACLE_PASSWORD']=dbaccountObj['create_db_account_api'][0]['encrypted_password']
        dbObj['ORACLE_HOSTNAME']=dbObj['ORACLE_HOSTNAME'].bytes.encodeBase64().toString()
        dbObj['ORACLE_PORT']=dbObj['ORACLE_PORT'].bytes.encodeBase64().toString()
        dbObj['ORACLE_SID']=dbObj['ORACLE_SID'].bytes.encodeBase64().toString()
        writeJSON file: database_file, json: dbObj
        print dbObj
        }
      }
    }
  }
  print serverUrl
  print "${kube_config}-${datacenter}"
  container('kubectl'){
   withKubeConfig([credentialsId: "${kube_config}-${datacenter}", serverUrl: serverUrl]) {
   sh """
     pwd
     ls -lart
     #sleep 1200
     sh  $WORKSPACE/${app_type}/first_deploy.sh
    """
   }
  }
}

def kubernetes_deployAll(environment,app_type,deploy_repo,version,kube_config,datacenter,app_platform){
 app_farm=app_type
 switch(environment){
  case "dev":
    env.environment_name = "Development"
    serverUrl=""
    break
  case "qa":
    serverUrl="https://10.100.14.1:6443"
    host_name="kubeqz01u"
    env.environment_name = "QA"
    break
  case "staging":
    env.environment_name = "Staging"
    if (datacenter == "DS"){
      serverUrl="https://172.17.73.100:6443"
      host_name="kubesz01u"
      }
    else{
      serverUrl="https://172.17.82.68:6443"
        host_name="kubeuz01u"
      }
    break
  case "prod":
    env.environment_name = "Production"
    if (datacenter == "VZ"){
      serverUrl="https://172.16.3.118:6443"
      host_name="kubeaz01u"
      }
    else {
      serverUrl="https://172.20.3.49:6443"
      host_name="kubebz01u"
    }
    break
}
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
  sh """
    git config --global user.email 'svc-devops'
    git config --global user.name 'svc-devops@drfirst.com'
    cd $WORKSPACE
    rm -rf ${app_type}
    git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
    cd ${app_type}
    git config remote.origin.url https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
    git checkout kubernetes

    old_version=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep "git.drfirst.com" | cut -d ":" -f 4)
    base_version=\$(echo ${version} | cut -d "-" -f 1)
    sed -i "s/\$old_version/\${base_version}/g" $WORKSPACE/${app_type}/${environment}/deployment.yaml

    if [ -n \"\$(git status --porcelain)\" ]; then
      git commit -am "version update"
      git push origin kubernetes
      echo "change"
    else
      echo 'no changes';
    fi
  """
  }

  container('kubectl'){
   withKubeConfig([credentialsId: "${kube_config}-${datacenter}", serverUrl: serverUrl]) {
   sh """
     pwd
     ls -lart
     sh  $WORKSPACE/${app_type}/deploy.sh
    """
   }
  }
withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
sh """
  host_ip=\$(getent hosts ${host_name}.dc | awk '{print \$1}')
	is_NodePort=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep "NodePort" | cut -d ":" -f 2| tr -d ' ')
	is_ClusterIP=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep "ClusterIP" | cut -d ":" -f 2| tr -d ' ')
  if [[ "\${is_NodePort}" == "NodePort" ]]; then
    echo "inside nodeport"
		if [[ "${environment_name}" == 'QA' ]]; then
			lb_vs_name="qa_${app_farm}_https"
      lb_pool_name="qa_${app_farm}_http"
		elif [[ "${environment_name}" == 'Staging' ]]; then
			lb_vs_name="stg_${app_farm}_https"
      lb_pool_name="stg_${app_farm}_http"
		elif [[ "${environment_name}" == 'Production' ]]; then
			lb_vs_name="${app_farm}_https"
      lb_pool_name="${app_farm}_http"
		fi
		app_port=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep "nodePort" | cut -d ":" -f 2| tr -d ' ')
	elif [[ "\${is_ClusterIP}" == 'ClusterIP' ]]; then
		if [[ "${environment_name}" == 'QA' ]]; then
			lb_vs_name="qa_${app_farm}_http"
      lb_pool_name="qa_${app_farm}_http"
		elif [[ "${environment_name}" == 'Staging' ]]; then
			lb_vs_name="stg_${app_farm}_http"
      lb_pool_name="stg_${app_farm}_http"
		elif [[ "${environment_name}" == 'Production' ]]; then
			lb_vs_name="${app_farm}_http"
      lb_pool_name="${app_farm}_http"
		fi
		app_port=\$(more $WORKSPACE/${app_type}/${environment}/deployment.yaml | grep webport -A 1 | tail -1 | grep port | cut -d ":" -f 2| tr -d ' ')
	fi
    curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/vm_app_status_updater.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${datacenter}\\",\\"region\\": \\"Common\\",\\"network_zone\\":\\"DMZ\\",\\\"host_name\\": \\"${host_name}\\",\\"host_ip\\": \\"\${host_ip}\\",\\"app_port\\": \\"\${app_port}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"web_server_type\\": \\"nginx\\",\\"app_instance_name\\": \\"${host_name}_\${app_port}\\",\\"app_version\\": \\"${version}\\",\\"lb_vs_name\\": \\"\${lb_vs_name}_vs\\",\\"lb_pool_name\\": \\"\${lb_pool_name}_pool\\",\\"app_deploy_date\\": \\"\$(date '+%m/%d/%Y %H:%M:%S')\\",\\"vm_app_instance_status\\": \\"Success\\",\\"deployer_username\\": \\"jenkins\\",\\"comments\\": \\"\\"}"
  """
  }
}

def checkPackageJson(build_name,app_version,application_name){
container('jnlp'){
	sh """
    echo "check package "
		cd $WORKSPACE
    echo "build name valie :- ${build_name} "
    if [[ '${build_name}' == 'webui-dev' ]]; then
		    nexuslocation="dev"
  	else
  	    nexuslocation="${app_version}"
		fi
    wget https://nexusrepo.drfirst.com/nexus/content/repositories/system-engg-artifacts/webui_ref/rcopia4x_web/\$nexuslocation/rcopia4x_web-\$nexuslocation.tar.gz
    mkdir ${application_name}
    tar xvf rcopia4x_web-\${nexuslocation}.tar.gz -C ./${application_name}
    package_output=\$(diff package.json ./${application_name}/package.json)
    echo \$package_output
	   if [[ -z \$package_output ]]; then
		    echo "Package.json doesn't have changes"
	   else
		    echo "Aborting the build Since it is having changes in Package.json"
        exit 1
	   fi

  """
}
}
