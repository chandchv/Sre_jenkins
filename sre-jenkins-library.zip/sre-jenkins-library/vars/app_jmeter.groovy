def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        options {
           buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
        }

        environment {
          gitCredentialID='svc-automation'
          
        }

      agent {
          label "jnlp-base"
        }
      stages{
        stage('jmeter execution')
        {
          steps {
              script{
                if ( "${config.on_demand_branch}" == "true")
               {
                timeout(time: 180, unit: 'SECONDS') {
                  
		                env.branch = input (id: 'inputVersion1',
				            message: 'Proceed or Abort?',
				            parameters: [string(defaultValue: '', description: 'enter branch ', name: 'inputBranch', trim: true)],
                    submitter: "${env.approver}")
				          }
                } else {
                env.branch="${config.branch_name}"
                }
                if ( env.branch.isEmpty() ) {
                      error('Branch name is empty')
                }

              }
          
              dir("$WORKSPACE") {
                git(
                    url: "${config.git_url}",
                    credentialsId: env.gitCredentialID,
                    branch: "${env.branch}"
                  )
                }
              
               container ('jmeter'){
                   script{
                    println('pipeline new ')
                    sh """ 
                    pwd 
                    cd $WORKSPACE
                    which jmeter
                    jmeter -n -t ${config.application}.jmx -JserverIp=${config.server_ip} -JserverPort=${config.server_port} -JreleaseName=${env.branch} -l log.jtl
                    ls -rlt
                    """
                    dir("$WORKSPACE") {
                    perfReport 'log.jtl'
                    archiveArtifacts 'jmeter.log,log.jtl'
                    }
                    currentBuild.displayName="${env.branch}"
                   }
               } 
          }
        }   
        stage('Test Rail')
        {
          steps{
            container('sandbox-curl'){
              script{
                env.testrail_url=build.getTestrailurl(config.testrail_project_id,env.branch)
                echo "$env.testrail_url"
                currentBuild.description="${env.testrail_url}"
              }
            }
          }
        }  
      }
    }
}
