def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        environment {
          gitCredentialID='svc-automation'
          nexusCred='nexus-cred'
          phpCred='phpCred'
        }
      agent any
      stages{
        stage('Scan')
        {
          steps {
            script{
              build.prepare_env()
              println "${env.repository_type}"
              env.application_name = "${config.application_name}"
              env.app_platform = "${config.app_platform}"
              env.primary_farm = "${config.primary_farm}"
              sh "rm -rf $WORKSPACE/${config.application_name}"

                if ( "${config.app_platform}" == "pi" ||  "${config.app_platform}" == "commonservies" ||  "${config.app_platform}" == "medhx"  )
                {
                  println "pi"
                  env.gitCredentialID = "jo"
                }

            }

            script{
              echo "${env.extraRepo} - extra repo"
              if ( "${env.extraRepo}" == "true")
              {
                  echo "callling extra repo"
                   build.cloneExtraRepo()
              }
            }

            dir("$WORKSPACE/${config.application_name}") {
                git(
                  url: config.repository_url,
                  credentialsId: env.gitCredentialID,
                    branch: config.branch
                )
            }
            script{
              build.nodejs_build()
            }
/*
            dir("$WORKSPACE/${config.application_name}/jenkins-dsl") {
                git(
                  url: config.repository_url2,
                  credentialsId: env.gitCredentialID,
                  branch: 'master'
                )
            }*/



          }
        }
        stage('SonarQube Scan') {
            steps {
                script{
                  echo "scan"
                   scannerHome = tool 'stand-alone-330'

                  // build.sonar_scan_only("${app_platform}","${application_name}")
                   //build.sonar_scan_only("${env.app_platform}","${env.application_name}")

/*
                withSonarQubeEnv('mysonar') {
                  sh """
                    sed -i 's/use_embedded_jre=true/use_embedded_jre=false/g' ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner
                    ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner -Dsonar.projectName=${env.app_platform} -Dsonar.projectKey=${env.app_platform}-${env.application_name} -Dsonar.scm.provider=git -Dsonar.sources=.
                    -Dsonar.java.binaries=*bin -Dsonar.inclusions=*src/com/drfirst/**
                  """
                }
                */
            }
        }
      }
        stage('quality gate')
        {
          steps{
            container('sandbox-curl'){
              script{
                if ("${config.scan}" == "true")
                {
                  env.bugCount=build.sonarCheck(env.sonarComponentKeys,'BUG')
                  env.vulnCount=build.sonarCheck(env.sonarComponentKeys,'VULNERABILITY')
                env.codesmellCount=build.sonarCheck(env.sonarComponentKeys,'CODE_SMELL')
                echo "sonar - http://cicd.dfcorp.drfirst.com/sonar/dashboard?id=${env.sonarComponentKeys} \n bugcount - $env.bugCount \n vulnCount - $env.vulnCount \n codesmellCount - $env.codesmellCount"
                }
                else {
                  println "no scan "
                }
           }
           }
         }
       }

    }
  }
}
