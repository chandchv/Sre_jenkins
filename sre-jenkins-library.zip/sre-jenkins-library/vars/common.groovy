import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType


def uuidGen(){
    def verCode = UUID.randomUUID().toString()
    env.jobUuid =verCode
}

def generateRequeueList(){
  sh """
  if [ -f machine_list1 ];then
   echo `cat machine_list1` > machine_list
  fi
  if [ -f machine_list2 ];then
   echo `cat machine_list2` >> machine_list
  fi
  cat machine_list
  """
}

def instanceLbHandler(enableDisable,nvironment_name,datacenter,host_name,host_ip,app_port,app_platform,appType,appFarm){
  sh """
    curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${datacenter}\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"${enableDisable}\\",\\\"host_name\\": \\"${host_name}\\",\\"host_ip\\": \\"${host_ip}\\",\\"app_port\\": \\"${app_port}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"jenkins\\"}"
  """
}

def getServerCount(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq '.host_info | length' > job.serverCount
     cat job.serverCount
   """
   return sh(script:"cat job.serverCount", returnStdout:true).trim()
   }
}

def getPrimaryDatacenter(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r '.host_info[0].datacenter' > job.dc
     cat job.dc
   """
   return sh(script:"cat job.dc", returnStdout:true).trim()
   }
}

def getWebServerType(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r '.host_info[0].instance_info[].web_server_type' > job.dc ||true
     cat job.dc
   """
   return sh(script:"cat job.dc", returnStdout:true).trim()
   }
}

def slackNotify(appType, String buildStatus = 'STARTED') {
  //def maps
  def releasegrp_apptype = [:]
  def releasegrp_channel = [:]
  releasegrp_apptype["griffin"] = ["webui", "orca", "grepo", "gdocmiller"]
  releasegrp_apptype["phoenix"] = ["gauth", "gaudit"]

  releasegrp_channel["griffin"] = ["cicd_rcopia4"]
  releasegrp_apptype["phoenix"] = ["jenkins-test"]

  channels = []

  for (item in releasegrp_apptype){
    if (appType in item.value) {
      if (!(releasegrp_channel[item.key] in channels)) {
        channels.add(releasegrp_channel[item.key])
      }
    }
  }
  print channels
  // build status of null means successful
  buildStatus =  buildStatus ?: 'SUCCESSFUL'

  // Default values
  def colorName = 'RED'
  def colorCode = '#FF0000'
  def subject = "${buildStatus}: Job '${env.JOB_NAME} [${env.BUILD_DISPLAY_NAME}]'"
  def summary = "${subject} (${env.JOB_URL})"
  // Override default values based on build status
  if (buildStatus == 'ABORTED') {
    color = 'YELLOW'
    colorCode = '#FFFF00'
  } else if (buildStatus == 'SUCCESSFUL') {
    color = 'GREEN'
    colorCode = '#00FF00'
  } else {
    color = 'RED'
    colorCode = '#FF0000'
  }

  if (channels.isEmpty()) {
    channels.add("jenkins-test")
  }
  // Send notifications
  for (channelName in channels) {
    slackSend channel:channelName, color: colorCode, message: summary, teamDomain: 'drfirst', tokenCredentialId: 'slackCredsId'
  }
}

def sparkNotify(application,environment,spaceId,spaceName,status){  
  
  sparkSend credentialsId: 'webex-bot', message: "${application} - ${environment} - ${status} ", messageType: 'text', spaceList: [[spaceId: "${spaceId}", spaceName: "${spaceName}"]]

 } 
