import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType

def chefPrimaryDatacenterSwitch(env, primaryDatacenter){

  println "verifying databag"
  sh """
    cp data_bags/datacenters/datacenters.json .
    cat datacenters.json
  """

  jsonFile1 = 'datacenters.json'
  def json1 = readJSON file: jsonFile1

  if (json1['environment'][env]['primary'] == primaryDatacenter){
    println "no DC change"
    error('nothing to do')
  } else {
      sh """
        sed -i 's/${json1['environment'][env]['primary']}/${primaryDatacenter}/g' data_bags/datacenters/datacenters.json
        rm -rf datacenters.json
        knife data bag from file datacenters data_bags/datacenters/datacenters.json
      """
  }
}

def chefDownloadDatabag(databagName,databagItem){
    sh """
    knife download data_bags/${databagName} --chef-repo-path ${WORKSPACE}
    ls -la
    cat ${WORKSPACE}/data_bags/${databagName}/${databagItem}.json
    """
}



def chefDeploy(appPlatform,appType,appFarm,appEnv,appDatacenter,deployToAll,deployOnlyTo){
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
      if (deployToAll) {
          sh """
            mkdir -p ${appType}_${appFarm}_${appDatacenter}
            curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"datacenter\\":\\"${appDatacenter}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[].host_name >> ${appType}_${appFarm}_${appDatacenter}/machine_list
          """
      }else {
          deployOnlyTo.each {
          sh """
            mkdir -p ${appType}_${appFarm}_${appDatacenter}
            curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"datacenter\\":\\"${appDatacenter}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[${it}].host_name >> ${appType}_${appFarm}_${appDatacenter}/machine_list
          """
          }
      }

      sh """
      cat ${appType}_${appFarm}_${appDatacenter}/machine_list| while read line || [[ -n "\$line" ]]; do
      line="\${line//\\"/}"
      machine_name=\$line
      echo \$machine_name
      #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date \\\""
      eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo chef-client \\\""
      done;
      """
    }
 }

 def chefSimpleDeploy(machine_name){
      sh """
      echo ${machine_name}
      eval "knife ssh 'name:${machine_name}' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo chef-client \\\""
      """
}

 def chefSimpleDeployLocal(){
      sh """
      #cat machine_list| while read line || [[ -n "\$line" ]]; do
      #line="\${line//\\"/}"
      machine_name=`cat machine_list`
      echo \${machine_name}
      eval "knife ssh 'name:\${machine_name}' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo date \\\""
      rm -rf machine_list
      """
}


 def getDeployList(appPlatform,appType,appFarm,appEnv,appDatacenter){
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
    sh """
      curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"datacenter\\":\\"${appDatacenter}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r .host_info[].host_name >> machine_list
      cat machine_list
    """
    }
 }

 def chefMedhxApiDrSwitch(appEnv,newDr,newPrime){
    withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {

    sh """
      mkdir -p medhxapi_${appEnv}_${newDr}
      curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"medhx\\",\\"app_type\\":\\"medhxapi\\",\\"datacenter\\":\\"${newDr}\\", \\"app_farm\\":\\"medhxapi\\" }" |jq -r .host_info[].host_name >> medhxapi_${appEnv}_${newDr}/machine_list
      cat medhxapi_${appEnv}_${newDr}/machine_list| while read line || [[ -n "\$line" ]]; do
      line="\${line//\\"/}"
      machine_name=\$line
      echo \$machine_name
      eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo sed -i 's/poll\\.jobs.*/poll\\.jobs=false/' /app/karaf/instances/*/etc/com.drfirst.job.core.impl.JobManagerImpl.cfg \\\"" #\\\"sudo chef-client \\\""
      done;
    """

    sh """
      mkdir -p medhxapi_${appEnv}_${newPrime}
      curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"medhx\\",\\"app_type\\":\\"medhxapi\\",\\"datacenter\\":\\"${newPrime}\\", \\"app_farm\\":\\"medhxapi\\" }" |jq -r .host_info[].host_name >> medhxapi_${appEnv}_${newPrime}/machine_list
      cat medhxapi_${appEnv}_${newPrime}/machine_list| while read line || [[ -n "\$line" ]]; do
      line="\${line//\\"/}"
      machine_name=\$line
      echo \$machine_name
      eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo sed -i 's/poll\\.jobs.*/poll\\.jobs=true/' /app/karaf/instances/*/etc/com.drfirst.job.core.impl.JobManagerImpl.cfg \\\"" #\\\"sudo chef-client \\\""
      done;
    """
    }
 }

def rxpollerDrSwitch(appEnv,newDr,newPrime){
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {

   sh """
     mkdir -p rxpoller_${appEnv}_${newDr}
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"commonservices\\",\\"app_type\\":\\"psrxpoller\\",\\"datacenter\\":\\"${newDr}\\", \\"app_farm\\":\\"psrxpoller\\" }" |jq -r .host_info[].host_name >> rxpoller_${appEnv}_${newDr}/machine_list

     cat rxpoller_${appEnv}_${newDr}/machine_list| while read line || [[ -n "\$line" ]]; do
     line="\${line//\\"/}"
     machine_name=\$line
     echo \$machine_name
     echo "disabling poller"
     curl http://\$machine_name.dc:52001/internal/poller/disable
     curl http://\$machine_name.dc:52002/internal/poller/disable
     #curl http://\$machine_name.dc:52001/internal/system/status
     #curl http://\$machine_name.dc:52002/internal/system/status
     eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo su appuser -c 'sh /app/karaf/instances/\${machine_name}_52001/bin/stop && sh /app/karaf/instances/\${machine_name}_52002/bin/stop && sh /app/karaf/instances/\${machine_name}_52001/bin/start && sh /app/karaf/instances/\${machine_name}_52002/bin/start '\\\""
     #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date\\\""
     done;
   """

   sh """
     mkdir -p rxpoller_${appEnv}_${newPrime}
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${appEnv}\\",\\"app_platform\\":\\"commonservices\\",\\"app_type\\":\\"psrxpoller\\",\\"datacenter\\":\\"${newPrime}\\", \\"app_farm\\":\\"psrxpoller\\" }" |jq -r .host_info[].host_name >> rxpoller_${appEnv}_${newPrime}/machine_list

     cat rxpoller_${appEnv}_${newPrime}/machine_list| while read line || [[ -n "\$line" ]]; do
     line="\${line//\\"/}"
     machine_name=\$line
     echo \$machine_name
     echo "enabling poller"
     curl http://\$machine_name.dc:52001/internal/poller/enable
     curl http://\$machine_name.dc:52002/internal/poller/enable
     #curl http://\$machine_name.dc:52001/internal/system/status
     #curl http://\$machine_name.dc:52002/internal/system/status
     eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo su appuser -c 'sh /app/karaf/instances/\${machine_name}_52001/bin/stop && sh /app/karaf/instances/\${machine_name}_52002/bin/stop && sh /app/karaf/instances/\${machine_name}_52001/bin/start && sh /app/karaf/instances/\${machine_name}_52002/bin/start &&  sh /app/utilities/pdv.sh'\\\""
     #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"date\\\""
     done;

   """
   }
}

def uuidGen(){
    def verCode = UUID.randomUUID().toString()
    env.jobUuid =verCode
}

def generateRequeueList(){
  sh """
  echo `cat machine_list1` > machine_list
  echo `cat machine_list2` >> machine_list
  cat machine_list
  """
}

def generate_report(elk_url,elk_report_url,filename_prefix,elk_auth_id,sftp_hostname,sftp_username){
withCredentials([string(credentialsId: elk_auth_id, variable: 'authorization'),string(credentialsId: sftp_username, variable: 'sftp_password')]) {
  sh """
  cat > generate_report.py <<-'EOF'
#!/usr/bin/env python
import requests
import json
from requests.auth import HTTPBasicAuth
import time
import logging
import pysftp

elk_url="${elk_url}"
elk_report_url="${elk_report_url}"
filename_prefix="${filename_prefix}"
authorization="${authorization}"
sftp_hostname="${sftp_hostname}"
sftp_username="${sftp_username}"
sftp_password="${sftp_password}"
try:
  response=requests.post(elk_report_url,headers={'Authorization':authorization,'kbn-xsrf':'true'})
  if response.ok:
    json_data = json.loads(response.text)
    logging.warning(" Path of the document on ELK - "+json_data['path'])
    document_url=elk_url+json_data['path']
    logging.warning(" Downloading document from url - "+document_url)
    for i in range(3):
      logging.warning(" Waiting for 20 seconds before attempting to download.")
      time.sleep(20)
      doc_response=requests.get(document_url,headers={'Authorization':authorization,'kbn-xsrf':'true'})
      if doc_response.ok:
        filename=filename_prefix+"-"+time.strftime("%Y%m%d-%H%M%S")+".pdf"
        logging.warning(filename)
        open(filename, 'wb').write(doc_response.content)
        break
      else:
        logging.warning(doc_response.text)
        time.sleep(20)
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    with pysftp.Connection(host=sftp_hostname, username=sftp_username, password=sftp_password,cnopts=cnopts) as sftp:
      logging.warning("Connection successfully established.")

      localFilePath = filename
      remoteFilePath = "/athena_health/report/"+filename
      sftp.put(localFilePath, remoteFilePath)
      logging.warning("File uploaded successfully.")
  else:
    logging.error(" An error occurred with api request!")
except  Exception as e:
    logging.error(" An error occurred! " + str(e))
"""
sh """
python generate_report.py
"""
  }
}

def dropdownEnvInput(){
  timeout(time: 180, unit: 'SECONDS') {
       env.environment = input message: 'Please choose the env to migrate affiliates ', ok: 'Validate!',
       parameters: [choice(name: 'ENV_NAME', choices: ['qa','stg','prod'], description: 'Env to migrate?')],
       submitter: "${env.approver}"
    }
    println env.environment
    println env.environment.getClass()
}

def affnameInput() {
    timeout(time: 180, unit: 'SECONDS') {
       env.affiliates = input (id: 'inputBranch1',
       message: 'Proceed or Abort?',
       parameters: [string(defaultValue: '', description: 'enter affiliate name', name: 'inputBranch', trim: true)],
       submitter: "${env.approver}")
    }
    println env.affiliates
    println env.affiliates.getClass()
}

def queueCreation() {
sh """
cd $WORKSPACE/${env.project_name}
pip install openpyxl
python amq.py ${env.environment} ${env.affiliates}
"""
}

def channelMod() {
currentBuild.displayName = "${env.environment}-${env.affiliates}"
sh """
cd $WORKSPACE/${env.project_name}
python channel_update.py ${env.environment} ${env.affiliates}
"""
}

def gitCommitPush(gitCredentialID,repo_name){

  //add all files and commit all changes and then push
  withCredentials([usernameColonPassword(credentialsId: gitCredentialID, variable: 'GITPASS')]) {
    sh """
      cd $WORKSPACE/${env.project_name}
      pwd
      if [ -n \"\$(git status --porcelain)\" ]; then
        echo "changess"
        git config --global user.email 'svc-devops'
        git config --global user.name 'svc-devops@drfirst.com'
        git commit -am "status change for affiliate"
        git push https://\${GITPASS}@git.drfirst.com/devops-se/${repo_name}.git HEAD:master
        #git push origin master
      else
        echo 'no changes';
      fi
    """
  }
}

def getTomcatversion(){
sh """
	 version=\$(cat node.json | jq '.default."df_tomcat-all".version' | sed 's/"//g' | cut -c 1)
     echo "\$version" > tomcat_version
   """
	 return sh(script:"cat tomcat_version", returnStdout:true).trim()
}

def getWebServerType(appPlatform,appType,appFarm,environment,appEnvironmentType){
  if (environment == 'dev') {
    env.promenv='qa'
    environment_name = "Development"
  } else if(environment == 'qa') {
    env.promenv='staging'
    environment_name = "QA"
  } else if(environment == 'staging') {
    env.promenv='prod'
    environment_name = "Staging"
  }else if(environment == 'prod') {
    env.promenv='prod'
    env.app_environment = "Production"
    environment_name = "Production"
  }
   withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
   sh """
     curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${appPlatform}\\",\\"app_type\\":\\"${appType}\\",\\"environment_type\\":\\"${appEnvironmentType}\\", \\"app_farm\\":\\"${appFarm}\\" }" |jq -r '.host_info[0].instance_info[0].web_server_type' > job.dc
     cat job.dc
   """
   return sh(script:"cat job.dc", returnStdout:true).trim()
   }
}

def getLbStatus(environment,app_platform,app_type,app_farm,server,datacenter,environment_type){

  if (environment == 'Staging') {
      environment_name = "Staging"
	  if (datacenter == 'DS'){
      lb_url = "dpclb1.dc"
	  } else if(datacenter == 'RU') {
	  lb_url = "ctlb2.dc"
	  }
  } else if(environment == 'Production') {
      environment_name = "Production"
      if (datacenter == 'VZ'){
      lb_url = "172.16.0.180"
	  } else if(datacenter == 'DP') {
	  lb_url = "172.20.0.31"
	  }
  }


withCredentials([string(credentialsId: 'lb_username', variable: 'lb_username'), string(credentialsId: 'lb_password', variable: 'lb_password'), usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {

sh """

# function to get the serverlist
curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"${environment_type}\\", \\"app_farm\\":\\"${app_farm}\\" }" | jq '.host_info[] | .host_name'  | sed 's/"//g' > machine_list
cat machine_list
sed -i '/${server}/d' machine_list

# getting server count and assigning weight for each server
server_count=\$(cat machine_list | wc -l)
server_weight=\$(( 100 / \$server_count ))
expected_availability=50
while read machine; do
    # function to get the port numbers using the
    curl -s -u "\${phpCred}" -XPOST   http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"${environment_type}\\", \\"app_farm\\":\\"${app_farm}\\"}"  | jq -r ".host_info[] | select(.host_name==\\"\$machine\\") | .instance_info[] | .app_port" > port_list
    cat port_list

    # getting instance count and assigning weight for each instance
    instance_count=\$(cat port_list | wc -l)
    instance_weight=\$(( \$server_weight / \$instance_count ))

    while read port;do
        # function to get the lb pool name using filter
        curl -s -u "\${phpCred}" -XPOST   http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d  "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"${environment_type}\\", \\"app_farm\\":\\"${app_farm}\\"}"  | jq -r ".host_info[] | select(.host_name==\\"\$machine\\") | .instance_info[] | select(.app_port==\\"\${port}\\") | .lb_pool_name"  > lbpool_list
        cat lbpool_list
        while read lbpool;do
          echo "\$line - \$port - \$lbpool"
          # function to check the status of the pool members in load balancer
          pool_status=\$(curl -k -u \${lb_username}:\${lb_password} -H \"Content-Type:application/json\" -X GET https://${lb_url}/mgmt/tm/ltm/pool/\$lbpool/members/~Common~\$machine:\$port | jq -r .state)
          if [ \$pool_status = up ];then
              echo "node is enable in LB"
              echo "\$machine:\$port-up" >> lb_pool_status
              desired_weight=\$(( \$desired_weight + \$instance_weight ))
          else
              echo "Please enable the server in LB"
              echo "\$machine:\$port-down" >> lb_pool_status
              desired_weight=\$(( \$desired_weight - \$instance_weight ))
          fi
        done <lbpool_list
    done <port_list
done <machine_list

echo " available weight :- \$desired_weight"
if [[ \$expected_availability -gt \$desired_weight ]];then
   echo "one of the other instances are down"
   exit 1
else
   echo "proceed for restart"
fi


cat lb_pool_status

rm -rf lbpool_list port_list machine_list

"""
  def status = [];
  def data = readFile(file: 'lb_pool_status')
          data.split('\n').each { value ->
                status.add(value)
              }
  sh """ rm -rf lb_pool_status """
  return status
}
}

def WindowsDeploy(){

bat '''
set remoteserver=%ipaddress%
set remotehostname=%machine_name%
IF NOT "%remotehostname%" == "" (
  GOTO chefrun
) ELSE (
  GOTO err
)


:chefrun
C:\\temp\\PSTools\\psexec \\\\%remoteserver% -u administrator -p jdf%remotehostname% -h -accepteula  -i cmd /c "d:\\drfirst\\DFTools\\chefrun.bat"
set exitcode=%errorlevel%
set /a run+=1
IF NOT "%exitcode%" == "0" (
  IF %run% lss 4 (
    timeout 5
    GOTO chefrun
  ) ELSE (
    GOTO error
  )
)

:error
echo Failed with error #%errorlevel%.

:err
echo Please enter valid server name.

'''

}



