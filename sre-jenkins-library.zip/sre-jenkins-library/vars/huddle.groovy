def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        options {
           buildDiscarder(logRotator(numToKeepStr: '50', artifactNumToKeepStr: '50'))
        }

        environment {
          gitCredentialID='svc-automation'
          nexusCred='nexus-cred'
          phpCred='phpCred'
        }

      agent {
          label "mobile-app"
        }
      stages{
      stage('Prepare pipeline'){
      steps {
        script{
          build.prepare_env()

          if ( "${config.on_demand_release_branch}" == "true" )
          {
            build.branchInput()
          }

          env.CD = "${config.CD}"
          env.application_name = "${config.application_name}"
          env.app_platform = "${config.application_name}"
          //env.dev_only_pipeline = "${config.dev_only_pipeline}"
          //env.qa_only_pipeline = "${config.qa_only_pipeline}"
          env.next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
          sh "rm -rf $WORKSPACE/${config.application_name}"

          println "${config.source_code_tool}"
          if ("${config.source_code_tool}" == "git")
          {
            println "git checkout"
            dir("$WORKSPACE/${config.application_name}") {
              git(
                url: config.repository_url,
                credentialsId: env.gitCredentialID,
                branch: "develop"
              )
            }
          }
          }
          }
      }
      stage('quality gate')
      {
        steps{
            script{
             // sleep 6000
              if ("${config.scan}" == "true")
              {
              def scannerHome = tool 'stand-alone-330'
              withSonarQubeEnv('mysonar') {
                sh """
                sed -i 's/use_embedded_jre=true/use_embedded_jre=false/g' ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner
                ${scannerHome}/sonar-scanner-3.3.0.1492-linux/bin/sonar-scanner -Dsonar.projectName=${app_platform}-${application_name} -Dsonar.projectKey=${app_platform}-${application_name} -Dsonar.scm.provider=git -Dsonar.sources=. -Dsonar.java.binaries=**/src/** -Dsonar.exclusions=**/andriod/app/build/**
                """
              }
              }
              else {
                println "no scan "
              }
         }

       }
     }
        stage('build')
        {
          steps {


            script{
            if ( "${config.version_strategy}" == "medhxui")
              {
                container ('sandbox-chef'){
                version=build.getMedhxUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                if (gitCommitNumber.contains("-")){
                  gitCommitNumber="${gitCommitNumber}"
                }else{
                  gitCommitNumber="0-${gitCommitNumber}"
                }
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }


              if ( "${config.CI}" == "true" && "${config.scan}" == "true")
              {
                echo "CI true with scan"
                if ("${config.buildStrategy}" == "huddle-andriod")
                {
                  echo "huddle-andriod build with scan"
                  container('react-native-android'){

                      sh """
                        cd $WORKSPACE/${config.application_name}
                        pwd
                        cat /proc/sys/fs/inotify/max_user_watches
                        echo fs.inotify.max_user_watches=524288 | tee -a /etc/sysctl.conf && sysctl -p
                        cat /etc/sysctl.conf | grep fs.inotify
                        cat /proc/sys/fs/inotify/max_user_watches
                        mv .env.dev .env
                        chmod +x android/gradlew
                        npm i -g envinfo && envinfo
                        yarn install
                        yarn android:build
                       """

                  }

                }
                if ("${config.buildStrategy}" == "huddle-iOS")
                {
                  node ('iOS'){
                  dir("$WORKSPACE/${config.application_name}") {
                    git(
                      url: config.repository_url,
                      credentialsId: env.gitCredentialID,
                      branch: "develop"
                    )
                  }
                  sh """
                    cd $WORKSPACE/${config.application_name}
                    pwd
                    echo $PATH
                    ls /usr/local/bin
                    /usr/local/bin/yarn install
                    /usr/local/bin/yarn pod:install
                    react-native run-ios
                   """
                  }
                }

              }
              else if("${config.CI}" == "true" && "${config.scan}" == "false")
              {
                echo "CI true without scan"
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven build without scan"
                  build.maven_build_withoutScan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle build without scan"
                  build.gradle_build_withoutScan()
                }
              }
              else if("${config.CI}" == "false" && "${config.scan}" == "true")
              {
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven only scan"
                  build.maven_only_scan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle only scan"
                  build.gradle_only_scan()
                }
                else {
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_only("${env.app_platform}","${env.application_name}")
                }
              }
              currentBuild.displayName = "${env.version_display}"
              //build.updateVersionJson("${env.version}")
              //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              //sleep 300

          //upload artifacts
          if ( "${config.pipeline_dev_mode}" == "false" && "${config.CI}" == "true")
            {
              if ("${config.dev_only_pipeline}" == "true" ){
                //delete current build
                container('sandbox-curl'){
                  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
                    sh(script:"""curl --request DELETE --user "\${NEXUSPASS}"  --silent "https://nexusrepo.drfirst.com/nexus/content/repositories/${env.nexus_repository}/${env.groupID}/${env.artifactId}/dev" """,returnStdout: true)
                  }
                }
                //publish new build
                build.publishToNexus(config.application_name,
                "dev",
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              else if ("${config.qa_only_pipeline}" == "true" ){
                //delete current build
                container('sandbox-curl'){
                  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
                    sh(script:"""curl --request DELETE --user "\${NEXUSPASS}"  --silent "https://nexusrepo.drfirst.com/nexus/content/repositories/${env.nexus_repository}/${env.groupID}/${env.artifactId}/dev" """,returnStdout: true)
                  }
                }
                //publish new build
                build.publishToNexus(config.application_name,
                "qa",
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              else {
                build.publishToNexus(config.application_name,
                env.jar_version,
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                //env.jar_location,
                //"$WORKSPACE/${env.jar_location}/${env.jar_name}-${env.jar_version}.jar",
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              //update build details
              if ( "${config.version_strategy}" == "gear"  && "${config.dev_only_pipeline}" != "true"){
                newJson = build.getNewBuildJson(version,(last_build.toInteger()+1).toString(),gitCommitHash)
                println newJson

                sh """
                  echo "${newJson}" > details.json
                """
                build.gitCommitPush(gitCredentialID,"${config.application_name}")
              }

            }
            }
          }
          post {
            failure {
                 script {
                    sleep 30
                }
              }
          }
        }

       /*
       stage('dev deploy')
       {
         when {
          anyOf {
            environment name: 'dev_only_pipeline', value: 'false'
            environment name: 'qa_only_pipeline', value: 'false'
          }
        }
         steps{
          container('sandbox-chef')
          {
            script
            {
              if ( "${config.dev_only_pipeline}" == "true"){
                currentBuild.displayName = "${config.app_type}-dev"
              }
              else {
                currentBuild.displayName = "${env.version_display}"
              }
              if ( "${config.CD}" == "true")
              {
                if ( "${config.config_tagging_enabled}" == "true"){
                    build.svnToGit(env.application_name,config.svn_url,config.git_url,env.gitCredentialID,env.version)
                }
                build.versionupdate_databag(config.dev_repo,env.version,config.app_farm,env.environment,env.gitCredentialID)
                deploy.deploy1stmachine(env.environment,config.app_platform,config.application_name,config.app_farm,env.primaryServerCount)
              }
              else
              {
                println "no deployment"
              }
          }
          }
        }
      }
      stage('QA promote')
      {
        when {
        environment name: 'CD', value: 'true'
        }
        steps
        {
          script{
            if (!config.auto_promote){
             timeout(time: 180, unit: 'SECONDS') {
               input (
                 id: 'Yes',
                 message: 'Promote to QA',
                 submitter: "${env.approver}",
                 submitterParameter:'qaProm'
                 )
               }
             }
            container('sandbox-chef'){

                if ("${config.dev_only_pipeline}" == "true" || "${config.qa_only_pipeline}" == "true"){
                  //println "${config.next_env_pipeline_branch}"
                  next_env_pipeline_branch = "qa_${config.app_farm}"
                  currentBuild.displayName = "${config.app_type}-dev"
                  build.updateJsonVersionDevOnly(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }else if (config.next_env_pipeline_branch != null && !config.next_env_pipeline_branch.trim().isEmpty() ){
                  currentBuild.displayName = "${env.version_display}"
                  next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
                  build.updateJsonVersionDedicateBranch(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }
                else {
                  currentBuild.displayName = "${env.version_display}"
                  build.updateJsonVersion(env.environment,env.version,env.version_display,config.application_name,gitCredentialID)
                }
            }
          }
        }
      }
      */
    }
  }
}
