def branch_generator(app_platform,app_type,environment,ci,application_name,dev_repo,repository_url,branch,source_code_tool)

{
  if (environment == 'dev') {
    environment_name = "Development"
  } else if(environment == 'qa') {
    environment_name = "QA"
  } else if(environment == 'staging') {
    environment_name = "Staging"
  }
  else if(environment == 'prod') {
    environment_name = "Production"
  }
  else if(environment == 'demo') {
    environment_name = "Demo"
  }

  withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS'),usernameColonPassword(credentialsId: 'phpCred', variable: 'phpCred')]) {
      sh """
      rm -rf templates ${app_type}
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/templates.git
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
      cd ${app_type}
      curl -s -u \${phpCred} -XPOST http://10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d \'{"request_type" : "farm_inventory", "environment" :"${environment_name}","app_platform":"${app_platform}", "app_type":"${app_type}", "environment_type": "primary"}\' | jq -r .farm_info[].app_farm > farmlist
      git branch -a | rev | cut -d"/" -f 1 | rev> branchlist
      echo "branchlist in branches"
      cat branchlist

      cat farmlist| while read line || [[ -n "\$line" ]]; do
      if cat branchlist | grep -q "${environment}_\$line"; then
        echo "branch is there--${environment}_\$line"
      else
        git checkout -b ${environment}_\$line
        echo "branch is not there there- ${environment}_\$line"
        application_name="application_name = \\\"`echo $application_name`\\\""
        app_type="app_type = \\\"`echo $app_type`\\\""
        app_platform="app_platform = \\\"`echo $app_platform`\\\""
        environment="environment = \\\"`echo $environment`\\\""
        dev_repo="dev_repo = \\\"`echo $dev_repo`\\\""
        source_code_tool="source_code_tool = \\\"`echo $source_code_tool`\\\""
        app_farm="app_farm = \\\"`echo \$line`\\\""
        ci="CI = \\\"`echo $ci`\\\""
        repository_url=\"repository_url = \\\"`echo $repository_url | sed 's/\\//\\\\\\\\\\\\//g'`\\\"\"
        branch="branch = \\\"`echo $branch`\\\""
        echo "application_name - \$application_name"
        echo "app_type - \$app_type"
        echo "app_platform - \$app_platform"
        echo "dev_repo - \$dev_repo"
        echo "app_farm - \$app_farm"
        echo "environment - \$environment"
        echo "repository_url - \$repository_url"
        echo "source_code_tool - \$source_code_tool"

        if [ "${environment}" == "dev" ] && [ "${ci}" == "true" ]; then
          rm -rf Jenkinsfile details.json
          cp ../templates/dev_jenkinsfile Jenkinsfile
          cp ../templates/dev_details.json details.json
          sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
          sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
          sed -i "1,/app_farm.*/s/app_farm.*/`echo \$app_farm`/g"   Jenkinsfile
          sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile
          sed -i "1,/dev_repo.*/s/dev_repo.*/`echo \$dev_repo`/g"   Jenkinsfile
          sed -i "1,/CI.*/s/CI.*/`echo \$ci`/g"   Jenkinsfile
          sed -i "1,/environment.*/s/environment.*/`echo \$environment`/g"   Jenkinsfile
          sed -i "1,/repository_url.*/s/repository_url.*/`echo \$repository_url`/g"   Jenkinsfile
          sed -i "1,/branch.*/s/branch.*/`echo \$branch`/g"   Jenkinsfile
          sed -i "1,/source_code_tool.*/s/source_code_tool.*/`echo \$source_code_tool`/g"   Jenkinsfile
        elif [ "${environment}" == "dr" ]; then
          cp ../templates/dr_jenkinsfile Jenkinsfile
          sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
          sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
        elif [ "${environment}" == "demo" ]; then
          cp ../templates/demo_jenkinsfile Jenkinsfile
          cp ../templates/qa_details.json details.json
          sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
          sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
          sed -i "1,/app_farm.*/s/app_farm.*/`echo \$app_farm`/g"   Jenkinsfile
          sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile
          sed -i "1,/dev_repo.*/s/dev_repo.*/`echo \$dev_repo`/g"   Jenkinsfile
          sed -i "1,/environment.*/s/environment.*/`echo \$environment`/g"   Jenkinsfile
        else
          rm -rf Jenkinsfile details.json
          cp ../templates/qa_jenkinsfile Jenkinsfile
          cp ../templates/qa_details.json details.json
          sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
          sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
          sed -i "1,/app_farm.*/s/app_farm.*/`echo \$app_farm`/g"   Jenkinsfile
          sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile
          sed -i "1,/dev_repo.*/s/dev_repo.*/`echo \$dev_repo`/g"   Jenkinsfile
          sed -i "1,/environment.*/s/environment.*/`echo \$environment`/g"   Jenkinsfile
        fi;
        git add Jenkinsfile
        git add details.json
        if [ -n \"\$(git status --porcelain)\" ]; then
          git config --global user.email "svc-devops@drfirst.com"
          git config --global user.name "svc-devops"
          git commit --allow-empty -m "update ${environment}_\$line"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git HEAD:"${environment}_\$line" --force
        else
          echo 'no changes';
        fi
      fi;
      done;
      rm -rf templates ${app_type}
      """
    }
}

def dr_branch_generator(app_platform,app_type,environment,application_name)
{
  withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS')]) {
      sh """
      rm -rf templates ${app_type}
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/templates.git
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
      cd ${app_type}
      git branch -a | rev | cut -d"/" -f 1 | rev> branchlist
      echo "branchlist in branches"
      cat branchlist
      if cat branchlist | grep -q "${environment}_deploy"; then
        echo "branch is there--${environment}_deploy"
      else
        git checkout -b "${environment}_deploy"
        echo "branch is not there there- ${environment}_deploy"
        application_name="application_name = \\\"`echo $application_name`\\\""
        app_type="app_type = \\\"`echo $app_type`\\\""
        app_platform="app_platform = \\\"`echo $app_platform`\\\""

        cp ../templates/dr_jenkinsfile Jenkinsfile
        sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
        sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
        sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile

        git add Jenkinsfile

        if [ -n \"\$(git status --porcelain)\" ]; then
          git config --global user.email "svc-devops@drfirst.com"
          git config --global user.name "svc-devops"
          git commit --allow-empty -m "update ${environment}_deploy"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git HEAD:"${environment}_deploy" --force
        else
          echo 'no changes';
        fi
      fi;

      rm -rf templates ${app_type}
      """
    }
}


def feature_branch_generator(app_platform,app_type,dev_code_repo,ci,application_name,dev_repo,repository_url,branch)
{
  withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS')]) {
      sh """
      echo "inside feature"
      rm -rf templates ${app_type} ${app_type}_dev
      mkdir  ${app_type}_dev
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/templates.git
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git
      git clone https://\${GITPASS}@git.drfirst.com/devops-se/${dev_code_repo}.git ${app_type}_dev
      cd ${app_type}_dev

      application_name="application_name = \\\"`echo $application_name`\\\""
      app_type="app_type = \\\"`echo $app_type`\\\""
      app_platform="app_platform = \\\"`echo $app_platform`\\\""
      dev_repo="dev_repo = \\\"`echo $dev_repo`\\\""
      ci="CI = \\\"`echo $ci`\\\""
      repository_url=\"repository_url = \\\"`echo $repository_url | sed 's/\\//\\\\\\\\\\\\//g'`\\\"\"
      branch="branch = \\\"`echo $branch`\\\""
      echo "repository_url- $repository_url"

      git branch -a | rev | cut -d"/" -f 1 | rev|  uniq > ../branchlist_dev
      cat ../branchlist_dev
      if cat ../branchlist_dev | grep -q "feature"; then
        grep "feature" < ../branchlist_dev > ../featurebranchlist
        cd ../${app_type}
        git branch -a | rev |cut -d"/" -f 1 | rev |  uniq > branchlist
        if cat branchlist | grep -q "feature"; then
          grep "feature" < branchlist > featurebranchlist_dev
          cat featurebranchlist_dev | while read line || [[ -n "\$line" ]]; do
            if cat ../featurebranchlist | grep -q "\$line"; then
              echo "branch is there--\$line"
            else
                echo "delete the branch"
                git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git --delete "\${line}"
                echo "\${line} branch deleted"
            fi;
          done;
        fi;
      else
        cd ../${app_type}
        git branch -a | rev | cut -d"/" -f 1 | rev | uniq > branchlist
        if cat branchlist | grep -q "feature"; then
          grep "feature" < branchlist > featurebranchlist_dev
          cat featurebranchlist_dev
          cat featurebranchlist_dev | while read line || [[ -n "\$line" ]]; do
            echo "delete the branch"
            git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git --delete "\${line}"
            echo "\${line} branch deleted"
          done;
        fi
      fi;
      rm -rf featurebranchlist_dev
      if cat ../branchlist_dev | grep -q "feature"; then
        cat ../featurebranchlist | while read line || [[ -n "\$line" ]]; do
          if cat branchlist | grep -q "\$line"; then
            echo "branch is there--\$line"
          else
            cp ../templates/feature_jenkinsfile Jenkinsfile
            cp ../templates/dev_details.json details.json
            sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"   Jenkinsfile
            sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile
            sed -i "1,/dev_repo.*/s/dev_repo.*/`echo \$dev_repo`/g"   Jenkinsfile
            sed -i "1,/CI.*/s/CI.*/`echo \$ci`/g"   Jenkinsfile
            sed -i "1,/environment.*/s/environment.*/`echo \$environment`/g"   Jenkinsfile
            sed -i "1,/repository_url.*/s/repository_url.*/`echo \$repository_url`/g"   Jenkinsfile
            sed -i "1,/branch.*/s/branch.*/`echo \$branch`/g"   Jenkinsfile
            git add Jenkinsfile
            git add details.json
            if [ -n \"\$(git status --porcelain)\" ]; then
              git config --global user.email "svc-devops@drfirst.com"
              git config --global user.name "svc-devops"
              git commit -am "update \$line"
              git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${app_type}.git HEAD:"\$line"
            else
              echo 'no changes';
            fi
          fi;
        done;
      fi;
      rm -rf templates ${app_type} ${app_type}_dev
      """
    }
}


def newKeyCheck()
{
  echo "inprogress"
}
