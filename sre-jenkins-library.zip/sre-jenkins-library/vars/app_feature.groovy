def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        nexusCred='nexus-cred'
      }
      tools {
        gradle 'gradle4.4'
        maven 'maven'
      }
      agent any
      stages{
        stage('build')
        {
         steps
         {
            script
            {
               build.prepare_env()
               println "${env.repository_type}"
               sh "rm -rf $WORKSPACE/${env.application_name}"
             }
             dir("$WORKSPACE/${env.application_name}")
             {
                 git(
                      url: config.repository_url,
                      credentialsId: env.gitCredentialID,
                      branch: config.branch
                    )
            }
            script{
              env.version=config.branch
              echo "version set done- ${env.version}"

              if ( "${env.build_tool}" == "maven")
              {
                echo "maven build"
                build.maven_build(env.MAVEN_SETTINGS_FILE)
              }
              else if("${env.build_tool}" == "gradle"){
                  echo "gradle build"
                  build.gradle_build()
              }
             currentBuild.displayName = "${env.version}"
             container('sandbox-curl'){
               build.nexusCleanup(config.application_name,env.version)
             }
             build.publishToNexus(config.application_name,
                env.version,
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                env.jar_location,
                env.type )
              }
            //junit "/home/jenkins/workspace/${env.application_name}/${env.application_name}/target/surefire-reports/*.xml"
          }
        }
       stage('quality gate')
       {
         steps{
             container('sandbox-curl'){
               script{
                 env.bugCount=build.sonarCheck(env.sonarComponentKeys,'BUG')
                 env.vulnCount=build.sonarCheck(env.sonarComponentKeys,'VULNERABILITY')
                 env.codesmellCount=build.sonarCheck(env.sonarComponentKeys,'CODE_SMELL')
                 echo "sonar - http://172.16.60.248:30616/sonar/dashboard?id=${env.sonarComponentKeys} \n bugcount - $env.bugCount \n vulnCount - $env.vulnCount \n codesmellCount - $env.codesmellCount"

               }
             }
          }
      }

      stage('deploy')
      {
        steps{
          script{
            echo "deploy in dedicated branch machine"
          }
        }
      }
    }
  }
}
