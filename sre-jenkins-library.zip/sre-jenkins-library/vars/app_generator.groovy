def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      options {
                buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
              }

      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent any
       stages{
         stage('generator')
         {
           steps{
            container('sandbox-chef')
             {
               script{
                 print "config.app_platform - ${config.app_platform}"
                 print "config.app_type - ${config.app_type}"
                 print "config.application_name - ${config.application_name}"
                 if ( "${config.CI}" == "true")
                  {
                    generator.feature_branch_generator(config.app_platform,config.app_type,config.dev_repo,config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch)
                  }
                 generator.branch_generator(config.app_platform,config.app_type,'dev',config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch,config.source_code_tool)
                 generator.branch_generator(config.app_platform,config.app_type,'qa',config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch,config.source_code_tool)
                 generator.branch_generator(config.app_platform,config.app_type,'staging',config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch,config.source_code_tool)
                 generator.branch_generator(config.app_platform,config.app_type,'prod',config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch,config.source_code_tool)
                 generator.dr_branch_generator(config.app_platform,config.app_type,'dr',config.application_name)
                 //generator.branch_generator(config.app_platform,config.app_type,'demo',config.CI,config.application_name,config.dev_repo,config.repository_url,config.branch,config.source_code_tool)

               }
             }
           }
         }
        }
      }
    }
