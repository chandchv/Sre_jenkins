def dr_deploy(environment,app_platform,app_type)
{
    if (environment == 'dev') {
      environment_name = "Development"
    } else if(environment == 'qa') {
      environment_name = "QA"
    } else if(environment == 'staging') {
      environment_name = "Staging"
    }
    else if(environment == 'prod') {
      environment_name = "Production"
    }
    else if(environment == 'demo') {
      environment_name = "Demo"
    }
    withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS'),usernameColonPassword(credentialsId: 'phpCred', variable: 'phpCred')]) {
      sh """
      curl -s -u \${phpCred} -XPOST http://10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d \'{"request_type" : "farm_inventory", "environment" :"${environment_name}","app_platform":"${app_platform}", "app_type":"${app_type}", "environment_type": "dr"}\' | jq -r .farm_info[].app_farm > farmlist
          cat farmlist| while read line || [[ -n "\$line" ]]; do
            curl -s -u "\${phpCred}" -XPOST http://\${phpCred}@10.100.16.23/portal/sysops/vm_farm_inventory_api.php -d "{\\"request_type\\" : \\"app_inventory\\",\\"environment\\" : \\"${environment_name}\\",\\"app_platform\\":\\"${app_platform}\\",\\"app_type\\":\\"${app_type}\\",\\"environment_type\\":\\"dr\\", \\"app_farm\\":\\"\${line}\\"}" > machine_list
            cat machine_list | jq '.host_info[] | .host_name' > machines
            mch=\$(<machines)
            cat machines| while read line || [[ -n "\$line" ]]; do
            machine_name=\$line
            echo \$machine_name
            eval "knife node show \$machine_name"
            #eval "knife ssh 'name:\$machine_name' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"sudo  echo '{\\\\\\"application_management\\\\\\":{\\\\\\"enable_loadbalancer\\\\\\":\\\\\\"true\\\\\\"}}' | sudo chef-client -j /dev/stdin\\\""
          done;
      done;
      rm -rf machine_list machines
       """
 }
}
def dr_update(environment,application_name,app_platform,app_type,version)
{
  withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS')]) {
    sh """
      cd /tmp
      application_name=${application_name}
      rm -rf \$repo_url
      git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${application_name}.git
      cd \$application_name
      git checkout dr_deploy
      git config --global user.email 'svc-devops'
      git config --global user.name 'svc-devops@drfirst.com'
      environment="environment=\\\"`echo \$environment`\\\""
      application_name="application_name=\\\"`echo \$application_name`\\\""
      app_platform="app_platform=\\\"`echo \$app_platform`\\\""
      app_type="app_type=\\\"`echo \$app_type`\\\""
      version="version=\\\"`echo \$version`\\\""

      sed -i "1,/environment.*/s/environment.*/`echo \$environment`/g"  "Jenkinsfile"
      sed -i "1,/application_name.*/s/application_name.*/`echo \$application_name`/g"  "Jenkinsfile"
      sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"  "Jenkinsfile"
      sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"  "Jenkinsfile"
      sed -i "1,/version.*/s/version.*/`echo \$version`/g"  "Jenkinsfile"
      if [ -n \"\$(git status --porcelain)\" ]; then
          echo "change"
          git commit -am "dr update for \${environment}"
          git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${application_name}.git HEAD:dr_deploy
      else
          echo 'no changes';
      fi
    """
  }
}
  def dr_jobTrigger(app_platform,app_name,environment,app_type)
  {
    if (environment == 'dr') {
      branch_name = "dr_deploy"
    } else if(environment == 'qa-prod') {
      branch_name = "qa_${app_type}-prod"
    }
    withCredentials([usernameColonPassword(credentialsId: 'jenkins-api', variable: 'JENKINSAPI')]) {
      sh """
      curl -X POST -u \${JENKINSAPI} "http://cicd.dfcorp.drfirst.com/job/${app_platform}-${app_name}/job/${branch_name}/build?token=BUILD_TOKEN"

    """
    }
  }
  def qa_update(environment,application_name,app_platform,app_type,version)
  {
    withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS')]) {
      sh """
        cd /tmp
        application_name=${application_name}
        rm -rf \$application_name
        git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${application_name}.git
        cd \$application_name
        git branch -a | rev | cut -d"/" -f 1 | rev> branchlist
        echo "branchlist in branches"
        cat branchlist
        if cat branchlist | grep -q "qa_${app_type}-prod"; then
          git checkout qa_${app_type}-prod
          git config --global user.email 'svc-devops'
          git config --global user.name 'svc-devops@drfirst.com'
          version="version=\\\"`echo \$version`\\\""
          autodeploy_1stmachine="\\\"autodeploy_1stmachine\\\": \\\"true\\\"",
          autodeploy_allmachine="\\\"autodeploy_allmachine\\\": \\\"true\\\"",

          sed -i "1,/\"autodeploy_1stmachine.*/s/\"autodeploy_1stmachine.*/`echo \$autodeploy_1stmachine`/g"  "details.json"
          sed -i "1,/\"autodeploy_allmachine.*/s/\"autodeploy_allmachine.*/`echo \$autodeploy_allmachine`/g"  "details.json"
          sed -i "1,/version.*/s/version.*/`echo \$version`/g"  "Jenkinsfile"
          if [ -n \"\$(git status --porcelain)\" ]; then
              echo "change"
              git commit -am "dr update for \${environment}"
              git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/\${application_name}.git HEAD:qa_${app_type}-prod
          else
              echo 'no changes';
          fi
        else
          echo "qa-prod branch is not there"
        fi
      """
    }
  }
