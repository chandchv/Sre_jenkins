def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        environment {
          gitCredentialID='svc-automation'
          nexusCred='nexus-cred'
          phpCred='phpCred'
        }

      agent {
          label "jnlp-base"
        }
      stages{
        stage('build')
        {
          steps {
            script{
              build.prepare_env()
              println "${config.on_demand_release_branch}"
              println "${env.repository_type}"
              env.application_name = "${config.application_name}"
              env.app_platform = "${config.app_platform}"
              env.primary_farm = "${config.primary_farm}"
              if ( "${config.on_demand_release_branch}" == "true" )
              {
                build.branchInput()
              }
              else
              {
                env.branch = "${config.branch}"
              }
              env.CD = "${config.CD}"
              env.dev_only_pipeline = "${config.dev_only_pipeline}"
              env.next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
              sh "rm -rf $WORKSPACE/${config.application_name}"

              println "${config.source_code_tool}"
              if ("${config.source_code_tool}" == "git")
              {
                println "git checkout"
              dir("$WORKSPACE/${config.application_name}") {
                  git(
                    url: config.repository_url,
                    credentialsId: env.gitCredentialID,
                    branch: env.branch
                  )
                }
              }
            }
            script{
            echo "${env.extraRepo} - extrarepo"
              // check out extra repo is configured
              if("${env.extraRepo}" == "true" && "${config.scan}" == "true")
              {
                echo "there is extra repo"
                build.cloneExtraRepo()
              }
              // version strategy
              //no build but scan and deploy - with need version inpout
              if ( "${config.CI}" == "false" && "${config.scan}" == "true" &&  "${config.CD}" == "true" && "${config.config_tagging_enabled}" != "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.version_strategy}" == "pom")
              {
              container ('sandbox-git'){
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                //env.jar_version="${version}-0"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                //env.version_display="${version}"
                //env.version="${version}.0"
                gitCommitNumber=build.getBuildFromGit()
                println "commit number from git describe - ${gitCommitNumber}"
                env.jar_version="${version}-${gitCommitNumber}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
                }
              }
              else if ( "${config.version_from_pom}" == "true")
              {
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                env.jar_version="${version}"
                env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else { // otherwise getting version from git
                version=build.getVersion()
                println "version from git -  ${version}"
                env.version="${version}"
                env.version_display="${version}"
                env.jar_version="${version}"
              }


              if ( "${config.CI}" == "true" && "${config.scan}" == "true")
              {
                echo "CI true with scan"
                if ( "${env.build_tool}" == "maven")
                {
                    scannerHome = tool 'stand-alone-330'
                    build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                    container ('jnlp'){
                    //tool 'maven'
                    echo "maven build with scan"
                    build.maven_build_withScan_lib(env.MAVEN_SETTINGS_FILE)
                    }
                }
              }
              else if("${config.CI}" == "false" && "${config.scan}" == "true")
              {
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven only scan"
                  build.maven_only_scan(env.MAVEN_SETTINGS_FILE)
                }
                else {
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_only("${env.app_platform}","${env.application_name}")
                }
              }
              currentBuild.displayName = "${env.version_display}"
              //build.updateVersionJson("${env.version}")
              //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              //sleep 300

          //upload artifacts
            }
          }
          post {
            failure {
                 script {
                    sleep 5
                }
              }
          }
        }
        stage('quality gate')
        {
          steps{
            container('sandbox-curl'){
              script{
                //sleep 6000
                if ("${config.scan}" == "true")
                {
                  //timeout(time: 5, unit: 'MINUTES') {
                  //  waitForQualityGate abortPipeline: true
                  //}
                  currentBuild.displayName = "${env.version_display}"
                  env.bugCount=build.sonarCheck('BUG')
                  env.vulnCount=build.sonarCheck('VULNERABILITY')
                  env.codesmellCount=build.sonarCheck('CODE_SMELL')
                  echo "sonar - ${env.SONAR_HOST_URL}/dashboard?id=${env.app_platform}-${env.application_name} \n bugcount - $env.bugCount \n vulnCount - $env.vulnCount \n codesmellCount - $env.codesmellCount"
                }
                else {
                  println "no scan "
                }
           }
           }
         }
       }
       stage('dev deploy')
       {
        steps{
          container('sandbox-chef')
          {
            script
            {
              if ( "${config.dev_only_pipeline}" == "true"){
                currentBuild.displayName = "${config.app_type}-dev"
              }
              else {
                currentBuild.displayName = "${env.version_display}"
              }
              if ( "${config.CD}" == "true")
              {
                if ( "${config.config_tagging_enabled}" == "true"){
                    build.svnToGit(env.application_name,config.svn_url,config.git_url,env.gitCredentialID,env.version)
                }
                build.versionupdate_databag(config.dev_repo,env.version,config.app_farm,env.environment,env.gitCredentialID)
                deploy.deploy1stmachine(env.environment,config.app_platform,config.application_name,config.app_farm,env.primaryServerCount)
              }
              else
              {
                println "no deployment"
              }
          }
          }
        }
      }
    }
  }
}
