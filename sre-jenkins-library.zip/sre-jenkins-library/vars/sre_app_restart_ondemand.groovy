def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        options {
                buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
              }
		parameters {
           string defaultValue: '', description: 'hostname ', name: 'nodeName', trim: true
           choice choices: ['prod', 'staging'], description: 'Environment', name: 'node_environment'
		       choice choices: ['primary', 'dr'], description: 'Datacenter', name: 'node_datacenter'
           }
	  environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "vsphere"
      }
      stages{
        stage('Get Server details'){
          steps {
            container('chef-vsphere'){
            script{
			             currentBuild.displayName = env.nodeName

			          // below function will get the node details app_type,datacenter,app_environment,app_farm,app_platform,app_ports,ipaddress,node_os
			             noc_utils.getNodeDetails(env.nodeName)

			         // Below function will get the webserver type
			            env.webServerType=sre_utils.getWebServerType(env.app_platform,env.app_type,env.app_farm,env.node_environment,env.node_datacenter)

			         // to get the restricted group details
			            noc_utils.restrictedGroup(env.nodeName)
			            
			         // lb status check 
			            env.LBstatus=sre_utils.getLbStatus(env.app_environment,env.app_platform,env.app_type,env.app_farm,env.nodeName,env.datacenter,env.node_datacenter)

			        // depending up on webserver type building the command
                if( env.webServerType == "tomcat" ) {
                  env.tomcat_version=sre_utils.getTomcatversion()
                  if( env.tomcat_version == '7'){
                    env.chefCommand="sudo service tomcat7-51001 restart;sudo service tomcat7-51002 restart; /app/utilities/pdv.sh "
                  }
                  else if(env.tomcat_version == '8'){
                     env.chefCommand="sudo service tomcat8-51001 restart;sudo service tomcat8-51002 restart; /app/utilities/pdv.sh "
                  }
                }
                else if( env.webServerType == "karaf" ){
                  env.chefCommand="sudo -u appuser /app/karaf/instances/${env.nodeName}_52001/bin/stop; sudo -u appuser /app/karaf/instances/${env.nodeName}_52001/bin/start; sudo -u appuser /app/karaf/instances/${env.nodeName}_52002/bin/stop;sudo -u appuser /app/karaf/instances/${env.nodeName}_52002/bin/start; /app/utilities/pdv.sh "
                }
                else {
                  println('This webserver type is not supported for restart')
                  sh " exit 1 "
                }
            }
          }
        }
      }

        stage('App restart'){
          steps{

            container('chef-vsphere'){
            script{
              currentBuild.displayName = env.nodeName

            	if (config.executionComponents.contains('disableLb')){
					(env.app_ports.tokenize(',[]"')).each { port ->
						noc_utils.instanceLbDisable(env.app_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
					}
				}
				if (config.executionComponents.contains('chefSimpleCommand')){
					noc_utils.chefSimpleCommand(env.nodeName,env.chefCommand,env.rGroup)
				}
				if (config.executionComponents.contains('enableLb')){
					(env.app_ports.tokenize(',[]"')).each { port ->
					   noc_utils.instanceLbEnable(env.app_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                    }
                }
			
            }
          }
         }
      }
     }
     post {
        success {
	        script{
		        common.sparkNotify("${env.nodeName}", "${env.node_environment}", "${config.spaceId}" ,"${config.spaceName }", 'Success')
            }
        }
        failure {
	        script{
		        common.sparkNotify("${env.nodeName}", "${env.node_environment}", "${config.spaceId}" ,"${config.spaceName }", 'Fail')
            }
        }
    }
  }
}
