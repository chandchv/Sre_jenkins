  def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "agent1"
      }
      stages{
        stage('prep env')
        {
          steps
          {
            container('sandbox-python'){
            script{
              common.uuidGen()
              currentBuild.description = env.jobUuid
              deploy.prepare_env()
              env.app_platform="${config.app_platform}"
              env.version="${config.version}"
              env.primary_farm="${config.primary_farm}"
              env.primaryServerCount=awscommon.getServerCount(config.aws_application_type,config.aws_environment,config.ec2_component,config.consul_auth_id)
              //env.drServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
              env.primaryDatacenter=common.getPrimaryDatacenter(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.primaryDatacenter=env.primaryDatacenter
              env.inventory="${config.inventory}"
              env.aws_application_type="${config.aws_application_type}"
              env.aws_environment="${config.aws_environment}"
              env.ec2_component="${config.ec2_component}"
              if (config.enableParallelDeploy){
                desiredParallelState = true
              } else {
                desiredParallelState = false
              }
              env.parallelDeployConfig=deploy.getParallelDeployConfig(env.primaryServerCount.toInteger(),desiredParallelState)

            }
          }
          }
        }
        stage('click to approve'){
          steps{
            script{
            currentBuild.displayName = config.build_name
            if ( "${env.autodeploy_1stmachine}" == "false")
              {
                timeout(time: 180, unit: 'SECONDS') {
                input (
                  id: 'Yes',
                  message: "Promote to ${config.environment}",
                  submitter: "${env.approver}",
                  submitterParameter:'qaProm'
                  )
                }
              }
            }
          }
        }
        stage('1st server')
        {
          steps{
            container('sandbox-chef')
            {
              script{
              println "pServerCount: ${env.primaryServerCount}"
              println "pDrCount: ${env.drServerCount}"
              println "parallel: ${env.parallelDeployConfig}"
              println "primaryDC: ${env.primaryDatacenter}"
              println "${config.version}"
              println "${env.autodeploy_1stmachine}"
              println "${env.autodeploy_allmachine}"
              env.environment = "${config.environment}"
              println "config.env - ${config.environment}"
              currentBuild.displayName = config.build_name

                 echo "deploy 1st machine "
                 println "reponame: ${config.repo_name}"
                 awscommon.versionupdate_databag(config.repo_name,env.version,config.app_farm,env.environment,env.gitCredentialID)
                 awscommon.deploy1stmachine(config.aws_application_type,config.aws_environment,config.ec2_component,primaryServerCount)
               //build.updateStage("1")
               //build.gitCommitPush(gitCredentialID,"${config.application_name}")
             }
            }
          }
        }
        stage("DeployAll")
        {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          steps
            {
            container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = config.build_name
                 if ("${env.autodeploy_allmachine}" == "false")
                  {
                    timeout(time: 180, unit: 'SECONDS') {
                    input (
                        id: 'Yes',
                        message: "Proceed to the rest of the servers",
                        submitter: "${env.approver}"
                      )
                    }
                  }
                  awscommon.getPrimaryList(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
                  rabbitmq.populateDeployItems(env.jobUuid,0)
                  //build.gitCommitPush(gitCredentialID,"${config.application_name}")
                  //echo "env.primary_farm - ${env.primary_farm}"
              }
            }
          }
        }

        stage('parallel deploy') {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          failFast true
          parallel {
          stage('worker1'){
            steps {
                script{
                  currentBuild.description = env.jobUuid
                  currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      echo env.jobUuid
                      awscommon.consumeDeployItem(env.jobUuid,'enable','1')
                    }
                }
             }
          }
          stage('worker2'){
             steps {
                 script{
                   currentBuild.description = env.jobUuid
                   currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      awscommon.consumeDeployItem(env.jobUuid,env.parallelDeployConfig,'2')
                  }
                 }
               }
             }
          }
          post {
            success {
               script {
                 container('sandbox-chef'){
                 rabbitmq.deleteQueue(env.jobUuid)
               }
              }
            }
            failure {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
            aborted {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
          }
        }

        stage("Promote ")
        {
          when {
          environment name: 'primary_farm', value: 'true'
          }

          steps {

            container('sandbox-chef'){
            timeout(time: 60, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "promote to ${env.promenv}",
              submitter: "${env.approver}"
              )
            }
            script{
              currentBuild.description = env.jobUuid
              currentBuild.displayName = config.build_name
              if (config.environment != 'prod') {
                println "build nmae - ${config.build_name}"
                if (config.next_env_pipeline_branch != null && !config.next_env_pipeline_branch.trim().isEmpty() ){
                  next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
                  build.updateJsonVersionDedicateBranch(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }
                else {
                  build.updateJsonVersion(config.environment,config.version,config.build_name,config.application_name,gitCredentialID)
                //build.gitCommitPush(gitCredentialID,"${config.application_name}")
               }
              }
            }
          }
        }
        }
      }
    }
  }
