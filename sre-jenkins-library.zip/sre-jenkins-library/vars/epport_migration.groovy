def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        environment {
          gitCredentialID='svc-automation'
          branch='master'
          phpCred='phpCred'
        }
        agent {
          label "vsphere"
        }
        stages{
            stage('git_checkout'){
                steps{
                         script{
                                println "${config.source_code_tool}"
                                env.project_name = "${config.project_name}"
                                env.repo_name = "${config.repo_name}"
                                if ("${config.source_code_tool}" == "git")
                                {
                                     println "git checkout"
                                     dir("$WORKSPACE/${config.project_name}") {
                                        git(
                                            url: config.repository_url,
                                            credentialsId: env.gitCredentialID,
                                            branch: env.branch
                                         )
                                    }

                                }
                            }
                         }
                    }

            stage('get_input'){
                steps{
                    script{

                            sre_utils.dropdownEnvInput()
                            sre_utils.affnameInput()

                    }


                }

            }
            stage('execute_queue_creation'){
                steps{
                    container('sandbox-python'){
                        script{

                            sre_utils.queueCreation()

                        }
                    }

                }

            }
            stage('reboot_instances'){
                    steps {
                        container('chef-vsphere'){
                            script{
                                env.serverlist=deploy.getServerList('epcs','epcsepportlistener','epcs2-epport-listener',env.environment,'primary')
                                println "Serverlist is " +env.serverlist
                                (env.serverlist.tokenize(' ,[] ')).each { server ->
                                env.nodeName=server
                                println "get node details"
                                noc_utils.getNodeDetails(server)
                                (env.app_ports.tokenize(',[]"')).each { port ->
                                noc_utils.instanceLbDisable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                                }
                                noc_utils.chefSimpleCommand(env.nodeName,config.chefCommand,5)
                                (env.app_ports.tokenize(',[]"')).each { port ->
                                noc_utils.instanceLbEnable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                                }
                            }
                        }
                    }
                }
            }
            stage('execute_channel_modification'){
                steps{
                    container('sandbox-python'){
                        script{

                            sre_utils.channelMod()
                        }
                    }
                    script{
                    sre_utils.gitCommitPush(env.gitCredentialID,"${config.repo_name}")
                    }
                }

            }
            stage('add_zabbix_monitoring'){
                steps{
                    container('sandbox-python'){
                        script{
                          currentBuild.displayName = "${env.environment}-${env.affiliates}"
                          sh """
                            cd $WORKSPACE/${env.project_name}
                            python zabbix_monit.py ${env.environment} ${env.affiliates}
                          """
                        }
                    }
                }
            }
        }
    }

}
