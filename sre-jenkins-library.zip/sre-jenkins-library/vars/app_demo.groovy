def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent any
      properties([
      parameters([
        string(name: 'version', defaultValue: '', description: 'application version', )
        ])
      ])
      stages{
        stage('load base env value')
        {
          steps
          {
            script{
              deploy.prepare_env()
            }
          }
        }
        stage('1st machine deploy')
        {
          steps{
            container('sandbox-chef')
            {
              script{
              println "${env.autodeploy_1stmachine}"
              println "${env.autodeploy_allmachine}"
              env.environment = "${config.environment}"
              println "config.env - ${config.environment}"
              currentBuild.displayName = "${env.version}"
              if ( "${env.autodeploy_1stmachine}" == "true")
                {
                  echo "auto deploy 1st machine -${env.autodeploy_1stmachine}"
                  build.versionupdate_databag(config.repo_name,env.config,config.application_name,config.environment,gitCredentialID)
                  deploy.deploy1stmachine(config.environment,config.platform,config.application_name,config.app_farm)

                }
              else
                {
                 timeout(time: 180, unit: 'SECONDS') {
                 input (
                   id: 'Yes',
                   message: "Promote to ${config.environment}",
                   submitter: "${env.approver}",
                   submitterParameter:'qaProm'
                   )
                 }
                 echo "deploy 1st machine after promotion- $config.autodeploy_1stmachine"
                 build.versionupdate_databag(config.repo_name,env.version,config.application_name,config.environment,gitCredentialID)
                 deploy.deploy1stmachine(config.environment,config.platform,config.application_name,config.app_farm)

               }
               //build.updateStage("1")
               build.gitCommitPush(gitCredentialID,"${config.application_name}")
             }
            }
          }
        }
        stage("DeployAll")
        {
          steps
            {
            container('sandbox-chef'){
              script{
                 if ("${env.autodeploy_allmachine}" == "true")
                  {
                    echo "auto deploy in all machine -- $env.autodeploy_allmachine"
                    build.versionupdate_databag(config.repo_name,env.version,config.app_farm,config.environment,gitCredentialID)
                    deploy.deployAllmachine(config.environment,config.platform,config.application_name,config.application_name)
                    build.gitCommitPush(gitCredentialID,"${config.application_name}")
                  }
                else {
                  timeout(time: 180, unit: 'SECONDS') {
                  input (
                      id: 'Yes',
                      message: "Promote to ${config.environment}",
                      submitter: "${env.approver}",
                      submitterParameter:'qaProm'
                    )
                  }
                  echo "deploy in all machine after prmotion - $config.autodeploy_allmachine"
                  build.versionupdate_databag(config.repo_name,env.version,config.app_farm,config.environment,gitCredentialID)
                  deploy.deployAllmachine(config.environment,config.platform,config.application_name,config.application_name)
                  build.gitCommitPush(gitCredentialID,"${config.application_name}")
                  echo "env.primary_farm - ${env.primary_farm}"
                }
              }
            }
          }
        }

        stage("dr deploy")
          {
              steps{
              script{
                dr.dr_update(config.environment,config.application_name,config.app_platform,config.app_type,env.version)
                dr.dr_jobTrigger(config.app_platform,config.application_name,'dr',config.app_type)
              }
            }
          }

      }
    }
  }
