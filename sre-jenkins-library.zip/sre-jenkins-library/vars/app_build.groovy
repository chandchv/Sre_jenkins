def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
        options {
           buildDiscarder(logRotator(numToKeepStr: '50', artifactNumToKeepStr: '50'))
        }

        environment {
          gitCredentialID='svc-automation'
          nexusCred='nexus-cred'
          phpCred='phpCred'
        }

      agent {
          label "jnlp-base"
        }
      stages{
        stage('build')
        {
          steps {
            script{
              build.prepare_env()
              println "${config.on_demand_release_branch}"
              println "${env.repository_type}"
              container('sandbox-chef'){
              env.primaryServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              }
              env.application_name = "${config.application_name}"
              env.app_platform = "${config.app_platform}"
              env.primary_farm = "${config.primary_farm}"
              env.app_farm = "${config.app_farm}"
              if ( "${config.on_demand_release_branch}" == "true" )
              {
                build.branchInput()
              }
              else if ( "${config.dev_only_pipeline}" == "true" &&  "${config.qa_only_pipeline}" == "true" )
              {
                build.dropdownBranchInput()
              }
              else
              {
                env.branch = "${config.branch}"
              }
              env.CD = "${config.CD}"
              //env.dev_only_pipeline = "${config.dev_only_pipeline}"
              //env.qa_only_pipeline = "${config.qa_only_pipeline}"
              env.next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
              sh "rm -rf $WORKSPACE/${config.application_name}"

              println "${config.source_code_tool}"
              if ("${config.source_code_tool}" == "git")
              {
                println "git checkout"
              dir("$WORKSPACE/${config.application_name}") {
                  git(
                    url: config.repository_url,
                    credentialsId: env.gitCredentialID,
                    branch: env.branch
                  )
                }
                if ("${config.buildStrategy}" == "angular2"){
                  sleep 3000
                }
              }
              else if ("${config.source_code_tool}" == "svn")
              {
                  println "svn checkout"
                  dir("$WORKSPACE/${config.application_name}") {
                  checkout(
                    [$class: 'SubversionSCM',
                    additionalCredentials: [],
                    excludedCommitMessages: '',
                     excludedRegions: '',
                     excludedRevprop: '',
                     excludedUsers: '',
                     filterChangelog: false,
                     ignoreDirPropChanges: false,
                     includedRegions: '',
                    locations: [[cancelProcessOnExternalsFail: true, credentialsId: 'svn-automation', depthOption: 'infinity', ignoreExternalsOption: false, local: '.',
                    remote: "${config.repository_url}/branches/${config.branch}"]],
                    quietOperation: false, workspaceUpdater: [$class: 'UpdateUpdater']])
                }
              }

            }
            script{
            echo "${env.extraRepo} - extrarepo"
              // check out extra repo is configured
              if("${env.extraRepo}" == "true" && "${config.scan}" == "true")
              {
                echo "there is extra repo"
                build.cloneExtraRepo()
              }
              // version strategy
              //no build but scan and deploy - with need version inpout
              if ( "${config.CI}" == "false" && "${config.scan}" == "true" &&  "${config.CD}" == "true" && "${config.config_tagging_enabled}" != "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.CI}" == "false" && "${config.app_type}" == "platformservices" && "${config.scan}" == "false" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"
                

              }
              else if ( "${config.CI}" == "false" && "${config.app_type}" == "pfcentral" && "${config.scan}" == "false" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.CI}" == "false" && "${config.app_type}".startsWith("ss2")  && "${config.scan}" == "false" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}"

              }
              else if ( "${config.version_strategy}" == "medhxui")
              {
                container ('sandbox-chef'){
                version=build.getMedhxUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                if (gitCommitNumber.contains("-")){
                  gitCommitNumber="${gitCommitNumber}"
                }else{
                  gitCommitNumber="0-${gitCommitNumber}"
                }
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
              else if ( "${config.version_strategy}" == "webui")
              {
                container ('sandbox-chef'){
                version=build.getWebUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
             else if ( "${config.version_strategy}" == "huddleweb")
              {
                container ('sandbox-chef'){
                version=build.getWebUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
              else if ( "${config.version_strategy}" == "pom")
              {
              container ('sandbox-git'){
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                //env.jar_version="${version}-0"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                //env.version_display="${version}"
                //env.version="${version}.0"
                gitCommitNumber=build.getBuildFromGit()
                println "commit number from git describe - ${gitCommitNumber}"
 
                env.jar_version="${version}-${gitCommitNumber}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
                }
              }
              else if ( "${config.version_strategy}" == "gear")
              {
               container ('sandbox-git'){      
                gitCommitHash = build.getVersion()
                println gitCommitHash
                build.checkGitCommit(gitCommitHash)
                version = build.getVersionFromGear()
                base_version = build.baseVersionGen(version,2)
                last_build = build.getBuildNumber(version)
                println last_build
                new_build = "B"+(last_build.toInteger()+1).toString()
                println new_build
                
                packaging_type = build.getPackagingFromGear()
                env.jar_version="${version}-${new_build}"
                
                if ( "$packaging_type" == "pom" ){
                    
                    env.jar_location="${env.artifactId}/${env.jar_name}-war/target/"
                    env.jar_name="${env.jar_name}-${env.type}-${env.jar_version}"
                }
                else 
                {
                    env.jar_name="${env.jar_name}-${env.jar_version}"
                }
               
                env.version_display="${version}-${new_build}"
                env.version="${version}.${new_build}"
                //sleep 3600
               }
              }
              else if ( "${config.version_from_pom}" == "true")
              {
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                env.jar_version="${version}"
                env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.version_from_databag}" == "true"){
                build.getVersionFromDatabag("${config.dev_repo}","${config.app_farm}")
                if ("${env.databagBuild}" == "")
                {
                  env.jar_version="${env.databagVersion}"
                  env.version="${env.databagVersion}_0"
                  env.version_display="${env.databagVersion}"
                }
                else
                {
                  env.version="${env.databagVersion}_${env.databagBuild}"
                  env.version_display="${env.databagVersion}_${env.databagBuild}"
                  env.jar_version="${version}"
                }
                println "version from git -  ${env.version}"
              }
              else { // otherwise getting version from git
                version=build.getVersion()
                println "version from git -  ${version}"
                env.version="${version}"
                env.version_display="${version}"
                env.jar_version="${version}"
              }


              if ( "${config.CI}" == "true" && "${config.scan}" == "true")
              {
                echo "CI true with scan"
                if ("${config.buildStrategy}" == "gear")
                {
                  echo "gear build with scan"
                  //build.gear_build_withoutScan(env.MAVEN_SETTINGS_FILE,new_build)
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  build.gear_build_withScan(env.MAVEN_SETTINGS_FILE,new_build)
                }
                else if ( "${env.build_tool}" == "maven")
                {
                    container ('jnlp'){
                    //tool 'maven'
                    echo "maven build with scan"
                    build.maven_build_withScan(env.MAVEN_SETTINGS_FILE)
                    }
                }
                else if ( "${env.build_tool}" == "nodejsandmaven")
                {

                    println "nodejs build with scan"
                    scannerHome = tool 'stand-alone-330'
                    // build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                    container('node-firefox'){
                    build.nodejs_pswbuild()
                    }
                    container ('jnlp'){
                    //tool 'maven'
                    echo "maven build with scan"
                    build.psw_maven_build_withScan(env.MAVEN_SETTINGS_FILE)
                    }
                    echo "scan after build"
                    build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                }
                else if ( "${env.build_tool}" == "iish")
                {
                  //scannerHome = tool 'stand-alone-330'
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                    container ('jnlp'){
                    //tool 'maven'
                    echo "maven build with scan for iish"
                    build.maven_build_iish(env.MAVEN_SETTINGS_FILE)
                    }
                }
                else if("${env.build_tool}" == "gradle"){
                //  tool 'gradle5.2.1'
                  echo "gradle build with scan"
                  build.gradle_build_withScan()
                }

                else if ("${env.build_tool}" == "nodejs")
                {
                  println "nodejs build with scan"
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                    container('node-firefox'){
                      build.nodejs_build()
                  }
                }

                else if ("${env.build_tool}" == "widgets")
                {
                  println "nodejs build with scan"
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-firefox'){
                    build.widgets_build()
                  }
                }

                else if ("${env.build_tool}" == "huddleweb")
                {
                  println "nodejs build with scan"
                  scannerHome = tool 'stand-alone-330'
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-8-9-4'){
                    build.huddleweb_build()
                  }
                }

                else if ("${config.buildStrategy}" == "ilac")
                {
                  println "ilac build"
                  scannerHome = tool 'stand-alone-330'
                  // enabled scan for ilac and iprescribeweb
                  build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-8-9-4'){
                    build.ilac_build(env.environment)
                  }
                }

                else if ("${config.buildStrategy}" == "angular")
                {
                  println "angular build"
                  scannerHome = tool 'stand-alone-330'
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-12'){
                    build.angular_build("${env.version}")
                  }
                }

              }
              else if("${config.CI}" == "true" && "${config.scan}" == "false")
              {
                echo "CI true without scan"
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven build without scan"
                  build.maven_build_withoutScan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle build without scan"
                  build.gradle_build_withoutScan()
                }
              }
              else if("${config.CI}" == "false" && "${config.scan}" == "true")
              {
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven only scan"
                  build.maven_only_scan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle only scan"
                  build.gradle_only_scan()
                }
                else if("${config.jacoco_report}" == "true"){
                  //tool 'gradle3.5' jacoco reports 
		              echo "gradle build with jacoco reports"
                  build.gradle_build_jacocoreport()
                }  
                else {
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_only("${env.app_platform}","${env.application_name}")
                }
              }
              currentBuild.displayName = "${env.version_display}"
              //build.updateVersionJson("${env.version}")
              //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              //sleep 300

          //upload artifacts
          if ( "${config.pipeline_dev_mode}" == "false" && "${config.CI}" == "true")
            {
              if ("${config.dev_only_pipeline}" == "true" ){
                //delete current build
                container('sandbox-curl'){
                  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
                    sh(script:"""curl --request DELETE --user "\${NEXUSPASS}"  --silent "https://nexusrepo.drfirst.com/nexus/content/repositories/${env.nexus_repository}/${env.groupID}/${env.artifactId}/dev" """,returnStdout: true)
                  }
                }
                //publish new build
                build.publishToNexus(config.application_name,
                "dev",
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              else if ("${config.qa_only_pipeline}" == "true" ){
                //delete current build
                container('sandbox-curl'){
                  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
                    sh(script:"""curl --request DELETE --user "\${NEXUSPASS}"  --silent "https://nexusrepo.drfirst.com/nexus/content/repositories/${env.nexus_repository}/${env.groupID}/${env.artifactId}/dev" """,returnStdout: true)
                  }
                }
                //publish new build
                build.publishToNexus(config.application_name,
                "qa",
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              else {
                build.publishToNexus(config.application_name,
                env.jar_version,
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                //env.jar_location,
                //"$WORKSPACE/${env.jar_location}/${env.jar_name}-${env.jar_version}.jar",
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              //update build details
              if ( "${config.version_strategy}" == "gear"  && "${config.dev_only_pipeline}" != "true"){
                newJson = build.getNewBuildJson(version,(last_build.toInteger()+1).toString(),gitCommitHash)
                println newJson

                sh """
                  echo "${newJson}" > details.json
                """
                build.gitCommitPush(gitCredentialID,"${config.application_name}")
              }

            }
            }
          }
          post {
            failure {
                 script {
                    sleep 5
                }
              }
          }
        }
        stage('quality gate')
        {
          steps{
            container('sandbox-curl'){
              script{
               // sleep 6000
                if ("${config.scan}" == "true")
                {
                  //timeout(time: 5, unit: 'MINUTES') {
                  //  waitForQualityGate abortPipeline: true
                  //}
                  currentBuild.displayName = "${env.version_display}"
                  env.bugCount=build.sonarCheck('BUG')
                  env.vulnCount=build.sonarCheck('VULNERABILITY')
                  env.codesmellCount=build.sonarCheck('CODE_SMELL')
                  echo "sonar - ${env.SONAR_HOST_URL}/dashboard?id=${env.app_platform}-${env.application_name} \n bugcount - $env.bugCount \n vulnCount - $env.vulnCount \n codesmellCount - $env.codesmellCount"
                }
                else {
                  println "no scan "
                }
           }
           }
         }
       }
       stage('dev deploy')
       {
         when {
          anyOf {
            environment name: 'dev_only_pipeline', value: 'false'
            environment name: 'qa_only_pipeline', value: 'false'
          }
        }
         steps{
          container('sandbox-chef')
          {
            script
            {
              if ( "${config.dev_only_pipeline}" == "true"){
                currentBuild.displayName = "${config.app_type}-dev"
              }
              else {
                currentBuild.displayName = "${env.version_display}"
              }
              if ( "${config.CD}" == "true")
              {
                if ( "${config.config_tagging_enabled}" == "true"){
                    build.svnToGit(env.application_name,config.svn_url,config.git_url,env.gitCredentialID,env.version)
                }
                build.versionupdate_databag(config.dev_repo,env.version,config.app_farm,env.environment,env.gitCredentialID)
                deploy.deploy1stmachine(env.environment,config.app_platform,config.application_name,config.app_farm,env.primaryServerCount)
              }
              else
              {
                println "no deployment"
              }
          }
          }
        }
      }
      stage('QA promote')
      {
        when {
        environment name: 'CD', value: 'true'
        }
        steps
        {
          script{
            if (!config.auto_promote){
             timeout(time: 180, unit: 'SECONDS') {
               input (
                 id: 'Yes',
                 message: 'Promote to QA',
                 submitter: "${env.approver}",
                 submitterParameter:'qaProm'
                 )
               }
             }
            container('sandbox-chef'){

                if ("${config.dev_only_pipeline}" == "true" || "${config.qa_only_pipeline}" == "true"){
                  //println "${config.next_env_pipeline_branch}"
                  next_env_pipeline_branch = "qa_${config.app_farm}"
                  currentBuild.displayName = "${config.app_type}-dev"
                  build.updateJsonVersionDevOnly(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }else if (config.next_env_pipeline_branch != null && !config.next_env_pipeline_branch.trim().isEmpty() ){
                  currentBuild.displayName = "${env.version_display}"
                  next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
                  build.updateJsonVersionDedicateBranch(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }
                else {
                  currentBuild.displayName = "${env.version_display}"
                  build.updateJsonVersion(env.environment,env.version,env.version_display,config.application_name,gitCredentialID)
                }
            }
          }
        }
      }
    }
  }
}
