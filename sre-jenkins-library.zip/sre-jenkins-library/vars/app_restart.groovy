def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    def param = " ${config.Minute} ${config.Hour} ${config.DOM} ${config.MONTH} ${config.DOW} "
    pipeline {
      options {
                buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
              }    
	  triggers { cron("${param}")}
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "vsphere"
      }
      stages{
        stage('Get Server details'){
          steps {
            container('chef-vsphere'){
            script{
			   currentBuild.displayName = config.application_name
			   env.environmentType=deploy.getEnvType(config.primary_site,config.dr_site)
			   env.serverlist=deploy.getServerList(config.app_platform,config.app_type,config.app_farm,config.environment,env.environmentType)
			  
            }
          }
        }
      }

        stage('execution'){
          steps{
            
            container('chef-vsphere'){
            script{
              currentBuild.displayName = config.application_name
			  (env.serverlist.tokenize(' ,[] ')).each { server ->
			    env.nodeName=server
				println "get restricted Group details"
				noc_utils.restrictedGroup(server)
				println "get node details"
                noc_utils.getNodeDetails(server)
            	if (config.executionComponents.contains('disableLb')){
					(env.app_ports.tokenize(',[]"')).each { port ->
						noc_utils.instanceLbDisable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
					}
				}
				if (config.executionComponents.contains('knifeReboot')){
					noc_utils.knifeReboot(env.nodeName,env.app_environment,env.datacenter,env.rGroup)
				}
				if (config.executionComponents.contains('chefSimpleCommand')){
				    if(config.chefCommand == 'karaf_restart'){
				        env.chefCommand="sudo -u appuser /app/karaf/instances/${env.nodeName}_52001/bin/stop; sudo -u appuser /app/karaf/instances/${env.nodeName}_52001/bin/start; sudo -u appuser /app/karaf/instances/${env.nodeName}_52002/bin/stop;sudo -u appuser /app/karaf/instances/${env.nodeName}_52002/bin/start; /app/utilities/pdv.sh "
                        noc_utils.chefSimpleCommand(env.nodeName,env.chefCommand,env.rGroup)
                    }else{
                        noc_utils.chefSimpleCommand(env.nodeName,config.chefCommand,env.rGroup)
                    }
					
				}
				if (config.executionComponents.contains('enableLb')){
					(env.app_ports.tokenize(',[]"')).each { port ->
					   noc_utils.instanceLbEnable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                    }
                }
				sleep 60
			  }
            }
          }
         }
      }
     }
     post {
        success {
	        script{
		        common.sparkNotify("${config.application_name}", "${config.environment}", "${config.spaceId}" ,"${config.spaceName }", 'Success')
            }
        }
        failure {
	        script{
		        common.sparkNotify("${config.application_name}", "${config.environment}", "${config.spaceId}" ,"${config.spaceName }", 'Fail')
            }
        }
    }
  }
}
