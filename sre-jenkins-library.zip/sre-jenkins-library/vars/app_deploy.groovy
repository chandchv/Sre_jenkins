def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      options {
           buildDiscarder(logRotator(numToKeepStr: '50', artifactNumToKeepStr: '50'))
        }

      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "agent1"
      }
      stages{
        stage('prep env')
        {
          steps
          {
            container('sandbox-chef'){
            script{
              common.uuidGen()
              currentBuild.description = env.jobUuid
              deploy.prepare_env()
              env.app_platform="${config.app_platform}"
              env.version="${config.version}"
              env.build_name="${config.build_name}"
              env.primary_farm="${config.primary_farm}"
              env.primaryServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.drServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
              env.primaryDatacenter=common.getPrimaryDatacenter(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.primaryDatacenter=env.primaryDatacenter
              if (config.enableParallelDeploy){
                desiredParallelState = true
              } else {
                desiredParallelState = false
              }
              env.parallelDeployConfig=deploy.getParallelDeployConfig(env.primaryServerCount.toInteger(),desiredParallelState)

            }
          }
          }
        }
        stage('click to approve'){
          steps{
            script{
            currentBuild.displayName = env.build_name
            if ( "${env.autodeploy_1stmachine}" == "false" && "${config.on_demand_release_version}" != "true" )
              {
                timeout(time: 180, unit: 'SECONDS') {
                input (
                  id: 'Yes',
                  message: "Promote to ${config.environment}",
                  submitter: "${env.approver}",
                  submitterParameter:'qaProm'
                  )
                }
              }
	      if ( "${config.on_demand_release_version}" == "true")
              {
                timeout(time: 180, unit: 'SECONDS') {
		 env.version = input (id: 'inputVersion1',
				message: 'Proceed or Abort?',
				parameters: [string(defaultValue: '', description: 'enter version ', name: 'inputVersion', trim: true)],
				submitter: "${env.approver}")
		}
                println('version' + "${env.version}")
                env.build_name=env.version
		if ( env.version.isEmpty() ) {
                  error('version is empty')
                }
              }
            }
          }
        }
        stage('1st server')
        {
          steps{
            container('sandbox-chef')
            {
              script{
              println "pServerCount: ${env.primaryServerCount}"
              println "pDrCount: ${env.drServerCount}"
              println "parallel: ${env.parallelDeployConfig}"
              println "primaryDC: ${env.primaryDatacenter}"
              println "${config.version}"
              println "${env.autodeploy_1stmachine}"
              println "${env.autodeploy_allmachine}"
              env.environment = "${config.environment}"
              println "config.env - ${config.environment}"
              currentBuild.displayName = env.build_name
                  if ("${config.application_name}" == "webui"  && "${config.environment}" == "qa"){
                        println('build_name' + "${config.build_name}" )
                        println('version' + "${config.version}" ) 
                      if ("${config.app_farm}" != "web220" ){   
                        if ("${config.app_farm}" != "web-ew"){
	                   deploy.checkPackageJson(config.build_name,config.version,config.application_name) }
                      }
                     }
                 echo "deploy 1st machine "
                 println "reponame: ${config.repo_name}"
                 build.versionupdate_databag(config.repo_name,env.version,config.app_farm,env.environment,env.gitCredentialID)
                 deploy.artifactPromotion(env.environment,config.karaf_feature,config.karaf_app_repo,config.build_name,env.nexus_repository)
                 if ("${config.artifact_format}" == "docker"){
                   deploy.dockerArtifactPromotion(env.environment,config.dev_registry,config.image_name,config.version,env.prod_registry)
                 }

                 retry(2){
                 if("${config.deploy_tool}"=="kubernetes"){
                  deploy.kubernetes_deploy(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config)
                 } else {
                  deploy.deploy1stmachine(config.environment,config.app_platform,config.application_name,config.app_farm,primaryServerCount)
                 }
                 }
               //build.updateStage("1")
               //build.gitCommitPush(gitCredentialID,"${config.application_name}")
             }
            }
          }
        }
        stage("DeployAll")
        {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          steps
            {
            container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = env.build_name
                 if ("${env.autodeploy_allmachine}" == "false")
                  {
                    timeout(time: 180, unit: 'SECONDS') {
                    input (
                        id: 'Yes',
                        message: "Proceed to the rest of the servers",
                        submitter: "${env.approver}"
                      )
                    }
                  }
                  echo "enable first instnce in lb"
                  deploy.enableFirstServer(config.environment,config.app_platform,config.application_name,config.app_farm)
                  deploy.getPrimaryList(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
                  rabbitmq.populateDeployItems(env.jobUuid,0)
                  //build.gitCommitPush(gitCredentialID,"${config.application_name}")
                  //echo "env.primary_farm - ${env.primary_farm}"
              }
            }
          }
        }

        stage('parallel deploy') {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          failFast true
          parallel {
          stage('worker1'){
            steps {
                script{
                  currentBuild.description = env.jobUuid
                  currentBuild.displayName = env.build_name
                    container('sandbox-chef'){
                      echo env.jobUuid
                      rabbitmq.consumeDeployItem(env.jobUuid,'enable','1')
                    }
                }
             }
          }
          stage('worker2'){
             steps {
                 script{
                   currentBuild.description = env.jobUuid
                   currentBuild.displayName = env.build_name
                    container('sandbox-chef'){
                      rabbitmq.consumeDeployItem(env.jobUuid,env.parallelDeployConfig,'2')
                  }
                 }
               }
             }
          }
          post {
            success {
               script {
                 container('sandbox-chef'){
                 rabbitmq.deleteQueue(env.jobUuid)
               }
              }
            }
            failure {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
            aborted {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
          }
        }

        stage("dr deploy")
          {
            when {
            expression { env.drServerCount.toInteger() > 0 }
            }

            steps{
              container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = env.build_name
                if ( "${env.environment}" == "prod")
                {
                   echo "deploy to prod and qa prod"
                   deploy.getDrList(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
                   rabbitmq.populateGeneralItems('deploy.production.jobs')
                }
                else
                {
                  echo "deploy to dr"
                  deploy.getDrList(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
                  rabbitmq.populateGeneralItems('deploy.general.jobs')
                }
            }
          }
          }
        }
        stage("Promote ")
        {
          when {
          environment name: 'primary_farm', value: 'true'
          }

          steps {

            container('sandbox-chef'){
            timeout(time: 60, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "promote to ${env.promenv}",
              submitter: "${env.approver}"
              )
            }
            script{
              currentBuild.description = env.jobUuid
              currentBuild.displayName = env.build_name
              if (config.environment != 'prod') {
                println "build nmae - ${env.build_name}"
                if (config.next_env_pipeline_branch != null && !config.next_env_pipeline_branch.trim().isEmpty() ){
                  next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
                  build.updateJsonVersionDedicateBranch(env.environment,next_env_pipeline_branch,env.version,currentBuild.displayName,config.application_name,gitCredentialID)
                }
                else if ("${config.on_demand_release_version}" == "true"){
                  build.updateJsonVersion(config.environment,env.version,env.build_name,config.application_name,gitCredentialID)
                }
                else {
                  build.updateJsonVersion(config.environment,config.version,config.build_name,config.application_name,gitCredentialID)
                //build.gitCommitPush(gitCredentialID,"${config.application_name}")
               }
              }
            }
          }
        }
        }
      }
    }
  }
