def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      agent any
       stages{
         stage('dr deployment')
         {
           steps{
            container('sandbox-chef')
             {
               script{
                currentBuild.displayName = "${config.environment}_${config.version}"
                 print "config.app_platform - ${config.app_platform}"
                 print "config.app_type - ${config.app_type}"
                 print "config.application_name - ${config.application_name}"
                 dr.dr_deploy(config.environment,config.app_platform,config.app_type)
               }
             }
           }
         }
        }
      }
    }
