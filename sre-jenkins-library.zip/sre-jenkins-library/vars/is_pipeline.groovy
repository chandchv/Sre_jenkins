def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      options {
                buildDiscarder(logRotator(numToKeepStr: '25', artifactNumToKeepStr: '25'))
              }    
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "python"
      }
      //parameters {
        //choice(choices: ['Staging'], description: 'chose environment', name: 'exec_environment')
        //choice(choices: ['51001', '51002'], description: 'application poet', name: 'app_port')
        //string(name: 'nodeName', description: 'hostname' )
      //}
      stages{
        stage('getting primary site'){
          steps{
            container('sandbox-python'){
            script{
              currentBuild.displayName = env.nodeName
              env.primaryDatacenter=common.getPrimaryDatacenter('medhx','mds','mds','staging','primary')
            }
           }
          }
        }
        stage('execution'){
          steps{
            timeout(time: 180, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "Clear rxhub cache for ${env.primaryDatacenter} hazelcast?",
            )
            }
            container('sandbox-python'){
            script{
              currentBuild.displayName = env.nodeName
              if (config.executionComponents.contains('hazelcastCacheClear')){
                is_utils.hazelcastCacheClear(env.primaryDatacenter)
              }
            }
          }
         }
      }
     }
  }
}
