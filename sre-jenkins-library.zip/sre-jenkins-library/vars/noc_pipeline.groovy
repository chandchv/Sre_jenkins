def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "vsphere"
      }
      options {
                buildDiscarder(logRotator(numToKeepStr: '25', artifactNumToKeepStr: '25'))
                disableConcurrentBuilds()
      }
      parameters {
        //choice(choices: ['Staging'], description: 'chose environment', name: 'exec_environment')
        //choice(choices: ['51001', '51002'], description: 'application poet', name: 'app_port')
        string(name: 'nodeName', description: 'hostname (please do not include .dc)' )
      }
      stages{
        stage('Get host details'){
          steps {
            container('chef-vsphere'){
            script{
              currentBuild.displayName = env.nodeName
              noc_utils.restrictedGroup(nodeName)
              println "envrgroup ${env.rGroup}"
              if (env.rGroup.toString() != '1'){
                println "get node detail"
                noc_utils.getNodeDetails(env.nodeName)
              }
            }
          }
        }
      }
        stage('apply filter'){
          steps{
            container('chef-vsphere'){
            script{
              currentBuild.displayName = env.nodeName
              if (env.rGroup.toString() != '1'){
              noc_utils.resourceCheck(config.dcEval,config.datacenters,config.envEval,config.environments,config.hostEval,config.hostnamePatterns,config.osEval,config.oss,config.startTime,config.endTime)
             }
            }
           }
          }
        }
        stage('execution'){
          steps{
            timeout(time: 180, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "Proceed with action?",
            )
            }
            container('chef-vsphere'){
            script{
              currentBuild.displayName = env.nodeName
              if (config.executionComponents.contains('disableLb')){
                (env.app_ports.tokenize(',[]"')).each { port ->
                  noc_utils.instanceLbDisable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                }
              }
              if (config.executionComponents.contains('knifeReboot')){
                noc_utils.knifeReboot(env.nodeName,env.app_environment,env.datacenter,env.rGroup)
              }
              if (config.executionComponents.contains('chefSimpleCommand')){
                noc_utils.chefSimpleCommand(env.nodeName,config.chefCommand,env.rGroup)
              }
              if (config.executionComponents.contains('enableLb')){
                (env.app_ports.tokenize(',[]"')).each { port ->
                  noc_utils.instanceLbEnable(env.php_environment,env.datacenter,env.nodeName,env.ipaddress,port,env.app_platform,env.app_type,env.app_farm)
                }
              }
            }
          }
         }
      }
     }
  }
}
