def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        nexusCred='nexus-cred'
        phpCred='phpCred'
      }
      agent any
      stages{
        stage('prep env')
        {
          steps
          {

            container('sandbox-chef'){
            script{
              // common.slackNotify(config.app_type,"SUCCESSFUL")
              common.uuidGen()
              currentBuild.description = env.jobUuid
              deploy.prepare_env()
              env.app_platform="${config.app_platform}"
              env.version="${config.version}"
              env.primary_farm="${config.primary_farm}"
              env.primaryServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.drServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
              env.primaryDatacenter=common.getPrimaryDatacenter(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.primaryDatacenter=env.primaryDatacenter
              if (config.enableParallelDeploy){
                desiredParallelState = true
              } else {
                desiredParallelState = false
              }
              env.parallelDeployConfig=deploy.getParallelDeployConfig(env.primaryServerCount.toInteger(),desiredParallelState)

            }
          }
          }
        }


        stage('click to approve'){
          steps{
            script{
            currentBuild.displayName = config.build_name
            if ( "${env.autodeploy_1stmachine}" == "false")
              {
                timeout(time: 180, unit: 'SECONDS') {
                input (
                  id: 'Yes',
                  message: "Promote to ${config.environment}",
                  submitter: "${env.approver}",
                  submitterParameter:'qaProm'
                  )
                }
              }
            }
          }
        }

        stage('build')
        {
          steps {
            script{
              build.prepare_env()
              println "${config.on_demand_release_branch}"
              println "${env.repository_type}"
              container('sandbox-chef'){
              env.primaryServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              }
              env.application_name = "${config.application_name}"
              env.app_platform = "${config.app_platform}"
              env.primary_farm = "${config.primary_farm}"
              if ( "${config.on_demand_release_branch}" == "true" )
              {
                build.branchInput()
              }
              else
              {
                env.branch = "${config.branch}"
              }
              env.CD = "${config.CD}"
              env.dev_only_pipeline = "${config.dev_only_pipeline}"
              env.next_env_pipeline_branch = "${config.next_env_pipeline_branch}"
              sh "rm -rf $WORKSPACE/${config.application_name}"
              if ("${config.source_code_tool}" == "git")
              {
              dir("$WORKSPACE/${config.application_name}") {
                  git(
                    url: config.repository_url,
                    credentialsId: env.gitCredentialID,
                    branch: env.branch
                  )
                }
              }
              else if ("${config.source_code_tool}" == "svn")
              {
                  dir("$WORKSPACE/${config.application_name}") {
                  checkout(
                    [$class: 'SubversionSCM',
                    additionalCredentials: [],
                    excludedCommitMessages: '',
                     excludedRegions: '',
                     excludedRevprop: '',
                     excludedUsers: '',
                     filterChangelog: false,
                     ignoreDirPropChanges: false,
                     includedRegions: '',
                    locations: [[cancelProcessOnExternalsFail: true, credentialsId: 'svn-automation', depthOption: 'infinity', ignoreExternalsOption: false, local: '.',
                    remote: "${config.repository_url}/branches/${config.branch}"]],
                    quietOperation: true, workspaceUpdater: [$class: 'UpdateUpdater']])
                }
              }

            }
            script{
            echo "${env.extraRepo} - extrarepo"
              // check out extra repo is configured
              if("${env.extraRepo}" == "true" && "${config.scan}" == "true")
              {
                echo "there is extra repo"
                build.cloneExtraRepo()
              }
              // version strategy
              //no build but scan and deploy - with need version inpout
              if ( "${config.CI}" == "false" && "${config.scan}" == "true" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.CI}" == "false" && "${config.app_type}" == "platformservices" && "${config.scan}" == "false" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.CI}" == "false" && "${config.app_type}".startsWith("ss2")  && "${config.scan}" == "false" &&  "${config.CD}" == "true")
              {
                build.versionInput()
                env.version_display="${version}"
                env.version="${version}"

              }
              else if ( "${config.version_strategy}" == "medhxui")
              {
                container ('sandbox-chef'){
                version=build.getMedhxUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
              else if ( "${config.version_strategy}" == "webui")
              {
                container ('sandbox-chef'){
                version=build.getWebUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
             else if ( "${config.version_strategy}" == "huddleweb")
              {
                container ('sandbox-chef'){
                version=build.getWebUiVersion()
                println "version from package - ${version}"
                gitCommitNumber=build.getBuildFromGit()
                env.jar_version="${version}-${gitCommitNumber}"
                //env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
               }
             }
              else if ( "${config.version_strategy}" == "pom")
              {
              container ('sandbox-git'){
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                //env.jar_version="${version}-0"
                //env.jar_name="${env.jar_name}-${version}"
                env.jar_name="${env.jar_name}"
                //env.version_display="${version}"
                //env.version="${version}.0"
                gitCommitNumber=build.getBuildFromGit()
                println "commit number from git describe - ${gitCommitNumber}"
                env.jar_version="${version}-${gitCommitNumber}"
                env.version_display="${version}-${gitCommitNumber}"
                env.version="${version}-${gitCommitNumber}"
                }
              }
              else if ( "${config.version_strategy}" == "gear")
              {
                gitCommitHash = build.getVersion()
                println gitCommitHash
                build.checkGitCommit(gitCommitHash)
                version = build.getVersionFromGear()
                base_version = build.baseVersionGen(version,2)
                last_build = build.getBuildNumber(version)
                println last_build
                new_build = "B"+(last_build.toInteger()+1).toString()
                println new_build

                env.jar_version="${version}-${new_build}"
                env.jar_name="${env.jar_name}-${env.jar_version}"
                env.version_display="${version}-${new_build}"
                env.version="${version}.${new_build}"
                //sleep 3600
              }
              else if ( "${config.version_from_pom}" == "true")
              {
                version=build.getVersionFromPom()
                println "version from pom- ${version}"
                env.jar_version="${version}"
                env.jar_name="${env.jar_name}-${version}"
                env.version_display="${version}"
                env.version="${version}.0"

              }
              else if ( "${config.version_from_databag}" == "true"){
                build.getVersionFromDatabag("${config.dev_repo}","${config.app_farm}")
                if ("${env.databagBuild}" == "")
                {
                  env.jar_version="${env.databagVersion}"
                  env.version="${env.databagVersion}_0"
                  env.version_display="${env.databagVersion}"
                }
                else
                {
                  env.version="${env.databagVersion}_${env.databagBuild}"
                  env.version_display="${env.databagVersion}_${env.databagBuild}"
                  env.jar_version="${version}"
                }
                println "version from git -  ${env.version}"
              }
              else { // otherwise getting version from git
                version=build.getVersion()
                println "version from git -  ${version}"
                env.version="${version}"
                env.version_display="${version}"
                env.jar_version="${version}"
              }


              if ( "${config.CI}" == "true" && "${config.scan}" == "true")
              {
                echo "CI true with scan"
                if ("${config.buildStrategy}" == "gear")
                {
                  echo "gear build with scan"
                  //build.gear_build_withoutScan(env.MAVEN_SETTINGS_FILE,new_build)
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  build.gear_build_withScan(env.MAVEN_SETTINGS_FILE,new_build)
                }
                else if ( "${env.build_tool}" == "maven")
                {

                    //tool 'maven'
                    echo "maven build with scan"
                    build.maven_build_withScan(env.MAVEN_SETTINGS_FILE)

                }
                else if("${env.build_tool}" == "gradle"){
                //  tool 'gradle5.2.1'
                  echo "gradle build with scan"
                  build.gradle_build_withScan()
                }

                else if ("${env.build_tool}" == "nodejs")
                {
                  println "nodejs build with scan"
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-firefox'){
                    build.nodejs_build()
                  }
                }

                else if ("${env.build_tool}" == "huddleweb")
                {
                  println "nodejs build with scan"
                  scannerHome = tool 'stand-alone-330'
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-8-9-4'){
                    build.huddleweb_build()
                  }
                }

                else if ("${config.buildStrategy}" == "ilac")
                {
                  println "ilac build"
                  scannerHome = tool 'stand-alone-330'
                  //build.sonar_scan_all("${env.app_platform}","${env.application_name}")
                  container('node-8-9-4'){
                    build.ilac_build(env.environment)
                  }
                }

              }
              else if("${config.CI}" == "true" && "${config.scan}" == "false")
              {
                echo "CI true without scan"
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven build without scan"
                  build.maven_build_withoutScan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle build without scan"
                  build.gradle_build_withoutScan()
                }
              }
              else if("${config.CI}" == "false" && "${config.scan}" == "true")
              {
                if ( "${env.build_tool}" == "maven")
                {
                  //tool 'maven'
                  echo "maven only scan"
                  build.maven_only_scan(env.MAVEN_SETTINGS_FILE)
                }
                else if("${env.build_tool}" == "gradle"){
                  //tool 'gradle5.2.1'
                  echo "gradle only scan"
                  build.gradle_only_scan()
                }
                else {
                  scannerHome = tool 'stand-alone-330'
                  build.sonar_scan_only("${env.app_platform}","${env.application_name}")
                }
              }
              currentBuild.displayName = "${env.version_display}"
              //build.updateVersionJson("${env.version}")
              //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              //sleep 300

          //upload artifacts
          if ( "${config.pipeline_dev_mode}" == "false" && "${config.CI}" == "true")
            {
              if ("${config.dev_only_pipeline}" == "true" ){
                //delete current build
                container('sandbox-curl'){
                  withCredentials([usernameColonPassword(credentialsId: nexusCred, variable: 'NEXUSPASS')]) {
                    sh(script:"""curl --request DELETE --user "\${NEXUSPASS}"  --silent "https://nexusrepo.drfirst.com/nexus/content/repositories/${env.nexus_repository}/${env.groupID}/${env.artifactId}/dev" """,returnStdout: true)
                  }
                }
                //publish new build
                build.publishToNexus(config.application_name,
                "dev",
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              else {
                build.publishToNexus(config.application_name,
                env.jar_version,
                env.nexus_repository,
                env.nexusCred,
                env.artifactId,
                env.classifier,
                //env.jar_location,
                //"$WORKSPACE/${env.jar_location}/${env.jar_name}-${env.jar_version}.jar",
                "$WORKSPACE/${env.jar_location}/${env.jar_name}.${env.type}",
                env.type,
                env.groupID )
              }
              //update build details
              if ( "${config.version_strategy}" == "gear"  && "${config.dev_only_pipeline}" != "true"){
                newJson = build.getNewBuildJson(version,(last_build.toInteger()+1).toString(),gitCommitHash)
                println newJson

                sh """
                  echo "${newJson}" > details.json
                """
                build.gitCommitPush(gitCredentialID,"${config.application_name}")
              }

            }
            }
          }
          post {
            failure {
                 script {
                    sleep 10
                }
              }
          }
        }
        stage('1st server')
        {
          steps{
            container('sandbox-chef')
            {
              script{
              println "pServerCount: ${env.primaryServerCount}"
              println "pDrCount: ${env.drServerCount}"
              println "parallel: ${env.parallelDeployConfig}"
              println "primaryDC: ${env.primaryDatacenter}"
              println "${config.version}"
              println "${env.autodeploy_1stmachine}"
              println "${env.autodeploy_allmachine}"
              env.environment = "${config.environment}"
              println "config.env - ${config.environment}"
              currentBuild.displayName = config.build_name

                 echo "deploy 1st machine "
                 println "reponame: ${config.repo_name}"
                 build.versionupdate_databag(config.repo_name,env.version,config.app_farm,env.environment,env.gitCredentialID)
                 deploy.artifactPromotion(env.environment,config.karaf_feature,config.karaf_app_repo,config.build_name,env.nexus_repository)
                 retry(2){
                   deploy.deploy1stmachine(config.environment,config.app_platform,config.application_name,config.app_farm,primaryServerCount)
                 }
               //build.updateStage("1")
               //build.gitCommitPush(gitCredentialID,"${config.application_name}")
             }
            }
          }
        }
        stage("DeployAll")
        {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          steps
            {
            container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = config.build_name
                 if ("${env.autodeploy_allmachine}" == "false")
                  {
                    timeout(time: 180, unit: 'SECONDS') {
                    input (
                        id: 'Yes',
                        message: "Proceed to the rest of the servers",
                        submitter: "${env.approver}"
                      )
                    }
                  }
                  echo "enable first instnce in lb"
                  deploy.enableFirstServer(config.environment,config.app_platform,config.application_name,config.app_farm)
                  deploy.getPrimaryList(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
                  rabbitmq.populateDeployItems(env.jobUuid,0)
                  //build.gitCommitPush(gitCredentialID,"${config.application_name}")
                  //echo "env.primary_farm - ${env.primary_farm}"
              }
            }
          }
        }

        stage('parallel deploy') {
          when {
          expression { env.primaryServerCount.toInteger() > 1 }
          }
          failFast true
          parallel {
          stage('worker1'){
            steps {
                script{
                  currentBuild.description = env.jobUuid
                  currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      echo env.jobUuid
                      rabbitmq.consumeDeployItem(env.jobUuid,'enable','1')
                    }
                }
             }
          }
          stage('worker2'){
             steps {
                 script{
                   currentBuild.description = env.jobUuid
                   currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      rabbitmq.consumeDeployItem(env.jobUuid,env.parallelDeployConfig,'2')
                  }
                 }
               }
             }
          }
          post {
            success {
               script {
                 container('sandbox-chef'){
                 rabbitmq.deleteQueue(env.jobUuid)
               }
              }
            }
            failure {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
            aborted {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
          }
        }

        stage("dr deploy")
          {
            when {
            expression { env.drServerCount.toInteger() > 0 }
            }

            steps{
              container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = config.build_name
                if ( "${env.environment}" == "prod")
                {
                   echo "deploy to prod and qa prod"
                   deploy.getDrList(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
                   rabbitmq.populateGeneralItems('deploy.production.jobs')
                }
                else
                {
                  echo "deploy to dr"
                  deploy.getDrList(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
                  rabbitmq.populateGeneralItems('deploy.general.jobs')
                }
            }
          }
          }
        }
        stage("Promote ")
        {
          when {
          environment name: 'primary_farm', value: 'true'
          }

          steps {

            container('sandbox-chef'){
            timeout(time: 60, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "promote to ${env.promenv}",
              submitter: "${env.approver}"
              )
            }
            script{
              currentBuild.description = env.jobUuid
              currentBuild.displayName = config.build_name
              if (config.environment != 'prod') {
                println "build nmae - ${config.build_name}"
                build.updateJsonVersion(config.environment,config.version,config.build_name,config.application_name,gitCredentialID)
                //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              }
            }
          }
        }
        }
      }
    }
  }
