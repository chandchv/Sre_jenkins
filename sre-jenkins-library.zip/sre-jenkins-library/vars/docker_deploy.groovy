def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    pipeline {
      environment {
        gitCredentialID='svc-automation'
        phpCred='phpCred'
      }
      agent {
          label "docker"
      }
      stages{
        stage('prep env')
        {
          steps
          {
            container('sandbox-chef'){
            script{
              common.uuidGen()
              currentBuild.description = env.jobUuid
              deploy.prepare_env()
              env.app_platform="${config.app_platform}"
              env.version="${config.version}"
              env.primary_farm="${config.primary_farm}"
              env.primaryServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.drServerCount=common.getServerCount(config.app_platform,config.app_type,config.app_farm,config.environment,"dr")
              env.primaryDatacenter=common.getPrimaryDatacenter(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.webServerType=common.getWebServerType(config.app_platform,config.app_type,config.app_farm,config.environment,"primary")
              env.primaryDatacenter=env.primaryDatacenter
              if (config.enableParallelDeploy){
                desiredParallelState = true
              } else {
                desiredParallelState = false
              }
              env.parallelDeployConfig=deploy.getParallelDeployConfig(env.primaryServerCount.toInteger(),desiredParallelState)

            }
          }
          }
        }
        stage('click to approve'){
          steps{
            script{
            currentBuild.displayName = config.build_name
            if ( "${env.autodeploy_1stmachine}" == "false")
              {
                timeout(time: 180, unit: 'SECONDS') {
                input (
                  id: 'Yes',
                  message: "Promote to ${config.environment}",
                  submitter: "${env.approver}",
                  submitterParameter:'qaProm'
                  )
                }
              }
            }
          }
        }
        stage('1st server')
        {
          steps{
            container('sandbox-chef')
            {
              script{
              println "pServerCount: ${env.primaryServerCount}"
              println "pDrCount: ${env.drServerCount}"
              println "parallel: ${env.parallelDeployConfig}"
              println "primaryDC: ${env.primaryDatacenter}"
              println "${config.version}"
              println "${env.autodeploy_1stmachine}"
              println "${env.autodeploy_allmachine}"
              env.environment = "${config.environment}"
              println "config.env - ${config.environment}"
              currentBuild.displayName = config.build_name

                 echo "deploy 1st machine "
                 println "reponame: ${config.repo_name}"
                 build.versionupdate_databag(config.repo_name,env.version,config.app_farm,env.environment,env.gitCredentialID)
                 deploy.artifactPromotion(env.environment,config.karaf_feature,config.karaf_app_repo,config.build_name,env.nexus_repository)
                 if ("${config.artifact_format}" == "docker"){
                   deploy.dockerArtifactPromotion(env.environment,config.dev_registry,config.image_name,config.version,config.prod_registry)
                 }
                 retry(2){
                 if("${config.deploy_tool}"=="kubernetes"){
                  //deploy.kubernetes_deploy(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config)
                  deploy.kubernetes_1stdeploy(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config,config.primaryDatacenter)
                 } else {
                  deploy.deploy1stmachine(config.environment,config.app_platform,config.application_name,config.app_farm,primaryServerCount)
                 }
                 }
               //build.updateStage("1")
               //build.gitCommitPush(gitCredentialID,"${config.application_name}")
             }
            }
          }
        }
        stage("DeployAll")
        {

          steps
            {
            container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = config.build_name
                 if ("${env.autodeploy_allmachine}" == "false")
                  {
                    timeout(time: 180, unit: 'SECONDS') {
                    input (
                        id: 'Yes',
                        message: "Proceed to the rest of the servers",
                        submitter: "${env.approver}"
                      )
                    }
                  }
              }
            }
          }
        }

        stage('parallel deploy') {

          failFast true
          parallel {
          stage('worker1'){
            steps {
                script{
                  currentBuild.description = env.jobUuid
                  currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      echo env.jobUuid
                      rabbitmq.consumeDeployItem(env.jobUuid,'enable','1')
                      if("${config.deploy_tool}"=="kubernetes"){
                        deploy.kubernetes_deployAll(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config,config.primaryDatacenter,config.app_platform)
                      }
                    }
                }
             }
          }
          stage('worker2'){
             steps {
                 script{
                   currentBuild.description = env.jobUuid
                   currentBuild.displayName = config.build_name
                    container('sandbox-chef'){
                      rabbitmq.consumeDeployItem(env.jobUuid,env.parallelDeployConfig,'2')
                  }
                 }
               }
             }
          }
          post {
            success {
               script {
                 container('sandbox-chef'){
                 rabbitmq.deleteQueue(env.jobUuid)
               }
              }
            }
            failure {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
            aborted {
               script {
                 container('sandbox-chef'){
                 common.generateRequeueList()
                 rabbitmq.populateDeployItems(env.jobUuid,5)
               }
              }
            }
          }
        }

        stage("dr deploy")
          {
            steps{
              container('sandbox-chef'){
              script{
                currentBuild.description = env.jobUuid
                currentBuild.displayName = config.build_name

                if("${config.deploy_tool}"=="kubernetes"){
                  if(environment == 'staging') {
                    if(env.primaryDatacenter=='DS'){
                      dr_datacenter="RU"}
                      else{
                        dr_datacenter="DS"
                      }
                  }
                  else if (environment == 'prod')
                  {
                  if(env.primaryDatacenter=='VZ'){
                    dr_datacenter="DP"}
                    else{
                      dr_datacenter="VZ"
                    }
                  }
                  deploy.kubernetes_1stdeploy(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config,dr_datacenter)
                  deploy.kubernetes_deployAll(config.environment,config.application_name,config.deploy_repo,config.version,config.kube_config,dr_datacenter,config.app_platform)
                }
            }
          }
          }
        }
        stage("Promote ")
        {
          when {
          environment name: 'primary_farm', value: 'true'
          }

          steps {

            container('sandbox-chef'){
            timeout(time: 60, unit: 'SECONDS') {
            input (
              id: 'Yes',
              message: "promote to ${env.promenv}",
              submitter: "${env.approver}"
              )
            }
            script{
              currentBuild.description = env.jobUuid
              currentBuild.displayName = config.build_name
              if (config.environment != 'prod') {
                println "build nmae - ${config.build_name}"
                build.updateJsonVersion(config.environment,config.version,config.build_name,config.application_name,gitCredentialID)
                //build.gitCommitPush(gitCredentialID,"${config.application_name}")
              }
            }
          }
        }
        }
      }
    }
  }
