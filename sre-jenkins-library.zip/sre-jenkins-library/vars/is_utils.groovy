def hazelcastCacheClear(datacenter){
  if (datacenter == 'DS'){
    hazelcastHost = "172.17.72.12"
  } else if (datacenter == 'RU'){
    hazelcastHost = "172.17.80.105"
  }
  hazelcastPort = "15701"
  hazelcastGroup = "hz-cache-staging"
  hazelcastPassword = "dr1Staging"

sh """
cat > hazelcastCacheClear.py <<-'EOF'
#!/usr/bin/env python
import hazelcast
import logging

logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)

config = hazelcast.ClientConfig()
config.network_config.addresses.append("${hazelcastHost}:${hazelcastPort}")
config.group_config.name = "${hazelcastGroup}"
config.group_config.password = "${hazelcastPassword}"

client = hazelcast.HazelcastClient(config)

hazelcastCacheNames = ['dcs24h.staging.rxhub','dcs24h.staging.rxhub2017','dcs72h.staging.rxhub','dcs24h.staging.meds-xml','dcs24h.staging.meds-async']

for cName in hazelcastCacheNames:
  print(cName)
  my_map = client.get_map(cName).blocking()
  print("map.size", my_map.size())
  my_map.clear()
  print("map.size", my_map.size())
"""

sh """
python hazelcastCacheClear.py
"""
}
