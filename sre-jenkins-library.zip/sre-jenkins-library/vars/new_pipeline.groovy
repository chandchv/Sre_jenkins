import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType

def create_repo(){
  def list = []

  //def dir = readDir("$WORKSPACE/inventory")
  //dir.eachFileRecurse (FileType.FILES) { file ->
  //  list << file
  //}
  //list.each {
  //println it.path
//}
def a_list = ["pi_list.json","medhx_list.json","iprescribe_list.json","commonservices_list.json","rcopia_list.json", "epcs_list.json","consumersolutions_list.json","rcopia3x_list.json"]
a_list.each {
    println it

    jsonFile1 = "./inventory/${it}"
    def json1 = readJSON file: jsonFile1
    totalApplication = json1.projects.size()
    println "count" + totalApplication
    for(int i = 0;i<totalApplication;i++) {
      application_name = json1['projects'][i]['application_name']
      app_platform = json1['projects'][i]['app_platform']
      app_type = json1['projects'][i]['app_type']
      dev_repo = json1['projects'][i]['dev_repo']
      ci = json1['projects'][i]['CI']
      repository_url = json1['projects'][i]['repository_url']
      branch = json1['projects'][i]['branch']
      source_code_tool = json1['projects'][i]['source_code_tool']
      withCredentials([usernameColonPassword(credentialsId: 'svc-automation', variable: 'GITPASS')]) {
          sh """
          rm -rf ${application_name}
          git clone https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${application_name}.git
          cp -r master_jenkinsfile ./${application_name}/Jenkinsfile
          cd ${application_name}
          ls -la
          git branch -a > ../branchlist
          if cat ../branchlist | grep -q "master"; then
            echo "branch exists"
          else
            git checkout -b master
            app_name="application_name = \\\"`echo $application_name`\\\""
            app_type="app_type = \\\"`echo $app_type`\\\""
            app_platform="app_platform = \\\"`echo $app_platform`\\\""
            dev_repo="dev_repo = \\\"`echo $dev_repo`\\\""
            ci="CI = \\\"`echo $ci`\\\""
            repository_url=\"repository_url = \\\"`echo $repository_url | sed 's/\\//\\\\\\\\\\\\//g'`\\\"\"

            source_code_tool="source_code_tool = \\\"`echo $source_code_tool`\\\""
            branch="branch = \\\"`echo $branch`\\\""
            echo "app_name - \$app_name"
            echo "app_type - \$app_type"
            echo "app_platform - \$app_platform"
            echo "dev_repo - \$dev_repo"
            sed -i "1,/application_name.*/s/application_name.*/`echo \$app_name`/g"   Jenkinsfile
            sed -i "1,/app_type.*/s/app_type.*/`echo \$app_type`/g"   Jenkinsfile
            sed -i "1,/app_platform.*/s/app_platform.*/`echo \$app_platform`/g"   Jenkinsfile
            sed -i "1,/dev_repo.*/s/dev_repo.*/`echo \$dev_repo`/g"   Jenkinsfile
            sed -i "1,/CI.*/s/CI.*/`echo \$ci`/g"   Jenkinsfile
            sed -i "1,/branch.*/s/branch.*/`echo \$branch`/g"   Jenkinsfile
            sed -i "1,/source_code_tool.*/s/source_code_tool.*/`echo \$source_code_tool`/g"   Jenkinsfile
            sed -i "1,/repository_url.*/s/repository_url.*/`echo \$repository_url`/g"   Jenkinsfile
#test
            cat Jenkinsfile
            git add .
            if [ -n \"\$(git status --porcelain)\" ]; then
              git config --global user.email "svc-devops@drfirst.com"
              git config --global user.name "svc-devops"
              git commit -am "application initial branch creation"
              git push https://\${GITPASS}@git.drfirst.com/sysops/pipelines/${application_name}.git master --force
            else
              echo 'no changes';
            fi
          fi;
          rm -rf branchlist
          """
        }
        pipeline_name = application_name.replaceAll("[\\.-]","_").replaceAll("\"","")
        jobDsl scriptText: """ multibranchPipelineJob("${app_platform}-${pipeline_name}") {
            def repo = \"https://git.drfirst.com/sysops/pipelines/${application_name}.git\"
            branchSources {
               git {
                   remote(repo)
                   credentialsId('svc-automation')
                   id('241ea4d0-894e-48de-8922-5722f0451fab')

               }
           }

        orphanedItemStrategy {
            discardOldItems {
                numToKeep(45)
            }
        }
    }"""
    }
  }
}
