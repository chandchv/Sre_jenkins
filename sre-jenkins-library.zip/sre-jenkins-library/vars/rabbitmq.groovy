def createRabbitMqItem(item){
sh """
echo "starting"
cat > newItem.py <<-'EOF'
#!/usr/bin/env python
import pika
import sys

message = ' '.join(sys.argv[1:]) or "Hello World!"

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials))
channel = connection.channel()

channel.queue_declare(queue='deploy.general.processing', arguments={
  'x-message-ttl' : 10000, # Delay until the message is transferred in milliseconds.
  'x-dead-letter-exchange' : 'amq.direct', # Exchange used to transfer the message from A to B.
  'x-dead-letter-routing-key' : 'hello' # Name of the queue we want the message transferred to.
})

channel.basic_publish(exchange='', routing_key='deploy.general.processing', body=message )
print(" [x] Sent %r" % message)
connection.close()
"""
    sh """
    echo "done"
    ls -la

    cat newItem.py
    python newItem.py test1
    """
}

def populateDeployItems(queueName,priorityLevel){
sh """
cat > populateDeployItems.py <<-'EOF'
#!/usr/bin/env python
import pika
import sys

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials))
channel = connection.channel()

channel.queue_declare(queue='${queueName}',durable=True,auto_delete=True,arguments={
    'x-max-priority': 10
})

if ${priorityLevel}:
  priorityLevel = int(${priorityLevel})
else:
  priorityLevel = 0

print(priorityLevel)


with open("machine_list") as f:
   lines = f.readlines()
   for line in lines:
     print(line.strip())
     message = line.strip()
     channel.basic_publish(exchange='', routing_key='${queueName}', body=message, properties=pika.BasicProperties(priority=priorityLevel) )
     print (" Sent %r" % message)

connection.close()
"""

sh """
python populateDeployItems.py
"""
}

def populateGeneralItems(queueName){
sh """
cat > populateGeneralItems.py <<-'EOF'
#!/usr/bin/env python
import pika
import sys

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials))
channel = connection.channel()

channel.queue_declare(queue='${queueName}',durable=True)


with open("machine_list") as f:
   lines = f.readlines()
   for line in lines:
     print(line.strip())
     message = line.strip()
     channel.basic_publish(exchange='', routing_key='${queueName}', body=message )
     print (" Sent %r" % message)

connection.close()
"""

sh """
python populateGeneralItems.py
"""
}

def consumeDeployItem(queueName,enableDisable,workerID){
sh """
cat > consumeDeployItem${workerID}.py <<-'EOF'
#!/usr/bin/env python
import pika
import subprocess
import sys

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials, socket_timeout=600))
channel = connection.channel()

status = channel.queue_declare(queue='${queueName}',durable=True, auto_delete=True, arguments={
    'x-max-priority': 10
})
print('${queueName}')
print('${enableDisable}')

def writeJobToFile(job_body):
  f = open("machine_list${workerID}", "wb")
  f.write(job_body)
  f.close()

def executeChef(machine_name):
  if machine_name.decode("utf-8").startswith('external'):
    chefCmd = ["knife ssh 'name:"+machine_name.decode("utf-8")+"' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem' -a ipaddress 'sudo chef-client -o df_nginx::external_widgets' " ]
  else:
    chefCmd = ["knife ssh 'name:"+machine_name.decode("utf-8")+"' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem' -a ipaddress sudo chef-client  " ]

  print(chefCmd)
  retry=0
  while retry < 2 :
    retry += 1
    try:
      result = subprocess.run(chefCmd, stderr=sys.stderr, stdout=sys.stdout, shell=True, check=True)
      print(result.returncode, result.stdout, result.stderr)
    except:
      if retry == 2:
        sys.exit(1)
      continue
    break

if '${enableDisable}' == 'enable':
  i = 1
else:
  i = 0

print(i)

while i != 0:
  method_frame, header_frame, body = channel.basic_get('${queueName}', auto_ack=True)
  if method_frame:
      print(method_frame, header_frame, body)
      print(method_frame.message_count)
      #channel.basic_ack(method_frame.delivery_tag)
      writeJobToFile(body)
      executeChef(body)
      i = method_frame.message_count
  else:
      print('No message returned')
      break
"""

sh """
python -u consumeDeployItem${workerID}.py
"""
}

def deleteQueue(queueName){
sh """
cat > deleteQueue.py <<-'EOF'
#!/usr/bin/env python
import pika

credentials = pika.PlainCredentials('jenkins','drfirst')
connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.16.60.165',credentials=credentials))
channel = connection.channel()
channel.queue_delete(queue='${queueName}')
connection.close()
"""

sh """
python deleteQueue.py
"""
}
