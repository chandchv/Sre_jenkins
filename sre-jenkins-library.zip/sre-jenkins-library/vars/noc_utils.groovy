import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.io.FileType

def getNodeDetails(nodeName){
    currentBuild.displayName = nodeName
    sh """
    pwd
    mkdir -p /home/jenkins/.chef
    rm -rf knife.rb chefuser.pem svc-devops.pem 
    cp /home/jenkins/.chef_basic/knife.rb /home/jenkins/.chef
    cp /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
    cp /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef
    knife node show ${nodeName} -l -F json > node.json
    #cat node.json
    """
    jsonFile1 = "$WORKSPACE/node.json"
    def json1 = readJSON file: jsonFile1

    chef_environment = json1['chef_environment']

    if (chef_environment.contains('Dev')){
      env.php_environment = 'Development'
    } else if (chef_environment.contains('QA')){
      env.php_environment = 'QA'
    } else if (chef_environment.contains('Staging')){
      env.php_environment = 'Staging'
    } else if (chef_environment.contains('Prod')){
      env.php_environment = 'Production'
    } else if (chef_environment.contains('DR')){
      env.php_environment = 'Production'
    } else if (chef_environment.contains('Demo')){
      env.php_environment = 'Demo'
    }

    env.app_type = json1['default']['application_management']['application']['name']
    env.datacenter = json1['default']['application_management']['application']['datacenter']
    env.app_environment = json1['default']['application_management']['environment']
    env.app_farm = json1['default']['application_management']['application']['farm']
    env.app_platform = json1['default']['application_management']['application']['platform']
    env.app_ports = json1['default']['application_management']['application']['ports']
    env.ipaddress = json1['automatic']['ipaddress']
    env.node_os = json1['automatic']['platform']


    println env.app_type
    println env.datacenter
    println env.app_environment
    println env.app_farm
    println env.app_platform
    println env.app_ports
    println env.ipaddress
    println env.node_os
}

def f5DisableNode(app_type,datacenter,app_farm,app_platform,app_ports){
  app_ports.each{ portNumber ->
    sh """
    curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${env.datacenter}\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"enable\\",\\\"host_name\\": \\"\${nodeName}\\",\\"host_ip\\": \\"\${ip}\\",\\"app_port\\": \\"${appPort}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"jenkins"}"
    """
  }
}


def resourceCheck(dcEval,datacenters,envEval,environments,hostEval,hostnamePatterns,osEval,oss,startTime,endTime){
  //check filters
  //check datacenter
  if (datacenters == 'any'){
    println "datacenter matched"
  } else if (dcEval == 'only'){
    if (datacenters.contains(env.datacenter.toLowerCase())){
      println "datacenter matched"
    }else {
      error('Hostname does not exist in allowed datacenter(s)')
    }
  } else if (dcEval == 'not'){
    if (datacenters.contains(env.datacenter.toLowerCase())){
      error('Hostname is in blocked datacenter')
    }else {
      println "datacenter matched"
    }
  }

  //check environment
  if (environments == 'any'){
    println "environment matched"
  } else if (envEval == 'only'){
    if (environments.contains(env.app_environment.toLowerCase())){
      println "environment matched"
    }else {
      error('Hostname does not exist in allowed environment(s)')
    }
  } else if (envEval == 'not'){
    if (environments.contains(env.app_environment.toLowerCase())){
      error('Hostname is in blocked environment')
    }else {
      println "environment matched"
    }
  }

  //check OS
  if (osEval == 'any'){
    println "OS matched"
  } else if (osEval == 'only'){
    if (oss.contains(env.node_os.toLowerCase())){
      println "OS matched"
    }else {
      error('Host OS is not allowed')
    }
  } else if (envEval == 'not'){
    if (oss.contains(env.node_os.toLowerCase())){
      error('Host OS is not allowed')
    }else {
      println "OS matched"
    }
  }

  //check hostname
  hostname_match_count=0
  if (hostnamePatterns == 'any'){
    hostname_match_count += 1
  } else if (hostEval == 'only'){
    hostnamePatterns.each{ hostnamePattern ->
      if (env.nodeName.contains(hostnamePattern)){
        hostname_match_count += 1
      }
    }
  } else if (hostEval == 'not'){
    hostnamePatterns.each{ hostnamePattern ->
      if (env.nodeName.contains(hostnamePattern)){
        error('hostname is not allowed')
      }
    }
  }

  if (hostname_match_count == 0){
    error('Hostname pattern does not match')
  }

  //check hours within allowed range
  TimeZone.setDefault(TimeZone.getTimeZone('America/New_York'))
  Calendar cal=Calendar.getInstance()
  def hour = cal.get(Calendar.HOUR_OF_DAY)
  println hour
  if (startTime < endTime){
    if (hour >= startTime && hour <= endTime){
      println "Time Verified"
    } else {
      error('This action is not allwed at this time')
    }
  } else if (startTime > endTime){
      if (hour >= startTime || hour <= endTime){
        println "Time Verified"
      } else {
        error('This action is not allwed at this time')
      }
  }
}


def restrictedGroup(nodeName){
  //define restricted group for limited action
  // 1 - no app detail in chef, should be limited for most actions
  rGroup = 5
  if (nodeName.contains('elkship')||nodeName.contains('hcast')||nodeName.contains('hazcast')){
    rGroup = 1
  }
  env.rGroup = rGroup
}


//
// action funtions below
// for each action please set the minimun level of restricted group number
//

def knifeReboot(hostname,environment,datacenter,rGroup){
  minimalGroupLevel = 3
  if (rGroup && rGroup <= minimalGroupLevel){
    error('this action is not allowed for this node')
  }
  if (environment.toLowerCase() == 'production'){
    if (datacenter == 'VZ'){
      knifeFile='knife.rb.vz'
    } else if (datacenter == 'DP'){
      knifeFile='knife.rb.dp'
    }
  } else if (environment.toLowerCase() == 'staging'){
      if (datacenter == 'DS'){
        knifeFile='knife.rb.ds'
      } else if (datacenter == 'RU'){
        knifeFile='knife.rb.rs'
      }
  }
  //copy the knife file and execute knife command
  sh """
  pwd
  cp -f /home/jenkins/.chef_vsphere/${knifeFile} /home/jenkins/.chef/knife.rb
  cp -f /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
  cp -f /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef
  knife vsphere vm state ${hostname} -s reboot
  #knife vsphere  datastore list
  """
}

def chefSimpleCommand(machine_name,command,rGroup){
  minimalGroupLevel = 3
  if (env.rGroup && rGroup <= minimalGroupLevel){
    error('this action is not allowed for this node')
  }
     sh """
     
     mkdir -p /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/knife.rb /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef
     echo ${machine_name}
     eval "knife ssh 'name:${machine_name}' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"${command} \\\""
     """
}

def instanceLbEnable(environment_name,datacenter,host_name,host_ip,app_port,app_platform,appType,appFarm){
  minimalGroupLevel = 3
  if (env.rGroup && rGroup <= minimalGroupLevel){
    error('this action is not allowed for this node')
  }
  withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
  sh """
    curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${datacenter}\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"enable\\",\\\"host_name\\": \\"${host_name}\\",\\"host_ip\\": \\"${host_ip}\\",\\"app_port\\": \\"${app_port}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"jenkins\\"}"

  """
}
}

def instanceLbDisable(environment_name,datacenter,host_name,host_ip,app_port,app_platform,appType,appFarm){
  minimalGroupLevel = 3
  if (env.rGroup && rGroup <= minimalGroupLevel){
    error('this action is not allowed for this node')
  }
  withCredentials([usernameColonPassword(credentialsId: phpCred, variable: 'phpCred')]) {
  sh """
    curl -sk -u "\${phpCred}" -H "Content-Type: application/json" -X PUT http://10.100.16.23/portal/sysops/f5_ltm_handler_api.php -d "{\\"environment\\":\\"${environment_name}\\", \\"datacenter\\": \\"${datacenter}\\",\\"request_type\\": \\"application\\",\\"network_zone\\":\\"DMZ\\",\\"action\\": \\"disable\\",\\\"host_name\\": \\"${host_name}\\",\\"host_ip\\": \\"${host_ip}\\",\\"app_port\\": \\"${app_port}\\",\\"app_platform\\": \\"${app_platform}\\",\\"app_type\\": \\"${app_type}\\",\\"app_farm\\": \\"${app_farm}\\", \\"chefnode\\": \\"jenkins\\"}"
  """
}
}


def symantecResponseCheck(machine_name,deviceID,token){
     command = "cd symantec; ./run.sh "+ deviceID + " "+ token + " > /tmp/symantecRespTime; cat /tmp/symantecRespTime "
     println command
     println token
     sh """
     mkdir -p /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/knife.rb /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/chefuser.pem /home/jenkins/.chef
     cp -f /home/jenkins/.chef_basic/svc-devops.pem /home/jenkins/.chef
     echo ${machine_name}
     eval "knife ssh 'name:${machine_name}' -x chefuser  -i '/home/jenkins/.chef/chefuser.pem'   -a ipaddress  \\\"${command} \\\" > respTime.txt "
     """
     println sh(script:"cat respTime.txt", returnStdout:true)
     return sh(script:"cat respTime.txt |tail -1 |awk '{print \$2}'", returnStdout:true).trim()
}
