def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    def param = " ${config.Minute} ${config.Hour} ${config.DOM} ${config.MONTH} ${config.DOW} "
    pipeline {
      triggers { cron("${param}")}
      agent {
          label "python"
      }
      stages{
        stage('execution'){
          steps{
            container('sandbox-python'){
              script{
                sre_utils.generate_report(config.elk_url,config.elk_report_url,config.filename_prefix,config.elk_auth_id,config.sftp_hostname,config.sftp_username)
            }
          }
        }
      }
    }
  }
}
